import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Search, Filter, Download, Upload, Plus, Trash2,
  MoreHorizontal, CheckSquare, Square, ArrowUpDown,
  Calendar, ChevronLeft, ChevronRight,
  FileText, DollarSign, Users, Building, Briefcase,
  Settings, LogOut, Menu, X, Eye, EyeOff, FolderInput,
  Shield, Crown, Edit2, ListFilter, Layers, Hourglass,
  AlertTriangle, CheckCircle, Clock, AlertCircle // Restored imports
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Job, JobsViewMode } from '../types';
import { formatCurrency, formatDate, generateId } from '../utils/helpers';
import { parseFile, isValidFileName } from '../services/importService';
import DuplicateResolutionModal from './DuplicateResolutionModal';
import JobEditModal from './JobEditModal';
import InvoiceStagingModal from './InvoiceStagingModal';
import DateHeader from './DateHeader';

import ContactsPortals from './ContactsPortals';
import JobsHistoryWidget, { JobHistoryAction } from './JobsHistoryWidget';
import DraggablePanel from './DraggablePanel';
import GeorgeWashingtonIcon from './icons/GeorgeWashingtonIcon';
import ExtrasModal from './ExtrasModal';
import { useClickOutside } from '../hooks/useClickOutside';
import { calculatePrice, generateInvoiceNote } from '../utils/pricing';

const JobsTable: React.FC = () => {
  const {
    jobs, deleteJobs, updateJob, addJob, t, // Added addJob
    focusDateRange, setFocusDateRange,
    viewMode, setJobsViewMode,
    addLog, setIsImporting, isImporting,
    employees,
    settings,
    clearAllData,
    appConfig
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [sortConfig, setSortConfig] = useState<{ key: keyof Job; direction: 'asc' | 'desc' } | null>({ key: 'date', direction: 'desc' });
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [isStagingOpen, setIsStagingOpen] = useState(false);

  // Local History State for Scoped Undo
  const [localHistory, setLocalHistory] = useState<JobHistoryAction[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const historyButtonRef = useRef<HTMLButtonElement>(null);
  const [historyPosition, setHistoryPosition] = useState({ x: 100, y: 100 });
  const [extrasModalJob, setExtrasModalJob] = useState<Job | null>(null);
  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const columnMenuRef = useRef<HTMLDivElement>(null);
  useClickOutside(columnMenuRef, () => setShowColumnMenu(false));
  const [showHidden, setShowHidden] = useState(false); // Toggle for Complete+Sent jobs

  // Advanced Filters State
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const filterMenuRef = useRef<HTMLDivElement>(null);
  useClickOutside(filterMenuRef, () => setShowFilterMenu(false));
  const [statusFilters, setStatusFilters] = useState<Set<string>>(new Set());
  const [employeeFilters, setEmployeeFilters] = useState<Set<string>>(new Set());

  const [visibleColumns, setVisibleColumns] = useState({
    property: true, apt: true, size: true, type: true, date: true,
    assignedTo: true, po: true, invoiceStatus: true, status: true,
    extras: true, notes: true, invoiceNote: true, clientPrice: true, employeePrice: true,
    total: true, invoiceNumber: true, isPrivate: true, actions: true
  });

  const toggleColumn = (col: string) => setVisibleColumns(prev => ({ ...prev, [col]: !prev[col as keyof typeof prev] }));

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  // Column Resizing State
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({
    property: 160, apt: 60, size: 60, type: 100, date: 90,
    assignedTo: 120, status: 100, invoiceStatus: 80, invoiceNumber: 80,
    extras: 150, notes: 120, invoiceNote: 120, clientPrice: 80, employeePrice: 80,
    total: 80, isPrivate: 40
  });
  const resizingRef = useRef<{ col: string, startX: number, startWidth: number } | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!resizingRef.current) return;
      const { col, startX, startWidth } = resizingRef.current;
      const diff = e.clientX - startX;
      setColumnWidths(prev => ({
        ...prev,
        [col]: Math.max(40, startWidth + diff) // Min width 40px
      }));
    };

    const handleMouseUp = () => {
      if (resizingRef.current) {
        resizingRef.current = null;
        document.body.style.cursor = 'default';
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  const startResizing = (e: React.MouseEvent, col: string) => {
    e.preventDefault();
    e.stopPropagation();
    resizingRef.current = { col, startX: e.clientX, startWidth: columnWidths[col] || 100 };
    document.body.style.cursor = 'col-resize';
  };

  // We need importJobs from context
  const { importJobs } = useApp();

  // --- HISTORY HELPERS ---
  const addToHistory = (action: JobHistoryAction) => {
    setLocalHistory(prev => [action, ...prev]);
  };

  const handleUndo = (action: JobHistoryAction) => {
    // 1. Revert CREATE -> Delete
    if (action.type === 'CREATE' && action.jobId) {
      deleteJobs([action.jobId]);
    }
    // 2. Revert DELETE -> Restore (Add back)
    else if (action.type === 'DELETE' && action.previousData) {
      // previousData is array of jobs
      const jobsToRestore = action.previousData as Job[];
      // We don't have a bulk add, so loop (or use importJobs if it supports it without date range)
      // importJobs adds to global history too, which is fine, but we want to restore them.
      // Let's use importJobs for bulk restore
      importJobs(jobsToRestore, null);
    }
    // 3. Revert UPDATE -> Restore old values
    else if ((action.type === 'UPDATE_STATUS' || action.type === 'UPDATE_PRICE' || action.type === 'UPDATE_EXTRAS') && action.jobId && action.previousData) {
      updateJob(action.jobId, action.previousData);
    }
    else if (action.type === 'DELETE_ALL' && action.previousData) {
      // previousData is array of all jobs
      const jobsToRestore = action.previousData as Job[];
      importJobs(jobsToRestore, null);
    }

    // Remove from local history
    setLocalHistory(prev => prev.filter(a => a.id !== action.id));

    addLog({
      id: generateId(),
      timestamp: new Date().toISOString(),
      type: 'info',
      message: `Undid action: ${action.description}`
    });
  };

  // --- ACTIONS WRAPPERS ---

  const handleAddJob = () => {
    const newJob: Job = {
      id: generateId(),
      date: new Date().toISOString(),
      property: 'New Property',
      apt: 'Unit',
      type: 'Clean',
      size: '1x1',
      assignedTo: '',
      status: 'Pending',
      invoiceStatus: 'None',
      clientPrice: 0,
      employeePrice: 0,
      extrasPrice: 0,
      notes: '',
      extras: '',
      invoiceNote: ''
    };

    addJob(newJob);

    addToHistory({
      id: generateId(),
      timestamp: Date.now(),
      type: 'CREATE',
      description: 'Created New Job',
      jobId: newJob.id,
      user: 'You'
    });

    // Optionally open edit modal immediately
    setEditingJobId(newJob.id);
  };

  const handleStatusChange = (id: string, newStatus: Job['status']) => {
    const job = jobs.find(j => j.id === id);
    if (!job) return;

    const oldStatus = job.status;
    updateJob(id, { status: newStatus });

    addToHistory({
      id: generateId(),
      timestamp: Date.now(),
      type: 'UPDATE_STATUS',
      description: `Changed status to ${newStatus}`,
      jobId: id,
      previousData: { status: oldStatus },
      user: 'You'
    });
  };

  const handleInvoiceStatusChange = (id: string, newStatus: Job['invoiceStatus']) => {
    const job = jobs.find(j => j.id === id);
    if (!job) return;

    const oldStatus = job.invoiceStatus;
    updateJob(id, { invoiceStatus: newStatus });

    addToHistory({
      id: generateId(),
      timestamp: Date.now(),
      type: 'UPDATE_STATUS',
      description: `Changed invoice status to ${newStatus}`,
      jobId: id,
      previousData: { invoiceStatus: oldStatus },
      user: 'You'
    });
  };

  const handleSaveExtras = (jobId: string, summary: string, total: number) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    const oldData = { extras: job.extras, extrasPrice: job.extrasPrice, invoiceNote: job.invoiceNote };
    const newInvoiceNote = generateInvoiceNote(job, summary);

    updateJob(jobId, { extras: summary, extrasPrice: total, invoiceNote: newInvoiceNote });

    addToHistory({
      id: generateId(),
      timestamp: Date.now(),
      type: 'UPDATE_EXTRAS',
      description: 'Updated Extras',
      jobId: jobId,
      previousData: oldData,
      user: 'You'
    });
  };

  const handleClearAllJobs = () => {
    if (confirm('Are you sure you want to DELETE ALL jobs? This cannot be undone easily.')) {
      const allJobs = [...jobs];
      const ids = jobs.map(j => j.id);
      deleteJobs(ids);
      setSelectedIds(new Set());
      addToHistory({ id: generateId(), timestamp: Date.now(), type: 'DELETE_ALL', description: `Deleted ALL ${allJobs.length} jobs`, previousData: allJobs, user: 'You' });
    }
  };

  const handleDeleteSelected = () => {
    if (confirm(`Delete ${selectedIds.size} jobs?`)) {
      const ids = Array.from(selectedIds);
      const jobsToDelete = jobs.filter(j => ids.includes(j.id));
      deleteJobs(ids);
      setSelectedIds(new Set());

      addToHistory({
        id: generateId(),
        timestamp: Date.now(),
        type: 'DELETE',
        description: `Deleted ${ids.length} jobs`,
        previousData: jobsToDelete,
        user: 'You'
      });
    }
  };

  const [duplicateModalOpen, setDuplicateModalOpen] = useState(false);
  const [pendingDuplicates, setPendingDuplicates] = useState<{ existing: Job; new: Job }[]>([]);
  const [pendingNonDuplicates, setPendingNonDuplicates] = useState<Job[]>([]);
  const [pendingDateRange, setPendingDateRange] = useState<{ start: Date; end: Date } | null>(null);

  const onFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsImporting(true);
    let allParsedJobs: Job[] = [];
    let allLogs: any[] = [];
    let combinedDateRange: { start: Date; end: Date } | null = null;

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.name.match(/\.(xlsx|xls|csv)$/i)) continue;

        const parsedResult = await parseFile(file, jobs, appConfig);
        const { jobs: parsedJobs, logs: fileLogs, dateRange } = parsedResult;

        allParsedJobs = [...allParsedJobs, ...parsedJobs];
        allLogs = [...allLogs, ...fileLogs];

        if (dateRange) {
          if (!combinedDateRange) combinedDateRange = dateRange;
          else {
            // Expand range if needed
            if (dateRange.start < combinedDateRange.start) combinedDateRange.start = dateRange.start;
            if (dateRange.end > combinedDateRange.end) combinedDateRange.end = dateRange.end;
          }
        }
      }

      // Add logs immediately
      allLogs.forEach(log => addLog(log));

      if (allParsedJobs.length === 0) {
        alert('No valid jobs found in selected files.');
        setIsImporting(false);
        e.target.value = '';
        return;
      }

      // CHECK FOR DUPLICATES
      const duplicates: { existing: Job; new: Job }[] = [];
      const nonDuplicates: Job[] = [];

      allParsedJobs.forEach(newJob => {
        // Definition of Duplicate: Same Property, Unit, Type, Date
        // (Ignoring ID since new job has generated ID)
        const existing = jobs.find(j =>
          j.property === newJob.property &&
          j.apt === newJob.apt &&
          j.type === newJob.type &&
          j.date === newJob.date
        );

        if (existing) {
          duplicates.push({ existing, new: newJob });
        } else {
          nonDuplicates.push(newJob);
        }
      });

      if (duplicates.length > 0) {
        // Open Modal
        setPendingDuplicates(duplicates);
        setPendingNonDuplicates(nonDuplicates);
        setPendingDateRange(combinedDateRange);
        setDuplicateModalOpen(true);
      } else {
        // No duplicates, import all immediately
        importJobs(nonDuplicates, combinedDateRange);
        alert(`Successfully imported ${nonDuplicates.length} jobs!`);
        if (combinedDateRange) {
          setFocusDateRange(combinedDateRange);
          setJobsViewMode('DATE_FILTERED');
        }
      }

    } catch (error: any) {
      console.error(error);
      addLog({
        id: generateId(),
        timestamp: new Date().toISOString(),
        type: 'error',
        message: 'Import failed',
        detail: error instanceof Error ? error.message : String(error)
      });
      alert('Import failed. Check logs.');
    } finally {
      if (pendingDuplicates.length === 0) {
        setIsImporting(false);
        e.target.value = '';
      }
      // If duplicates found, we keep isImporting true until modal resolves? 
      // Actually better to reset loading state, modal handles the rest.
      setIsImporting(false);
      // Don't clear value yet if we might need to re-trigger? No, value clear is fine.
      e.target.value = '';
    }
  };

  const handleDuplicateResolution = (resolutions: { [key: string]: 'skip' | 'overwrite' | 'keep_both' }) => {
    const finalJobsToImport = [...pendingNonDuplicates];
    const jobsToUpdate: Job[] = [];

    pendingDuplicates.forEach(d => {
      const action = resolutions[d.new.id];
      if (action === 'keep_both') {
        finalJobsToImport.push(d.new);
      } else if (action === 'overwrite') {
        // We need to update the EXISTING job with NEW data
        // But keep the ID of the existing job
        const updatedJob = { ...d.new, id: d.existing.id };
        jobsToUpdate.push(updatedJob);
      }
      // if 'skip', do nothing
    });

    // 1. Import New Jobs
    if (finalJobsToImport.length > 0) {
      importJobs(finalJobsToImport, null); // Don't reset range yet
    }

    // 2. Update Overwritten Jobs
    jobsToUpdate.forEach(j => {
      updateJob(j.id, j);
    });

    // 3. Navigate
    if (pendingDateRange) {
      setFocusDateRange(pendingDateRange);
      setJobsViewMode('DATE_FILTERED');
    }

    const totalProcessed = finalJobsToImport.length + jobsToUpdate.length;
    alert(`Import complete! Added ${finalJobsToImport.length}, Updated ${jobsToUpdate.length}.`);

    setDuplicateModalOpen(false);
    setPendingDuplicates([]);
    setPendingNonDuplicates([]);
    setPendingDateRange(null);
  };

  // --- DUPLICATE DETECTION (Persistent) ---
  const duplicateCount = useMemo(() => {
    // Check entire jobs list for duplicates
    // Definition: Same Property, Unit, Type, Date
    // We need to find groups > 1
    const signatures = jobs.map(j => `${j.property}|${j.apt}|${j.type}|${j.date}`);
    const counts: { [key: string]: number } = {};
    signatures.forEach(s => counts[s] = (counts[s] || 0) + 1);
    return Object.values(counts).filter(c => c > 1).reduce((sum, c) => sum + c, 0);
  }, [jobs]);

  const [showDuplicatesOnly, setShowDuplicatesOnly] = useState(false);

  const handleShowDuplicates = () => {
    setShowDuplicatesOnly(true);
  };

  // --- FILTER LOGIC ---
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // 0. Duplicates Filter (Highest Priority)
      if (showDuplicatesOnly) {
        const sig = `${job.property}|${job.apt}|${job.type}|${job.date}`;
        const count = jobs.filter(j => `${j.property}|${j.apt}|${j.type}|${j.date}` === sig).length;
        return count > 1;
      }

      // 1. Search Filter (Global Priority)
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        return Object.entries(job).some(([key, value]) => {
          // 1. Standard Check (includes raw date string like "2023-12-01")
          if (String(value).toLowerCase().includes(term)) return true;

          // 2. Enhanced Date Check (matches "Dec", "December", "Dec 25")
          if (key === 'date' && typeof value === 'string') {
            const d = new Date(value);
            if (!isNaN(d.getTime())) {
              const formats = [
                d.toLocaleDateString('en-US', { month: 'short' }), // "Dec"
                d.toLocaleDateString('en-US', { month: 'long' }),  // "December"
                d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }), // "Dec 1, 2023"
                d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })   // "December 1, 2023"
              ];
              return formats.some(f => f.toLowerCase().includes(term));
            }
          }
          return false;
        });
      }

      // 2. View Mode Filter (Only if no search)
      let matchesMode = true;

      switch (viewMode) {
        case 'DATE_FILTERED':
          // Standard behavior: Filter by date
          if (focusDateRange) {
            const jobDate = new Date(job.date);
            const start = new Date(focusDateRange.start);
            start.setHours(0, 0, 0, 0);
            const end = new Date(focusDateRange.end);
            end.setHours(23, 59, 59, 999);
            matchesMode = jobDate >= start && jobDate <= end;
          }
          break;
        case 'VIEW_ALL':
          matchesMode = true;
          break;
        case 'READY_TO_BILL':
          // Status Complete AND Invoice None/Draft
          matchesMode = job.status === 'Complete' && job.invoiceStatus !== 'Sent';
          break;
        case 'OPEN_JOBS':
          // User wants "Open" to mean "Not fully processed".
          // So we include Complete jobs here. They will only disappear if they become "Complete + Sent" (handled by global filter).
          matchesMode = job.status !== 'Paid' && job.status !== 'Cancel';
          break;
      }

      if (!matchesMode) return false;

      // GLOBAL DATE FILTER (If "Everywhere" is enabled and a range is selected)
      // This applies ON TOP of the specific view mode (e.g. "Open Jobs" in "December")
      if (settings.dateDialVisibility === 'everywhere' && focusDateRange && viewMode !== 'DATE_FILTERED') {
        const jobDate = new Date(job.date);
        const start = new Date(focusDateRange.start);
        start.setHours(0, 0, 0, 0);
        const end = new Date(focusDateRange.end);
        end.setHours(23, 59, 59, 999);
        if (!(jobDate >= start && jobDate <= end)) {
          return false;
        }
      }

      // 3. Hide Complete + Sent (unless showHidden is true)
      if (!showHidden && !searchTerm) {
        if (job.status === 'Complete' && job.invoiceStatus === 'Sent') {
          return false;
        }
      }

      // 4. Advanced Filters (Status & Employee)
      if (statusFilters.size > 0 && !statusFilters.has(job.status)) {
        return false;
      }
      if (employeeFilters.size > 0 && !employeeFilters.has(job.assignedTo)) {
        return false;
      }

      return true;
    });
  }, [jobs, searchTerm, viewMode, focusDateRange, settings.dateDialVisibility, showDuplicatesOnly, showHidden, statusFilters, employeeFilters]);

  // AUTO-SORT EFFECT: Enforce Date Ascending when Date Range Changes
  useEffect(() => {
    if (focusDateRange && (viewMode === 'DATE_FILTERED' || settings.dateDialVisibility === 'everywhere')) {
      setSortConfig({ key: 'date', direction: 'asc' });
    }
  }, [focusDateRange, viewMode, settings.dateDialVisibility]);

  // Sort Logic
  const sortedJobs = useMemo(() => {
    let sortableItems = [...filteredJobs];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        // 1. Primary Sort
        let comparison = 0;

        if (aValue === bValue) {
          comparison = 0;
        } else if (aValue === undefined || aValue === null) {
          comparison = 1; // Move nulls to bottom
        } else if (bValue === undefined || bValue === null) {
          comparison = -1;
        } else if (typeof aValue === 'string' && typeof bValue === 'string') {
          // Use natural sort for strings (handles "Unit 1" vs "Unit 10" correctly)
          comparison = aValue.localeCompare(bValue, undefined, { numeric: true, sensitivity: 'base' });
        } else if (aValue < bValue) {
          comparison = -1;
        } else if (aValue > bValue) {
          comparison = 1;
        }

        // Apply Direction
        if (comparison !== 0) {
          return sortConfig.direction === 'asc' ? comparison : -comparison;
        }
      });
    }
    return sortableItems;
  }, [filteredJobs, sortConfig]);

  // Pagination Logic
  const totalPages = Math.ceil(sortedJobs.length / itemsPerPage);
  const paginatedJobs = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedJobs.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedJobs, currentPage]);

  const requestSort = (key: keyof Job) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const toggleSelection = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedJobs.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginatedJobs.map(j => j.id)));
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Complete': return 'bg-emerald-200 text-emerald-900 border-emerald-300 font-bold'; // Higher contrast
      case 'In Progress': return 'bg-blue-200 text-blue-900 border-blue-300 font-bold';
      case 'Pending': return 'bg-slate-200 text-slate-700 border-slate-300 font-bold';
      case 'Paid': return 'bg-purple-200 text-purple-900 border-purple-300 font-bold';
      case 'Cancel': return 'bg-red-100 text-red-700 border-red-200 line-through font-bold';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  // Helper to get row background color
  const getRowStyle = (job: Job) => {
    // 1. Green Line Rule: Complete + Sent = Green
    if (job.status === 'Complete' && job.invoiceStatus === 'Sent') {
      return { backgroundColor: '#bbf7d0' }; // emerald-200 (Higher Contrast)
    }

    // 2. Employee Color Rule
    if (job.assignedTo) {
      const emp = employees.find(e => e.name === job.assignedTo);
      if (emp && emp.color) {
        // Create a very light version of the color (approx 10% opacity)
        // Since we have hex, we can use a style with opacity or rgba
        return { backgroundColor: `${emp.color}15` }; // Hex + 15 alpha ~ 8% opacity
      }
    }

    return {};
  };

  // Calculate Totals
  const totals = useMemo(() => {
    return filteredJobs.reduce((acc, job) => ({
      client: acc.client + (job.clientPrice || 0),
      employee: acc.employee + (job.employeePrice || 0),
      count: acc.count + 1
    }), { client: 0, employee: 0, count: 0 });
  }, [filteredJobs]);

  const selectedTotals = useMemo(() => {
    const selected = jobs.filter(j => selectedIds.has(j.id));
    return selected.reduce((acc, job) => ({
      client: acc.client + (job.clientPrice || 0),
      employee: acc.employee + (job.employeePrice || 0),
      count: acc.count + 1
    }), { client: 0, employee: 0, count: 0 });
  }, [jobs, selectedIds]);

  // Counts for Tabs
  const readyToBillCount = useMemo(() => {
    // Count jobs that match READY_TO_BILL criteria within current date range (if filtered)
    // Or globally? Usually tabs show global or filtered counts. Let's stick to filtered for consistency.
    return jobs.filter(j => j.status === 'Complete' && j.invoiceStatus !== 'Sent').length;
  }, [jobs]);

  return (
    <div className="flex flex-row h-full bg-slate-50 relative overflow-hidden">

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* DATE DIAL HEADER (Visible if DATE_FILTERED or set to Everywhere) */}
        {(viewMode === 'DATE_FILTERED' || settings.dateDialVisibility === 'everywhere') && (
          <DateHeader
            currentRange={focusDateRange}
            onRangeChange={(range) => {
              setFocusDateRange(range);
              // If we are in "View All" but change the date, switch to Date Filtered to avoid confusion
              if (viewMode === 'VIEW_ALL') {
                setJobsViewMode('DATE_FILTERED');
              }
              // AUTO-SORT: When using the Date Dial (especially Day/Timeline view), 
              // we want the selected date to be the FIRST thing seen.
              // So we enforce Date Ascending sort.
              // We use a timeout to ensure this happens after any other state updates.
              // setTimeout(() => {
              //   setSortConfig({ key: 'date', direction: 'asc' });
              // }, 0);
            }}
            onClear={() => {
              setFocusDateRange(undefined);
              if (settings.dateDialVisibility !== 'everywhere') {
                setJobsViewMode('VIEW_ALL');
              }
            }}
            hasActiveFilter={!!focusDateRange}
          />
        )}

        {/* Force Sort on Date Range Change */}
        {/* This ensures that when the user picks a date, we ALWAYS start by showing that date at the top */}
        {useMemo(() => {
          if (focusDateRange && (viewMode === 'DATE_FILTERED' || settings.dateDialVisibility === 'everywhere')) {
            // We can't call setState in render, so we use a micro-effect here or just rely on the callback.
            // Actually, let's use a useEffect for this specific behavior to be robust.
          }
          return null;
        }, [focusDateRange, viewMode, settings.dateDialVisibility])}

        {/* DUPLICATE WARNING BANNER (Mocked for now based on screenshot idea) */}
        {/* In a real scenario, we'd check for actual duplicates */}
        {false && (
          <div className="bg-orange-50 border-b border-orange-200 p-3 flex items-center justify-between text-orange-800 text-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle size={16} className="text-orange-600" />
              <div>
                <span className="font-bold">342 Potential Duplicates Found</span>
                <span className="ml-2 opacity-80">Some jobs have same unit + service within 14 days.</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="bg-orange-100 hover:bg-orange-200 text-orange-800 px-3 py-1 rounded font-bold transition-colors">Resolve</button>
              <button className="bg-white border border-orange-200 hover:bg-orange-50 text-orange-800 px-3 py-1 rounded font-bold transition-colors">Show All (Ignore)</button>
            </div>
          </div>
        )}

        {/* CONTACTS & PORTALS (Search on Top) */}
        <div className="px-2 pt-2">
          <ContactsPortals />
        </div>

        {/* DUPLICATE RESOLUTION MODAL */}
        <DuplicateResolutionModal
          isOpen={duplicateModalOpen}
          onClose={() => {
            setDuplicateModalOpen(false);
            setPendingDuplicates([]);
            setPendingNonDuplicates([]);
            setPendingDateRange(null);
          }}
          duplicates={pendingDuplicates}
          onResolve={handleDuplicateResolution}
        />



        <div className="bg-white border-b border-slate-200 p-2 flex flex-col md:flex-row gap-4 justify-between items-center shrink-0 shadow-sm z-20">

          {/* LEFT: Tabs & Actions */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full md:w-auto">
            {/* DUPLICATE WARNING */}
            {duplicateCount > 0 && (
              <button
                onClick={handleShowDuplicates}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${showDuplicatesOnly ? 'bg-orange-100 text-orange-700 border-orange-300 ring-2 ring-orange-200' : 'bg-orange-50 text-orange-600 border-orange-200 hover:bg-orange-100'}`}
              >
                <AlertTriangle size={14} />
                <span>{duplicateCount} Duplicates Found</span>
                {showDuplicatesOnly && <X size={12} onClick={(e) => { e.stopPropagation(); setShowDuplicatesOnly(false); }} className="ml-1 hover:bg-orange-200 rounded" />}
              </button>
            )}

            <div className="flex bg-slate-100 p-1 rounded-lg shrink-0">
              <button
                onClick={handleAddJob}
                className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded-md text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm whitespace-nowrap"
              >
                <Plus size={14} />
                New Job
              </button>

              <div className="h-6 w-px bg-slate-200 mx-1"></div>

              {/* Tabs */}
              <button
                onClick={() => setJobsViewMode('OPEN_JOBS')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'OPEN_JOBS' ? 'bg-slate-100 text-slate-800 border border-slate-200' : 'text-slate-500 hover:bg-slate-50'
                  }`}
              >
                <Briefcase size={14} />
                Open Jobs
              </button>

              <button
                onClick={() => setJobsViewMode('READY_TO_BILL')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'READY_TO_BILL' ? 'bg-red-50 text-red-700 border border-red-100' : 'text-slate-500 hover:bg-slate-50'
                  }`}
              >
                <CheckCircle size={14} />
                Ready to Bill
                <span className="bg-red-100 text-red-700 px-1.5 rounded-full text-[10px] font-bold">{readyToBillCount}</span>
              </button>

              <div className="h-6 w-px bg-slate-200 mx-1"></div>

            </div>


            {/* CENTER: Icon Actions (Static, No Scroll to prevent clipping) */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => {
                  if (selectedIds.size === 1) {
                    setEditingJobId(Array.from(selectedIds)[0]);
                  } else if (selectedIds.size === 0) {
                    alert('Please select a job to edit.');
                  } else {
                    alert('Please select only one job to edit.');
                  }
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"
                title="Edit Selected Job"
              >
                <Edit2 size={14} />
              </button>
              {/* Filter Menu */}
              <div className="relative" ref={filterMenuRef}>
                <button
                  onClick={() => setShowFilterMenu(!showFilterMenu)}
                  className={`p-1.5 rounded transition-colors ${showFilterMenu || statusFilters.size > 0 || employeeFilters.size > 0 ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                  title="Sort & Filter"
                >
                  <ListFilter size={14} />
                </button>
                {showFilterMenu && (
                  <div className="absolute top-full left-0 mt-1 w-56 bg-white rounded-lg shadow-xl border border-slate-200 z-50 p-3 max-h-[80vh] overflow-y-auto">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs font-bold text-slate-500">SORT & FILTER</span>
                      {(statusFilters.size > 0 || employeeFilters.size > 0) && (
                        <button
                          onClick={() => { setStatusFilters(new Set()); setEmployeeFilters(new Set()); }}
                          className="text-[10px] text-red-500 hover:text-red-700 font-bold"
                        >
                          Clear Filters
                        </button>
                      )}
                    </div>

                    {/* Sort Section */}
                    <div className="mb-3 pb-3 border-b border-slate-100">
                      <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase">Sort By</div>
                      <div className="grid grid-cols-2 gap-1">
                        {[
                          { k: 'date', l: 'Date' }, { k: 'property', l: 'Property' },
                          { k: 'apt', l: 'Unit' }, { k: 'status', l: 'Status' },
                          { k: 'assignedTo', l: 'Tech' }, { k: 'invoiceNumber', l: 'Inv #' }
                        ].map(opt => (
                          <button
                            key={opt.k}
                            onClick={() => requestSort(opt.k as keyof Job)}
                            className={`px-2 py-1 text-xs text-left rounded ${sortConfig?.key === opt.k ? 'bg-blue-100 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}
                          >
                            {opt.l} {sortConfig?.key === opt.k && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Status Filters */}
                    <div className="mb-3">
                      <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase">Status</div>
                      {['Pending', 'In Progress', 'Complete', 'Paid', 'Cancel'].map(status => (
                        <label key={status} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                          <input
                            type="checkbox"
                            checked={statusFilters.has(status)}
                            onChange={() => {
                              const newSet = new Set(statusFilters);
                              if (newSet.has(status)) newSet.delete(status);
                              else newSet.add(status);
                              setStatusFilters(newSet);
                            }}
                            className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3"
                          />
                          <span className="text-xs">{status}</span>
                        </label>
                      ))}
                    </div>

                    {/* Employee Filters */}
                    <div>
                      <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase">Tech</div>
                      {employees.map(emp => (
                        <label key={emp.id} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                          <input
                            type="checkbox"
                            checked={employeeFilters.has(emp.name)}
                            onChange={() => {
                              const newSet = new Set(employeeFilters);
                              if (newSet.has(emp.name)) newSet.delete(emp.name);
                              else newSet.add(emp.name);
                              setEmployeeFilters(newSet);
                            }}
                            className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3"
                          />
                          <span className="text-xs">{emp.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Column Selector */}
              <div className="relative" ref={columnMenuRef}>
                <button onClick={() => setShowColumnMenu(!showColumnMenu)} className={`p-1.5 rounded transition-colors ${showColumnMenu ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`} title="Columns"><Layers size={14} /></button>
                {showColumnMenu && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-xl border border-slate-200 z-50 p-2 max-h-[80vh] overflow-y-auto">
                    <div className="text-xs font-bold text-slate-500 mb-2 px-1">VISIBLE COLUMNS</div>
                    {[
                      { k: 'property', l: 'Property' }, { k: 'apt', l: 'Apt' }, { k: 'size', l: 'Size' }, { k: 'type', l: 'Job Type' },
                      { k: 'date', l: 'Date' }, { k: 'assignedTo', l: 'Assigned' }, { k: 'po', l: 'PO' }, { k: 'invoiceStatus', l: 'Draft/Sent' },
                      { k: 'status', l: 'Status' }, { k: 'extras', l: 'Extras' }, { k: 'notes', l: 'Notes' }, { k: 'invoiceNote', l: 'Inv. Note' },
                      { k: 'clientPrice', l: 'Price (Client)' }, { k: 'employeePrice', l: 'Pay (Emp)' }, { k: 'total', l: 'Total' }, { k: 'invoiceNumber', l: 'Invoice' }
                    ].map(col => (
                      <label key={col.k} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                        <input type="checkbox" checked={visibleColumns[col.k as keyof typeof visibleColumns]} onChange={() => toggleColumn(col.k)} className="rounded text-blue-600 focus:ring-blue-500" />
                        <span className="text-xs">{col.l}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* History Toggle (Hourglass) */}
              <button
                ref={historyButtonRef}
                onClick={() => {
                  if (!showHistory && historyButtonRef.current) {
                    const rect = historyButtonRef.current.getBoundingClientRect();
                    // Anchor to bottom-right of button, offset slightly
                    setHistoryPosition({
                      x: Math.max(10, rect.right - 320), // Align right edge, but keep on screen
                      y: rect.bottom + 8
                    });
                  }
                  setShowHistory(!showHistory);
                }}
                className={`p-1.5 rounded transition-colors ${showHistory ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                title="Toggle History"
              >
                <Hourglass size={14} />
              </button>

              {/* Show/Hide Completed+Sent Toggle */}
              <button
                onClick={() => setShowHidden(!showHidden)}
                className={`p-1.5 rounded transition-colors ${showHidden ? 'bg-emerald-100 text-emerald-700' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                title={showHidden ? "Hide Completed & Sent Jobs" : "Show All (Including Completed & Sent)"}
              >
                {showHidden ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
            </div>


            {/* FLOATING HISTORY WIDGET */}
            {/* RIGHT: Search & Import */}
            <div className="flex items-center gap-3 w-full md:w-auto justify-end">

              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-48 pl-8 pr-3 py-1.5 text-xs rounded-md border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {/* Clear Jobs Button */}
              <button onClick={handleClearAllJobs} className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-white text-red-600 border border-red-200 hover:bg-red-50 hover:border-red-300 shadow-sm transition-colors" title="Clear All Jobs">
                <Trash2 size={14} />
                <span className="font-bold text-xs hidden sm:inline">Clear</span>
              </button>

              {/* Import Button */}
              <label className={`flex items-center gap-2 px-3 py-1.5 rounded-md cursor-pointer transition-all border ${isImporting ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white text-blue-600 border-blue-200 hover:bg-blue-50 hover:border-blue-300 shadow-sm'}`}>
                <FolderInput size={14} />
                <span className="font-bold text-xs hidden sm:inline">{isImporting ? 'Importing...' : 'Import Jobs'}</span>
                <input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  multiple
                  className="hidden"
                  onChange={onFileUpload}
                  disabled={isImporting}
                />
              </label>
            </div>
          </div>
        </div>

        {/* TABLE CONTAINER */}
        <div className="flex-1 overflow-auto relative">
          <table className="w-full text-xs text-left border-collapse table-fixed">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-3 w-8 border-b border-slate-200 text-center">#</th>
                <th className="p-3 w-8 border-b border-slate-200">
                  <button onClick={toggleSelectAll} className="flex items-center justify-center text-slate-400 hover:text-slate-600">
                    {selectedIds.size > 0 && selectedIds.size === paginatedJobs.length ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
                  </button>
                </th>
                {visibleColumns.property && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.property, minWidth: columnWidths.property }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('property')}>PROPERTY<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'property')} />
                </th>}
                {visibleColumns.apt && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.apt, minWidth: columnWidths.apt }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('apt')}>UNIT<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'apt')} />
                </th>}
                {visibleColumns.type && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.type, minWidth: columnWidths.type }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('type')}>SERVICE<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'type')} />
                </th>}
                {visibleColumns.size && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.size, minWidth: columnWidths.size }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('size')}>SIZE<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'size')} />
                </th>}
                {visibleColumns.date && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.date, minWidth: columnWidths.date }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('date')}>DATE<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'date')} />
                </th>}
                {visibleColumns.assignedTo && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.assignedTo, minWidth: columnWidths.assignedTo }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('assignedTo')}>TECH<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'assignedTo')} />
                </th>}
                {visibleColumns.status && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.status, minWidth: columnWidths.status }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('status')}>STATUS<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'status')} />
                </th>}
                {visibleColumns.invoiceStatus && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.invoiceStatus, minWidth: columnWidths.invoiceStatus }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('invoiceStatus')}>INV STATUS<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'invoiceStatus')} />
                </th>}
                {visibleColumns.invoiceNumber && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.invoiceNumber, minWidth: columnWidths.invoiceNumber }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('invoiceNumber')}>INV #<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'invoiceNumber')} />
                </th>}
                {visibleColumns.extras && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.extras, minWidth: columnWidths.extras }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('extras')}>EXTRAS<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'extras')} />
                </th>}
                {visibleColumns.notes && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.notes, minWidth: columnWidths.notes }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('notes')}>NOTES<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'notes')} />
                </th>}
                {visibleColumns.invoiceNote && <th className="p-3 border-b border-slate-200 relative group" style={{ width: columnWidths.invoiceNote, minWidth: columnWidths.invoiceNote }}>
                  <div className="flex items-center gap-1 cursor-pointer hover:bg-slate-100" onClick={() => requestSort('invoiceNote')}>INV. NOTE<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'invoiceNote')} />
                </th>}
                {visibleColumns.clientPrice && <th className="p-3 border-b border-slate-200 relative group text-right" style={{ width: columnWidths.clientPrice, minWidth: columnWidths.clientPrice }}>
                  <div className="flex items-center gap-1 justify-end cursor-pointer hover:bg-slate-100" onClick={() => requestSort('clientPrice')}>PRICE<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'clientPrice')} />
                </th>}
                {visibleColumns.employeePrice && <th className="p-3 border-b border-slate-200 relative group text-right" style={{ width: columnWidths.employeePrice, minWidth: columnWidths.employeePrice }}>
                  <div className="flex items-center gap-1 justify-end cursor-pointer hover:bg-slate-100" onClick={() => requestSort('employeePrice')}>PAY<ArrowUpDown size={10} className="text-slate-400" /></div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'employeePrice')} />
                </th>}
                {visibleColumns.total && <th className="p-3 border-b border-slate-200 relative group text-right" style={{ width: columnWidths.total, minWidth: columnWidths.total }}>
                  <div className="flex items-center gap-1 justify-end">TOTAL</div>
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'total')} />
                </th>}
                {visibleColumns.isPrivate && <th className="p-3 border-b border-slate-200 text-center relative group" style={{ width: columnWidths.isPrivate, minWidth: columnWidths.isPrivate }}>
                  <Crown size={14} className="mx-auto text-slate-400" />
                  <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" onMouseDown={(e) => startResizing(e, 'isPrivate')} />
                </th>}
                <th className="p-3 border-b border-slate-200 text-center">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {paginatedJobs.length === 0 ? (
                <tr>
                  <td colSpan={17} className="p-12 text-center text-slate-400 italic">
                    {viewMode === 'DATE_FILTERED' && focusDateRange
                      ? "No jobs found for the selected date range."
                      : "No jobs found matching your filters."}
                  </td>
                </tr>
              ) : (
                paginatedJobs.map((job, index) => (
                  <tr
                    key={job.id}
                    style={getRowStyle(job)}
                    className={`group transition-colors hover:brightness-95 ${selectedIds.has(job.id) ? 'bg-blue-50/50' :
                      job.isPrivate ? 'bg-purple-50 border-l-4 border-purple-500' : ''
                      }`}
                  >
                    <td className="p-3 text-center text-slate-400 font-mono text-[10px]">{(currentPage - 1) * itemsPerPage + index + 1}</td>
                    <td className="p-3">
                      <button onClick={() => toggleSelection(job.id)} className="flex items-center justify-center text-slate-300 hover:text-blue-500">
                        {selectedIds.has(job.id) ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
                      </button>
                    </td>
                    {visibleColumns.property && <td className="p-3 font-bold text-slate-700 truncate" style={{ width: columnWidths.property }} title={job.property}>{job.property}</td>}
                    {visibleColumns.apt && <td className="p-3 font-bold text-slate-800 truncate" style={{ width: columnWidths.apt }}>{job.apt}</td>}
                    {visibleColumns.size && <td className="p-3 text-slate-500 truncate" style={{ width: columnWidths.size }}>{job.size}</td>}
                    {visibleColumns.type && <td className="p-3 font-bold text-slate-600 uppercase text-[10px] truncate" style={{ width: columnWidths.type }}>{job.type}</td>}
                    {visibleColumns.date && <td className="p-3 font-mono text-slate-600 truncate" style={{ width: columnWidths.date }}>{formatDate(job.date)}</td>}
                    {visibleColumns.assignedTo && <td className="p-3" style={{ width: columnWidths.assignedTo }}>
                      {job.assignedTo && (
                        <div className="flex items-center gap-2 truncate">
                          <div
                            className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shadow-sm shrink-0"
                            style={{ backgroundColor: employees.find(e => e.name === job.assignedTo)?.color || '#cbd5e1' }}
                          >
                            {job.assignedTo.charAt(0)}
                          </div>
                          <span className="text-slate-700 font-medium truncate">{job.assignedTo}</span>
                        </div>
                      )}
                    </td>}
                    {visibleColumns.status && <td className="p-3" style={{ width: columnWidths.status }}>
                      <div className="flex items-center gap-1.5">
                        <div className={`w-2 h-2 rounded-full shrink-0 ${job.status === 'Complete' ? 'bg-emerald-500' :
                          job.status === 'In Progress' ? 'bg-blue-500' :
                            job.status === 'Pending' ? 'bg-slate-300' : 'bg-red-500'
                          }`}></div>
                        <select
                          value={job.status}
                          onChange={(e) => handleStatusChange(job.id, e.target.value as Job['status'])}
                          className="bg-transparent border-none text-slate-600 text-xs focus:ring-0 cursor-pointer truncate w-full"
                        >
                          <option value="Pending">Pending</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Complete">Complete</option>
                          <option value="Paid">Paid</option>
                          <option value="Cancel">Cancel</option>
                        </select>
                      </div>
                    </td>}
                    {visibleColumns.invoiceStatus && <td className="p-3" style={{ width: columnWidths.invoiceStatus }}>
                      <select
                        value={job.invoiceStatus}
                        onChange={(e) => handleInvoiceStatusChange(job.id, e.target.value as Job['invoiceStatus'])}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold border appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/20 w-full truncate ${job.invoiceStatus === 'Sent' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                          job.invoiceStatus === 'Draft' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                            'bg-slate-50 text-slate-400 border-slate-100'
                          }`}
                      >
                        <option value="None">-</option>
                        <option value="Draft">Draft</option>
                        <option value="Sent">Sent</option>
                      </select>
                    </td>}
                    {visibleColumns.invoiceNumber && <td className="p-3" style={{ width: columnWidths.invoiceNumber }}>
                      <input
                        type="text"
                        value={job.invoiceNumber || ''}
                        onChange={(e) => {
                          updateJob(job.id, { invoiceNumber: e.target.value });
                        }}
                        onBlur={(e) => {
                          const val = e.target.value.trim();
                          if (val !== (job.invoiceNumber || '')) {
                            updateJob(job.id, { invoiceNumber: val });
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.currentTarget.blur();
                          }
                        }}
                        className="bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none text-slate-600 font-mono text-xs py-0.5 transition-colors placeholder-slate-300 w-full"
                        placeholder="-"
                      />
                    </td>}
                    {visibleColumns.extras && <td className="p-3" style={{ width: columnWidths.extras }}>
                      <div className="flex items-center justify-between group/extras">
                        <span className="text-slate-600 truncate" title={job.extras}>{job.extras || '-'}</span>
                        <button onClick={() => setExtrasModalJob(job)} className="opacity-0 group-hover/extras:opacity-100 p-1 text-blue-500 hover:bg-blue-50 rounded transition-all shrink-0">
                          <Plus size={12} />
                        </button>
                      </div>
                    </td>}
                    {visibleColumns.notes && <td className="p-3 text-slate-500 italic truncate" style={{ width: columnWidths.notes }}>{job.notes}</td>}
                    {visibleColumns.invoiceNote && <td className="p-3 text-slate-500 text-[10px] truncate group/note relative" style={{ width: columnWidths.invoiceNote }}>
                      <div className="flex justify-between items-center">
                        <span title={job.invoiceNote} className="truncate">{job.invoiceNote}</span>
                        {job.invoiceNote && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigator.clipboard.writeText(job.invoiceNote || '');
                            }}
                            className="opacity-0 group-hover/note:opacity-100 p-1 text-blue-500 hover:bg-blue-50 rounded transition-all shrink-0"
                            title="Copy Invoice Note"
                          >
                            <FileText size={10} />
                          </button>
                        )}
                      </div>
                    </td>}
                    {visibleColumns.clientPrice && <td className="p-3 text-right font-mono text-slate-700 font-medium truncate" style={{ width: columnWidths.clientPrice }}>{formatCurrency(job.clientPrice)}</td>}
                    {visibleColumns.employeePrice && <td className="p-3 text-right font-mono text-slate-500 truncate" style={{ width: columnWidths.employeePrice }}>{formatCurrency(job.employeePrice)}</td>}
                    {visibleColumns.total && <td className="p-3 text-right font-mono text-slate-800 font-bold truncate" style={{ width: columnWidths.total }}>{formatCurrency((job.clientPrice || 0) + (job.extrasPrice || 0))}</td>}
                    {visibleColumns.isPrivate && <td className="p-3 text-center" style={{ width: columnWidths.isPrivate }}>
                      <button
                        onClick={() => updateJob(job.id, { isPrivate: !job.isPrivate })}
                        className={`p-1 rounded-full transition-colors ${job.isPrivate ? 'bg-purple-100 text-purple-600' : 'text-slate-300 hover:text-slate-400'}`}
                        title="Toggle Private/Direct Charge"
                      >
                        <Crown size={14} fill={job.isPrivate ? "currentColor" : "none"} />
                      </button>
                    </td>}
                    <td className="p-3 text-center">
                      <button
                        onClick={() => setEditingJobId(job.id)}
                        className="text-slate-400 hover:text-blue-600 transition-colors"
                      >
                        <MoreHorizontal size={14} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
              {/* Ghost Rows for Spacing */}
              {[...Array(5)].map((_, i) => (
                <tr key={`ghost-${i}`} className="h-10 border-b border-transparent">
                  <td colSpan={16}></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* STICKY FOOTER */}
        <div className="bg-white border-t border-slate-200 p-2 flex justify-between items-center shrink-0 text-[10px] text-slate-500 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-30">
          <div className="flex items-center gap-4">
            <span>Showing {paginatedJobs.length} of {filteredJobs.length} jobs</span>

            {/* Quick Stats */}
            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="flex items-center gap-1.5">
                <DollarSign size={12} className="text-emerald-500" />
                <span className="font-bold text-slate-700">{formatCurrency(selectedIds.size > 0 ? selectedTotals.client : totals.client)}</span>
                <span className="text-slate-400">REVENUE</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock size={12} className="text-orange-400" />
                <span className="font-bold text-slate-700">{formatCurrency(selectedIds.size > 0 ? selectedTotals.employee : totals.employee)}</span>
                <span className="text-slate-400">PAYROLL</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
            >
              <ChevronLeft size={14} />
            </button>
            <span className="font-medium">Page {currentPage} of {totalPages || 1}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Modals */}
        {
          editingJobId && (
            <JobEditModal
              isOpen={true}
              onClose={() => setEditingJobId(null)}
              jobId={editingJobId}
              onOpenExtras={(id) => setExtrasModalJob(jobs.find(j => j.id === id) || null)}
            />
          )
        }

        <ExtrasModal
          isOpen={!!extrasModalJob}
          onClose={() => setExtrasModalJob(null)}
          job={extrasModalJob}
          onSave={handleSaveExtras}
        />

        <InvoiceStagingModal
          isOpen={isStagingOpen}
          onClose={() => setIsStagingOpen(false)}
          selectedJobs={jobs.filter(j => selectedIds.has(j.id))}
        />
      </div>

      {/* FLOATING HISTORY WIDGET */}
      {
        showHistory && (
          <DraggablePanel
            title="History"
            onClose={() => setShowHistory(false)}
            initialPosition={historyPosition}
            onPositionChange={setHistoryPosition}
            className="max-h-[500px]"
          >
            <JobsHistoryWidget history={localHistory} onUndo={handleUndo} />
          </DraggablePanel>
        )
      }
    </div>
  );
};

export default JobsTable;