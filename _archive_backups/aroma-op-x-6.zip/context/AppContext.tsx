
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppState, Job, Employee, Property, PriceTable, AppContextType, PricingOverride, PriceConfig, QuickLink, ActionLog, JobsViewMode, LogEntry, ApiConfig, Task, AppConfig } from '../types';
import { DEFAULT_EMPLOYEES, DEFAULT_PRICES, DEFAULT_PROPERTY_CONTACTS, DEFAULT_PORTAL_URLS, DEFAULT_PRICING_DATA, DEFAULT_QUICK_LINKS, APP_VERSION, TRANSLATIONS, APP_CONFIG } from '../constants';
import { generateId } from '../utils/helpers';
import { getStartOfMonth, getEndOfMonth } from '../utils/dateUtils';

const STORAGE_KEY = 'aroma_ops_data_v2';

const defaultState: AppState = {
  version: APP_VERSION,
  activeYear: new Date().getFullYear(),
  jobs: [],
  employees: DEFAULT_EMPLOYEES,
  properties: DEFAULT_PROPERTY_CONTACTS,
  prices: DEFAULT_PRICES, // Legacy
  pricingData: DEFAULT_PRICING_DATA, // New Brain
  appConfig: APP_CONFIG as AppConfig, // NEW CENTRALIZED CONFIG
  quickLinks: DEFAULT_QUICK_LINKS,
  settings: {
    employeeInvoiceEmail: 'aromacleaning22@gmail.com',
    companyName: 'Aroma Cleaning & Painting',
    language: 'en',
    dateDialVisibility: 'dashboard_only', // Default
    enableDebugConsole: false // Default OFF (Hidden)
  },
  portals: DEFAULT_PORTAL_URLS,
  lists: {
    jobTypes: ['Paint', 'Clean', 'Touch Up Paint', 'Touch Up Clean'],
    sizes: ['1x1', '2x2', '3x2', 'Studio']
  },
  tasks: [],
  prepaidUnits: {},
  history: [], // Init empty history
  systemLogs: [], // Init empty logs
  isImporting: false, // Init importing state
  viewMode: 'DATE_FILTERED', // Default view mode
  lastNonDuplicateMode: 'DATE_FILTERED', // Default fallback
  apiConfigs: [],
  focusDateRange: {
    start: getStartOfMonth(new Date()),
    end: getEndOfMonth(new Date())
  },
  dateViewUnit: 'week' // Default
};

export const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(defaultState);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from local storage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setState({
          ...defaultState,
          ...parsed,
          version: APP_VERSION, // Always force current code version
          // Merge nested objects to prevent data loss on new fields
          pricingData: parsed.pricingData || DEFAULT_PRICING_DATA,
          appConfig: parsed.appConfig || APP_CONFIG, // Load or Default
          quickLinks: parsed.quickLinks || DEFAULT_QUICK_LINKS,
          tasks: parsed.tasks || [],
          prepaidUnits: parsed.prepaidUnits || {},
          history: parsed.history || [],
          settings: { ...defaultState.settings, ...parsed.settings },
          lists: { ...defaultState.lists, ...parsed.lists },
          portals: { ...defaultState.portals, ...(parsed.portals || {}) },
          properties: (parsed.properties || DEFAULT_PROPERTY_CONTACTS).map((p: any) => {
            let logic = p.billingLogic;
            if (!logic) {
              if (p.name === 'Sur Club') logic = 'combined';
              else logic = 'independent';
            }
            return { ...p, billingLogic: logic };
          }),
          // Ensure dateViewUnit exists if loading old state
          dateViewUnit: parsed.dateViewUnit || 'week'
        });
      }
    } catch (e) {
      console.error("Failed to load state", e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  // Save to local storage
  useEffect(() => {
    if (isLoaded) {
      const { focusDateRange, ...storageState } = state;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(storageState));
    }
  }, [state, isLoaded]);

  // TRANSLATION HELPER
  const t = (key: string): string => {
    const lang = state.settings.language || 'en';
    const dict = TRANSLATIONS[lang] || TRANSLATIONS['en'];
    return (dict as any)[key] || key;
  };

  // --- HISTORY HELPER ---
  const addToHistory = (prevHistory: ActionLog[], log: ActionLog): ActionLog[] => {
    // Keep last 20 actions
    return [log, ...prevHistory].slice(0, 20);
  };

  const addJob = (job: Job) => {
    setState(prev => {
      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'CREATE',
        description: `Created Job: ${job.property} ${job.apt}`,
        currentDataId: job.id
      };
      return {
        ...prev,
        jobs: [...prev.jobs, job],
        history: addToHistory(prev.history, log)
      };
    });
  };

  const updateJob = (id: string, updates: Partial<Job>) => {
    setState(prev => {
      const oldJob = prev.jobs.find(j => j.id === id);
      if (!oldJob) return prev;

      // Only log if something actually changed (shallow comparison for simplicity)
      // This prevents spamming logs if updates are identical
      const hasChanges = Object.keys(updates).some(k => (oldJob as any)[k] !== (updates as any)[k]);

      let newHistory = prev.history;

      if (hasChanges) {
        const log: ActionLog = {
          id: generateId(),
          timestamp: Date.now(),
          type: 'UPDATE',
          description: `Updated ${oldJob.property} ${oldJob.apt}`,
          previousData: oldJob
        };
        newHistory = addToHistory(prev.history, log);
      }

      return {
        ...prev,
        jobs: prev.jobs.map(j => j.id === id ? { ...j, ...updates } : j),
        history: newHistory
      };
    });
  };

  const deleteJobs = (ids: string[]) => {
    setState(prev => {
      const deletedJobs = prev.jobs.filter(j => ids.includes(j.id));
      if (deletedJobs.length === 0) return prev;

      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'DELETE',
        description: `Deleted ${ids.length} Job(s)`,
        previousData: deletedJobs // Store array of jobs to restore
      };

      return {
        ...prev,
        jobs: prev.jobs.filter(j => !ids.includes(j.id)),
        history: addToHistory(prev.history, log)
      };
    });
  };

  const importJobs = (newJobs: Job[], dateRange?: { start: Date; end: Date } | null) => {
    setState(prev => {
      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'IMPORT',
        description: `Imported ${newJobs.length} Jobs`,
        currentDataId: newJobs.map(j => j.id) // Track IDs to potentially undo import
      };

      return {
        ...prev,
        jobs: [...prev.jobs, ...newJobs],
        focusDateRange: dateRange || undefined,
        history: addToHistory(prev.history, log)
      };
    });
  };

  // --- UNDO ENGINE ---
  const undoAction = (actionId: string) => {
    setState(prev => {
      const action = prev.history.find(a => a.id === actionId);
      if (!action) return prev;

      let restoredJobs = [...prev.jobs];

      // 1. REVERT UPDATE: Restore old job data
      if (action.type === 'UPDATE' && action.previousData) {
        const oldData = action.previousData as Job;
        restoredJobs = restoredJobs.map(j => j.id === oldData.id ? oldData : j);
      }
      // 2. REVERT DELETE: Add back deleted jobs
      else if (action.type === 'DELETE' && action.previousData) {
        const deletedJobs = action.previousData as Job[];
        restoredJobs = [...restoredJobs, ...deletedJobs];
      }
      // 3. REVERT CREATE/IMPORT: Remove created jobs
      else if ((action.type === 'CREATE' || action.type === 'IMPORT') && action.currentDataId) {
        const idsToRemove = Array.isArray(action.currentDataId)
          ? action.currentDataId
          : [action.currentDataId];
        restoredJobs = restoredJobs.filter(j => !idsToRemove.includes(j.id));
      }

      return {
        ...prev,
        jobs: restoredJobs,
        history: prev.history.filter(a => a.id !== actionId) // Remove from history
      };
    });
  };

  const clearAllData = () => {
    setState(defaultState);
    localStorage.removeItem(STORAGE_KEY);
  };

  // --- PRICING ACTIONS ---

  const updatePrices = (prices: PriceTable) => {
    setState(prev => ({ ...prev, prices }));
  };

  const setActiveYear = (year: number) => {
    setState(prev => ({ ...prev, activeYear: year }));
  };

  const updateGlobalPrice = (year: number, category: string, size: string, price: PriceConfig) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      let yearIdx = newData.findIndex(y => y.year === year);

      if (yearIdx === -1) {
        // Create year if doesn't exist (Clone default structure)
        newData.push({
          year,
          global: JSON.parse(JSON.stringify(DEFAULT_PRICES)),
          overrides: []
        });
        yearIdx = newData.length - 1;
      }

      const targetYear = newData[yearIdx];
      if (!targetYear.global[category]) targetYear.global[category] = {};
      targetYear.global[category][size] = price;

      // NEW LOGIC: If this is a new Size we haven't seen before, add it to the dropdown list
      // This ensures "what you add here affects everything"
      let newLists = prev.lists;
      const normalizedSize = size.trim();
      if (normalizedSize && !prev.lists.sizes.some(s => s.toLowerCase() === normalizedSize.toLowerCase())) {
        newLists = {
          ...prev.lists,
          sizes: [...prev.lists.sizes, normalizedSize]
        };
      }

      return { ...prev, pricingData: newData, lists: newLists };
    });
  };

  const deleteGlobalPrice = (year: number, category: string, size: string) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      const yearData = newData.find(y => y.year === year);
      if (yearData && yearData.global[category]) {
        const newCategory = { ...yearData.global[category] };
        delete newCategory[size];
        yearData.global[category] = newCategory;
      }
      return { ...prev, pricingData: newData };
    });
  };

  const addPriceOverride = (year: number, override: PricingOverride) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      let targetYear = newData.find(y => y.year === year);
      if (!targetYear) {
        targetYear = { year, global: JSON.parse(JSON.stringify(DEFAULT_PRICES)), overrides: [] };
        newData.push(targetYear);
      }
      // Remove existing override for same prop/cat/size if exists
      targetYear.overrides = targetYear.overrides.filter(o =>
        !(o.propertyId === override.propertyId && o.category === override.category && o.size === override.size)
      );
      targetYear.overrides.push(override);
      return { ...prev, pricingData: newData };
    });
  };

  const removePriceOverride = (year: number, propertyId: string, category: string, size: string) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      const targetYear = newData.find(y => y.year === year);
      if (targetYear) {
        targetYear.overrides = targetYear.overrides.filter(o =>
          !(o.propertyId === propertyId && o.category === category && o.size === size)
        );
      }
      return { ...prev, pricingData: newData };
    });
  };

  // --- APP CONFIG (NEW) ---
  const updateAppConfig = (updates: Partial<AppConfig>) => {
    setState(prev => ({
      ...prev,
      appConfig: { ...prev.appConfig, ...updates }
    }));
  };

  // --- EMPLOYEE ACTIONS (NEW) ---
  const addEmployee = (employee: Employee) => {
    setState(prev => ({ ...prev, employees: [...prev.employees, employee] }));
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setState(prev => ({
      ...prev,
      employees: prev.employees.map(e => e.id === id ? { ...e, ...updates } : e)
    }));
  };

  const deleteEmployee = (id: string) => {
    setState(prev => ({
      ...prev,
      employees: prev.employees.filter(e => e.id !== id)
    }));
  };

  // --- LINK ACTIONS ---
  const addQuickLink = (link: QuickLink) => {
    setState(prev => ({ ...prev, quickLinks: [...prev.quickLinks, link] }));
  };

  const deleteQuickLink = (id: string) => {
    setState(prev => ({ ...prev, quickLinks: prev.quickLinks.filter(l => l.id !== id) }));
  };

  // --- TASK ACTIONS ---
  const addTask = (text: string) => {
    const newTask = { id: generateId(), text, completed: false, createdAt: Date.now() };
    setState(prev => ({ ...prev, tasks: [newTask, ...prev.tasks] }));
  };

  const toggleTask = (id: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
    }));
  };

  const deleteTask = (id: string) => {
    setState(prev => ({ ...prev, tasks: prev.tasks.filter(t => t.id !== id) }));
  };

  const updateTask = (id: string, text: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === id ? { ...t, text } : t)
    }));
  };

  const reorderTasks = (tasks: Task[]) => {
    setState(prev => ({ ...prev, tasks }));
  };

  const setTasks = (tasks: Task[]) => {
    setState(prev => ({ ...prev, tasks }));
  };

  // --- API CONFIG ACTIONS ---
  const addApiConfig = (config: ApiConfig) => {
    setState(prev => ({ ...prev, apiConfigs: [...(prev.apiConfigs || []), config] }));
  };

  const updateApiConfig = (id: string, updates: Partial<ApiConfig>) => {
    setState(prev => ({
      ...prev,
      apiConfigs: (prev.apiConfigs || []).map(c => c.id === id ? { ...c, ...updates } : c)
    }));
  };

  const deleteApiConfig = (id: string) => {
    setState(prev => ({
      ...prev,
      apiConfigs: (prev.apiConfigs || []).filter(c => c.id !== id)
    }));
  };

  // --- PREPAID ACTIONS ---
  const updatePrepaidList = (key: string, units: string[]) => {
    setState(prev => ({
      ...prev,
      prepaidUnits: { ...prev.prepaidUnits, [key]: units }
    }));
  };

  const updateProperty = (id: string, updates: Partial<Property>) => {
    setState(prev => ({
      ...prev,
      properties: prev.properties.map(p => p.id === id ? { ...p, ...updates } : p)
    }));
  };

  const addProperty = (property: Property) => {
    setState(prev => ({
      ...prev,
      properties: [...prev.properties, property]
    }));
  };

  const setFocusDateRange = (range: { start: Date; end: Date } | undefined) => {
    setState(prev => ({ ...prev, focusDateRange: range }));
  };

  const setDateViewUnit = (unit: 'day' | 'week' | 'month') => {
    setState(prev => ({ ...prev, dateViewUnit: unit }));
  };

  const updateSettings = (newSettings: Partial<AppState['settings']>) => {
    setState(prev => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings }
    }));
  };

  const setJobsViewMode = (mode: JobsViewMode) => {
    setState(prev => {
      let lastMode = prev.lastNonDuplicateMode;
      if (mode === 'DUPLICATES_ONLY' && prev.viewMode !== 'DUPLICATES_ONLY') {
        lastMode = prev.viewMode;
      }
      return {
        ...prev,
        viewMode: mode,
        lastNonDuplicateMode: lastMode
      };
    });
  };

  const addLog = (log: LogEntry) => {
    setState(prev => ({ ...prev, systemLogs: [...prev.systemLogs, log] }));
  };

  const setIsImporting = (val: boolean) => {
    setState(prev => ({ ...prev, isImporting: val }));
  };

  if (!isLoaded) return <div className="flex h-screen items-center justify-center text-slate-500">Loading Aroma Op-x {APP_VERSION}...</div>;

  return (
    <AppContext.Provider value={{
      ...state,
      addJob,
      updateJob,
      deleteJobs,
      importJobs,
      clearAllData,
      undoAction,
      updatePrices,
      setActiveYear,
      updateGlobalPrice,
      deleteGlobalPrice,
      addPriceOverride,
      removePriceOverride,
      updateAppConfig, // NEW
      updateProperty,
      addProperty,
      addEmployee,
      updateEmployee,
      deleteEmployee,
      addQuickLink,
      deleteQuickLink,
      addTask,
      toggleTask,
      deleteTask,
      updatePrepaidList,
      setJobsViewMode,
      setDateViewUnit, // Added
      addLog,
      setIsImporting,
      updateSettings,
      t,
      addApiConfig,
      updateApiConfig,
      deleteApiConfig,
      updateTask,
      reorderTasks,
      setTasks
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
