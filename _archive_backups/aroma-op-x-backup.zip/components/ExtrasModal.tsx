
import React, { useState, useEffect } from 'react';
import { X, Check, Calculator, AlertTriangle, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { PriceConfig } from '../types';

interface ExtrasModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentExtras: string;
  onSave: (extrasStr: string, price: number) => void;
}

const ExtrasModal: React.FC<ExtrasModalProps> = ({ isOpen, onClose, currentExtras, onSave }) => {
  const { prices } = useApp();
  const [selectedExtras, setSelectedExtras] = useState<Set<string>>(new Set());
  
  // Drywall / Custom Logic
  const [customCost, setCustomCost] = useState<string>('');
  const [calculatedPrice, setCalculatedPrice] = useState<string>('');
  const [manualOverride, setManualOverride] = useState(false);

  // Parse current string into set on open
  useEffect(() => {
    if (isOpen) {
      const items = currentExtras.split(',').map(s => s.trim()).filter(s => !!s);
      // Filter out custom drywall entries to just select checkboxes for standard items
      const standardItems = items.filter(i => !i.startsWith('Drywall Repair'));
      setSelectedExtras(new Set(standardItems));
      
      // Reset custom inputs
      setCustomCost('');
      setCalculatedPrice('');
      setManualOverride(false);
    }
  }, [isOpen, currentExtras]);

  // Auto-calculate x2 rule
  useEffect(() => {
    if (!manualOverride) {
        const cost = parseFloat(customCost);
        if (!isNaN(cost)) {
            setCalculatedPrice((cost * 2).toFixed(2));
        } else {
            setCalculatedPrice('');
        }
    }
  }, [customCost, manualOverride]);

  if (!isOpen) return null;

  const extrasList = (prices['EXTRAS'] || {}) as Record<string, PriceConfig>;
  const availableExtras = Object.keys(extrasList);

  const toggleExtra = (extraName: string) => {
    const newSet = new Set(selectedExtras);
    if (newSet.has(extraName)) {
      newSet.delete(extraName);
    } else {
      newSet.add(extraName);
    }
    setSelectedExtras(newSet);
  };

  const handleSave = () => {
    let extrasArray = Array.from(selectedExtras);
    let total = 0;

    // 1. Calculate Standard Items
    extrasArray.forEach((name: string) => {
      const item = extrasList[name];
      if (item) {
        total += item.client;
      }
    });

    // 2. Add Custom Drywall if present
    const cost = parseFloat(customCost);
    const price = parseFloat(calculatedPrice);

    if (!isNaN(cost) && !isNaN(price)) {
        // Format: "Drywall Repair ($120)" - The price is included in description for clarity on invoice?
        // Or just "Drywall Repair" and add price to total. 
        // User requested: "Drywall Repair $80"
        extrasArray.push(`Drywall Repair $${Math.round(price)}`);
        total += price;
    }

    const extrasStr = extrasArray.join(', ');
    onSave(extrasStr, total);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
          <h3 className="font-bold text-slate-800">Manage Extras & Repairs</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X size={20} />
          </button>
        </div>

        <div className="p-4 overflow-y-auto custom-scrollbar flex-1 space-y-6">
            
            {/* DRYWALL CALCULATOR MODULE */}
            <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                    <div className="bg-orange-100 p-1.5 rounded text-orange-600">
                        <Calculator size={16} />
                    </div>
                    <h4 className="font-bold text-orange-900 text-sm">Drywall Repair Calculator</h4>
                </div>
                
                <div className="flex items-end gap-3">
                    <div className="flex-1">
                        <label className="block text-[10px] font-bold text-orange-800 uppercase mb-1">Worker Cost</label>
                        <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-orange-400 text-xs">$</span>
                            <input 
                                type="number" 
                                className="w-full pl-5 pr-2 py-1.5 text-sm border border-orange-200 rounded focus:ring-2 focus:ring-orange-400 outline-none font-bold text-slate-700"
                                placeholder="0"
                                value={customCost}
                                onChange={e => setCustomCost(e.target.value)}
                            />
                        </div>
                    </div>
                    
                    <div className="pb-2 text-orange-300">
                        <ArrowRight size={16} />
                    </div>

                    <div className="flex-1">
                         <div className="flex justify-between items-center mb-1">
                            <label className="block text-[10px] font-bold text-orange-800 uppercase">Client Price</label>
                            {manualOverride ? (
                                <button onClick={() => setManualOverride(false)} className="text-[9px] text-red-500 hover:underline">Reset x2</button>
                            ) : (
                                <span className="text-[9px] text-orange-400 font-mono">Auto (x2)</span>
                            )}
                         </div>
                        <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-orange-400 text-xs">$</span>
                            <input 
                                type="number" 
                                className={`w-full pl-5 pr-2 py-1.5 text-sm border rounded focus:ring-2 outline-none font-bold ${manualOverride ? 'border-blue-300 bg-white ring-blue-500 text-blue-700' : 'border-orange-200 bg-orange-100/50 text-slate-700'}`}
                                placeholder="0"
                                value={calculatedPrice}
                                onChange={e => {
                                    setManualOverride(true);
                                    setCalculatedPrice(e.target.value);
                                }}
                            />
                        </div>
                    </div>
                </div>
                
                {manualOverride && (
                    <div className="mt-2 flex items-center gap-1.5 text-[10px] text-blue-600 bg-blue-50 px-2 py-1 rounded border border-blue-100">
                        <AlertTriangle size={10} />
                        Manual Override Active. Price is no longer 2x Cost.
                    </div>
                )}
            </div>

            {/* STANDARD LIST */}
            <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Standard Extras</h4>
                {availableExtras.map(name => {
                const isSelected = selectedExtras.has(name);
                const item = extrasList[name];
                const price = item ? item.client : 0;
                
                return (
                    <button
                    key={name}
                    onClick={() => toggleExtra(name)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                        isSelected 
                        ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-sm' 
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                    >
                    <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                        isSelected ? 'bg-blue-500 border-blue-500 text-white' : 'border-slate-300'
                        }`}>
                        {isSelected && <Check size={12} />}
                        </div>
                        <span className="font-medium">{name}</span>
                    </div>
                    <span className="text-sm font-semibold text-slate-500">
                        +{formatCurrency(price)}
                    </span>
                    </button>
                );
                })}
            </div>
            
            {selectedExtras.size === 0 && !customCost && (
                <p className="text-center text-slate-400 text-sm mt-4 italic">No extras selected</p>
            )}
        </div>

        <div className="p-4 border-t border-slate-200 bg-slate-50">
          <button 
            onClick={handleSave}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExtrasModal;
