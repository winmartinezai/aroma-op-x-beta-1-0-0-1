
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ChevronLeft, ChevronRight, CheckCircle2, History, Calendar, MousePointer2 } from 'lucide-react';
import { getStartOfWeek, getEndOfWeek, formatDateRange } from '../utils/dateUtils';

interface DateHeaderProps {
  currentRange: { start: Date; end: Date } | null;
  onRangeChange: (range: { start: Date; end: Date } | null) => void;
  onClear: () => void;
  hasActiveFilter: boolean;
}

// CONFIG
const ITEM_WIDTH = 60; 
const VISIBLE_BUFFER = 15; 

const DateHeader: React.FC<DateHeaderProps> = ({ currentRange, onRangeChange }) => {
  const [isDialMode, setIsDialMode] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Base date for the visual center
  const effectiveDate = currentRange ? currentRange.start : new Date();
  const [virtualDate, setVirtualDate] = useState<Date>(new Date(effectiveDate));
  
  // Wheel Physics State
  const wheelAccumulator = useRef(0);
  const wheelTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Sync virtual date when external range changes (e.g. from Sidebar or Import)
  useEffect(() => {
    if (currentRange) {
        setVirtualDate(currentRange.start);
    }
  }, [currentRange]);
  
  // --- NAVIGATION HELPERS ---
  
  // Jump 7 days forward/back
  const navigateWeek = (direction: 'prev' | 'next') => {
      const newDate = new Date(virtualDate);
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
      setVirtualDate(newDate);
      
      // Update Parent immediately
      const start = getStartOfWeek(newDate);
      const end = getEndOfWeek(newDate);
      onRangeChange({ start, end });
  };

  // Select specific day
  const handleSelectDay = (date: Date) => {
      setVirtualDate(date);
      if (isDialMode) {
          // Single Day Mode
          onRangeChange({ start: date, end: date });
      } else {
          // Week Mode
          onRangeChange({ start: getStartOfWeek(date), end: getEndOfWeek(date) });
      }
  };

  const handleToggleViewAll = () => {
      if (currentRange) {
          onRangeChange(null); // Clear filter
      } else {
          // Restore to current week
          const today = new Date();
          onRangeChange({ start: getStartOfWeek(today), end: getEndOfWeek(today) });
          setVirtualDate(today);
      }
  };

  // --- MOUSE WHEEL LOGIC (The "Fun" Part) ---
  const handleWheel = (e: React.WheelEvent) => {
    // If viewing all history (no filter), prevent wheel from doing anything weird
    if (!currentRange) return;

    // Accumulate delta (Horizontal or Vertical scroll both work)
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    
    // Add to accumulator
    wheelAccumulator.current += delta;

    // Threshold determines sensitivity. 30 is a good balance for trackpads.
    const THRESHOLD = 30;

    if (Math.abs(wheelAccumulator.current) > THRESHOLD) {
        const direction = wheelAccumulator.current > 0 ? 1 : -1;
        
        // Calculate new visual date
        const newDate = new Date(virtualDate);
        newDate.setDate(newDate.getDate() + direction);
        setVirtualDate(newDate);

        // Reset accumulator
        wheelAccumulator.current = 0;

        // PERFORMANCE GUARD:
        // If in "Dial Mode" (Day View), we update the table immediately because looking at 1 day is fast.
        // If in "Week Mode", we ONLY scroll visually. We don't update the table query until the user stops or clicks.
        // This prevents "flickering" the heavy Jobs Table while just browsing dates.
        if (isDialMode) {
            // Debounce the actual data fetch slightly if scrolling super fast
            if (wheelTimeout.current) clearTimeout(wheelTimeout.current);
            wheelTimeout.current = setTimeout(() => {
                onRangeChange({ start: newDate, end: newDate });
            }, 50); // 50ms buffer
        }
    }
  };

  // --- RENDER ITEMS ---
  const visibleItems = useMemo(() => {
      const items = [];
      for (let i = -VISIBLE_BUFFER; i <= VISIBLE_BUFFER; i++) {
          const d = new Date(virtualDate);
          d.setDate(d.getDate() + i); 
          items.push({ date: d, index: i });
      }
      return items;
  }, [virtualDate]);

  const displayDate = currentRange 
    ? (isDialMode 
        ? formatDateRange(virtualDate, virtualDate) 
        : formatDateRange(getStartOfWeek(virtualDate), getEndOfWeek(virtualDate)))
    : "Viewing All History";

  return (
    <div 
        className="bg-slate-900 border-b border-slate-800 flex flex-col relative shadow-md z-30 h-32 shrink-0 select-none"
        onWheel={handleWheel}
    >
      
      {/* TOP BAR: CONTROLS & DISPLAY */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-950/50 border-b border-white/5 h-10 shrink-0">
        
        {/* Toggle Mode */}
        <div className="flex bg-slate-800/50 rounded-lg p-0.5 border border-white/10">
             <button 
                onClick={() => {
                    setIsDialMode(false);
                    // Re-snap to week view range
                    onRangeChange({ start: getStartOfWeek(virtualDate), end: getEndOfWeek(virtualDate) });
                }}
                className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase transition-all ${!isDialMode && currentRange ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
             >
                Week
             </button>
             <button 
                onClick={() => {
                    setIsDialMode(true);
                    // Snap to single day view
                    onRangeChange({ start: virtualDate, end: virtualDate });
                }}
                className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase transition-all ${isDialMode && currentRange ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
             >
                Day
             </button>
        </div>

        {/* Date Display Badge */}
        <div className="flex items-center gap-2 absolute left-1/2 -translate-x-1/2 pointer-events-none">
            <span className={`text-xs font-mono font-medium tracking-wide px-4 py-1 rounded-full border shadow-sm transition-colors ${
                currentRange 
                ? 'bg-slate-800 text-slate-200 border-slate-700' 
                : 'bg-emerald-900/50 text-emerald-400 border-emerald-800'
            }`}>
                {displayDate}
            </span>
        </div>

        {/* View All Button */}
        <button 
            onClick={handleToggleViewAll}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border ${
                !currentRange 
                ? 'bg-emerald-500 text-white border-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.4)]' 
                : 'bg-slate-800 text-slate-400 border-white/10 hover:bg-slate-700 hover:text-white'
            }`}
        >
            {!currentRange ? <CheckCircle2 size={12} /> : <History size={12} />}
            {currentRange ? 'View All' : 'Filtering Off'}
        </button>
      </div>

      {/* VISUAL DIAL AREA */}
      <div className="relative flex-1 w-full overflow-hidden bg-slate-900 group cursor-grab active:cursor-grabbing">
           
           {/* Navigation Arrows (Large clickable areas) */}
           <button 
                onClick={() => navigateWeek('prev')}
                className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent z-30 flex items-center justify-center text-slate-400 hover:text-white transition-all hover:bg-slate-800/30 cursor-pointer active:scale-95"
                title="Go Back 1 Week"
           >
               <ChevronLeft size={32} />
           </button>

           <button 
                onClick={() => navigateWeek('next')}
                className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-slate-900 via-slate-900/80 to-transparent z-30 flex items-center justify-center text-slate-400 hover:text-white transition-all hover:bg-slate-800/30 cursor-pointer active:scale-95"
                title="Go Forward 1 Week"
           >
               <ChevronRight size={32} />
           </button>

           {/* Center Marker */}
           <div className="absolute left-1/2 top-0 bottom-0 w-[60px] -translate-x-1/2 z-10 pointer-events-none border-x border-blue-500/30 bg-blue-500/5">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-2 bg-blue-400"></div>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0.5 h-2 bg-blue-400"></div>
           </div>

           {/* Date Strip */}
           <div 
                className="absolute top-0 bottom-0 left-1/2 h-full flex items-center"
                ref={containerRef}
           >
               {visibleItems.map((item) => {
                   const offset = item.index * ITEM_WIDTH;
                   const isCenter = item.index === 0;
                   const isWeekend = item.date.getDay() === 0 || item.date.getDay() === 6;

                   return (
                       <div 
                            key={item.date.toISOString()} 
                            // Optimized transition duration (200ms) for snappy wheel feel
                            className="absolute flex flex-col items-center justify-center transition-transform duration-200 ease-out hover:bg-white/5 rounded-lg py-2"
                            style={{
                                transform: `translateX(${offset}px) translateX(-50%)`, 
                                width: `${ITEM_WIDTH}px`,
                                zIndex: isCenter ? 10 : 1,
                                opacity: currentRange ? (Math.abs(item.index) > 4 ? 0.3 : 1) : 0.3
                            }}
                            onClick={(e) => {
                                e.stopPropagation();
                                handleSelectDay(item.date);
                            }}
                       >
                            <span className={`text-[9px] font-bold uppercase mb-1 ${
                                isCenter ? 'text-blue-300' : isWeekend ? 'text-slate-500' : 'text-slate-600'
                            }`}>
                                {item.date.toLocaleDateString('en-US', { weekday: 'short' })}
                            </span>
                            <span className={`font-sans text-xl font-bold transition-transform ${
                                isCenter ? 'text-white scale-125' : isWeekend ? 'text-slate-600' : 'text-slate-500'
                            }`}>
                                {item.date.getDate()}
                            </span>
                            {/* Month Marker on the 1st */}
                            {item.date.getDate() === 1 && (
                                <div className="absolute -top-4 bg-slate-700 text-slate-200 text-[8px] px-1.5 py-0.5 rounded border border-slate-600 pointer-events-none">
                                    {item.date.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
                                </div>
                            )}
                       </div>
                   );
               })}
           </div>
      </div>
      
      {/* DISABLED OVERLAY (When View All is active) */}
      {!currentRange && (
          <div className="absolute inset-0 z-20 bg-slate-950/60 backdrop-blur-[1px] flex items-center justify-center pointer-events-none">
              <div className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 shadow-2xl flex flex-col items-center">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-1">Timeline Unlocked</span>
                  <span className="text-[10px] text-slate-500">Showing all records from database</span>
              </div>
          </div>
      )}
    </div>
  );
};

export default DateHeader;
