/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                // Add custom colors here if needed, or rely on Tailwind defaults + arbitrary values
            },
        },
    },
    plugins: [],
}
