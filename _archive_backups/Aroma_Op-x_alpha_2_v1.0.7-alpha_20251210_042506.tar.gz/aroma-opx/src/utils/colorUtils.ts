export const EMPLOYEE_COLORS = [
    'blue',
    'emerald',
    'violet',
    'amber',
    'rose',
    'cyan',
    'fuchsia',
    'lime',
    'orange',
    'teal',
    'indigo',
    'pink'
] as const;

export type EmployeeColor = typeof EMPLOYEE_COLORS[number];

export const getRandomEmployeeColor = (): EmployeeColor => {
    return EMPLOYEE_COLORS[Math.floor(Math.random() * EMPLOYEE_COLORS.length)];
};

export const getEmployeeColorClasses = (color: string) => {
    // Handle legacy Hex codes gracefully (fallback to slate if exact match fails, or use style prop elsewhere)
    if (color.startsWith('#')) {
        return {
            bg: 'bg-slate-100',
            text: 'text-slate-800',
            border: 'border-slate-200',
            isHex: true
        };
    }

    // Standard Tailwind colors (High Contrast)
    return {
        bg: `bg-${color}-300`, // Was 200 - now stronger
        text: `text-${color}-950`, // Was 900 - now darkest
        border: `border-${color}-400`, // Was 300 - now stronger
        ring: `focus:ring-${color}-600`,
        isHex: false
    };
};
