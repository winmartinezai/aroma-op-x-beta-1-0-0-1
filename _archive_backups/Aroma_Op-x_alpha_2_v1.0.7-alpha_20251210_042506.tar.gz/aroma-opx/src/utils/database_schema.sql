-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. JOBS TABLE
CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_number INT UNIQUE,
    date DATE NOT NULL,
    property TEXT NOT NULL,
    apt TEXT NOT NULL,
    size TEXT NOT NULL,
    type TEXT NOT NULL,
    assigned_to TEXT,
    status TEXT DEFAULT 'Pending',
    invoice_status TEXT DEFAULT 'None',
    po TEXT,
    invoice_number TEXT,
    client_price NUMERIC DEFAULT 0,
    employee_price NUMERIC DEFAULT 0,
    extras_price NUMERIC DEFAULT 0,
    notes TEXT,
    is_private BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. EMPLOYEES TABLE
CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    color TEXT,
    email TEXT,
    phone TEXT,
    pricing_config JSONB, -- Stores custom rates
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. PROPERTIES TABLE
CREATE TABLE IF NOT EXISTS properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    billing_logic TEXT,
    po_logic TEXT,
    management_group TEXT,
    portal_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. APP SETTINGS (Singleton config)
CREATE TABLE IF NOT EXISTS app_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key TEXT UNIQUE NOT NULL, -- e.g. 'GLOBAL_CONFIG'
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- --- SECURITY POLICIES (Row Level Security) ---
-- For Phase 1, we will allow public read/write since we don't have Auth users yet.
-- WARNING: This is temporary. In Phase 2, we lock this down.

ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- Allow Anon (Public) access for now
CREATE POLICY "Allow public access to jobs" ON jobs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to employees" ON employees FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to properties" ON properties FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to app_settings" ON app_settings FOR ALL USING (true) WITH CHECK (true);

-- --- REALTIME SUBSCRIPTIONS ---
-- Enable Realtime for jobs so the dashboard updates instantly
alter publication supabase_realtime add table jobs;
