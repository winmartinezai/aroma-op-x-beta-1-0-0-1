
import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { AppState, Job, Employee, Property, PriceTable, AppContextType, PricingOverride, PriceConfig, QuickLink, ActionLog, JobsViewMode, LogEntry, ApiConfig, Task, AppConfig } from '../types/types';
import { DEFAULT_EMPLOYEES, DEFAULT_PRICES, DEFAULT_PROPERTY_CONTACTS, DEFAULT_PORTAL_URLS, DEFAULT_PRICING_DATA, DEFAULT_QUICK_LINKS, APP_VERSION, TRANSLATIONS, APP_CONFIG } from '../utils/constants';
import { generateId } from '../utils/helpers';
import { getStartOfMonth, getEndOfMonth } from '../utils/dateUtils';

const STORAGE_KEY = 'aroma_ops_data_v2';

const defaultState: AppState = {
  version: APP_VERSION,
  activeYear: new Date().getFullYear(),
  jobs: [],
  employees: DEFAULT_EMPLOYEES,
  properties: DEFAULT_PROPERTY_CONTACTS,
  prices: DEFAULT_PRICES, // Legacy
  pricingData: DEFAULT_PRICING_DATA, // New Brain
  appConfig: APP_CONFIG as AppConfig, // NEW CENTRALIZED CONFIG
  quickLinks: DEFAULT_QUICK_LINKS,
  settings: {
    employeeInvoiceEmail: 'aromacleaning22@gmail.com',
    companyName: 'Aroma Cleaning & Painting',
    language: 'en',
    dateDialVisibility: 'dashboard_only', // Default
    enableDebugConsole: false, // Default OFF (Hidden)
    showAdvancedCheck: false, // Default off per request (gated feature)
    uiScale: 1 // Default 100% scale
  },
  portals: DEFAULT_PORTAL_URLS,
  lists: {
    jobTypes: ['Paint', 'Clean', 'Touch Up Paint', 'Touch Up Clean'],
    sizes: ['1x1', '2x2', '3x2', 'Studio']
  },
  tasks: [],
  prepaidUnits: {},
  history: [], // Init empty history
  systemLogs: [], // Init empty logs
  isImporting: false, // Init importing state
  viewMode: 'DATE_FILTERED', // Default view mode
  lastNonDuplicateMode: 'DATE_FILTERED', // Default fallback
  viewLayout: 'list',
  searchTerm: '',
  apiConfigs: [],
  focusDateRange: {
    start: getStartOfMonth(new Date()),
    end: getEndOfMonth(new Date())
  },
  dateViewUnit: 'week' // Default
};

export const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(defaultState);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from local storage
  const refreshFromStorage = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);

        // BACKFILL LOGIC: Check for jobs without numbers OR old numbers (below 100k)
        let jobs: Job[] = parsed.jobs || [];
        // Treat jobs with IDs < 100,000 as needing update (migration from 4000s)
        const jobsNeedingUpdate = jobs.filter(j => !j.jobNumber || j.jobNumber < 100000);

        if (jobsNeedingUpdate.length > 0) {
          console.log(`🔧 MIGRATION: Found ${jobsNeedingUpdate.length} jobs with old/missing IDs. Reassigning to 100xxx...`);

          // Find current max of VALID series (>= 100000), or start at seed 100100 (so next is 100101)
          let currentMax = jobs.reduce((max, j) => (j.jobNumber && j.jobNumber >= 100000) ? Math.max(max, j.jobNumber) : max, 100100);

          // Sort needing update by date
          // We need to update ONLY the ones needing update, but we want to keep them consistent?
          // Simplest is to just re-scan all.
          // Let's create a map of IDs to update.
          const idsToUpdate = new Set(jobsNeedingUpdate.map(j => j.id));

          // Sort ALL jobs by date to ensure sequential ordering if we were doing all, 
          // but here we just want to fix the old ones.
          // Let's sort the "needing update" subset by date.
          jobsNeedingUpdate.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

          // Create a mapping of old ID -> New NUmber
          const newNumberMap = new Map<string, number>();
          jobsNeedingUpdate.forEach(j => {
            currentMax++;
            // RULE: 4th digit cannot be 0.
            // If we hit xXX0xx, skip 100 to xXX1xx.
            // e.g. 100999 -> 101000 (0 at index 3). Add 100 -> 101100.
            // Wait, 101100 has 0 at index 3? No, '1' is index 3. '1','0','1','1'.
            if (currentMax.toString()[3] === '0') {
              currentMax += 100;
            }
            newNumberMap.set(j.id, currentMax);
          });

          // Apply updates
          jobs = jobs.map(j => {
            if (idsToUpdate.has(j.id)) {
              return { ...j, jobNumber: newNumberMap.get(j.id) };
            }
            return j;
          });
        }

        console.log("🔄 REFRESH: Loaded from Storage", {
          jobsCount: jobs.length,
          viewMode: parsed.viewMode,
          dateRange: parsed.focusDateRange
        });

        setState(() => ({ // specific update pattern to avoid race conditions if needed
          ...defaultState,
          ...parsed,
          jobs: jobs, // Use patched jobs
          version: APP_VERSION, // Always force current code version
          // Merge nested objects to prevent data loss on new fields
          pricingData: parsed.pricingData || DEFAULT_PRICING_DATA,
          appConfig: parsed.appConfig || APP_CONFIG, // Load or Default
          quickLinks: parsed.quickLinks || DEFAULT_QUICK_LINKS,
          tasks: parsed.tasks || [],
          prepaidUnits: parsed.prepaidUnits || {},
          history: parsed.history || [],
          settings: { ...defaultState.settings, ...parsed.settings },
          lists: { ...defaultState.lists, ...parsed.lists },
          portals: { ...defaultState.portals, ...(parsed.portals || {}) },
          properties: (parsed.properties || DEFAULT_PROPERTY_CONTACTS).map((p: any) => {
            let logic = p.billingLogic;
            if (!logic) {
              if (p.name === 'Sur Club') logic = 'combined';
              else logic = 'independent';
            }
            return { ...p, billingLogic: logic };
          }),
          // Ensure dateViewUnit exists if loading old state
          dateViewUnit: parsed.dateViewUnit || 'week'
        }));
      } else {
        console.warn("⚠️ REFRESH: No data found in LocalStorage");
      }
    } catch (e) {
      console.error("Failed to load state", e);
    } finally {
      setIsLoaded(true);
    }
  };

  useEffect(() => {
    refreshFromStorage();
  }, []);

  // Save to local storage
  useEffect(() => {
    if (isLoaded) {
      const { focusDateRange, ...storageState } = state;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(storageState));
        console.log("💾 SAVE: Persisted to Storage", { jobs: state.jobs.length });
      } catch (err) {
        console.error("❌ SAVE FAILED:", err);
      }
    }
  }, [state, isLoaded]);

  // TRANSLATION HELPER
  const t = (key: string): string => {
    const lang = state.settings.language || 'en';
    const dict = TRANSLATIONS[lang] || TRANSLATIONS['en'];
    return (dict as any)[key] || key;
  };

  // --- HISTORY HELPER ---
  const addToHistory = (prevHistory: ActionLog[], log: ActionLog): ActionLog[] => {
    // Keep last 20 actions
    return [log, ...prevHistory].slice(0, 20);
  };

  const addJob = (job: Job) => {
    setState(prev => {
      // Auto-increment Job Number
      // Start at 100100 so first new job is 100101
      const maxJobNum = prev.jobs.reduce((max, j) => Math.max(max, j.jobNumber || 0), 100100);
      let newJobNumber = maxJobNum + 1;

      // RULE: 4th digit cannot be 0.
      if (newJobNumber.toString()[3] === '0') {
        newJobNumber += 100;
      }

      // Ensure Job Number is assigned and cannot be overridden by input
      const newJob = { ...job, jobNumber: newJobNumber };

      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'CREATE',
        description: `Created Job: ${newJob.property} ${newJob.apt} (#${newJobNumber})`,
        currentDataId: newJob.id
      };
      return {
        ...prev,
        jobs: [...prev.jobs, newJob],
        history: addToHistory(prev.history, log)
      };
    });
  };

  const updateJob = (id: string, updates: Partial<Job>) => {
    setState(prev => {
      const oldJob = prev.jobs.find(j => j.id === id);
      if (!oldJob) return prev;

      // IMMUTABILITY CHECK: Prevent changing jobNumber
      if (updates.jobNumber !== undefined && updates.jobNumber !== oldJob.jobNumber) {
        console.warn("🚫 Attempted to change immutable Job Number. Ignoring.");
        delete updates.jobNumber;
      }

      // Only log if something actually changed (shallow comparison for simplicity)
      const hasChanges = Object.keys(updates).some(k => (oldJob as any)[k] !== (updates as any)[k]);

      let newHistory = prev.history;

      if (hasChanges) {
        const log: ActionLog = {
          id: generateId(),
          timestamp: Date.now(),
          type: 'UPDATE',
          description: `Updated ${oldJob.property} ${oldJob.apt}`,
          previousData: oldJob
        };
        newHistory = addToHistory(prev.history, log);
      }

      return {
        ...prev,
        jobs: prev.jobs.map(j => j.id === id ? { ...j, ...updates } : j),
        history: newHistory
      };
    });
  };

  const updateJobs = (updates: Job[]) => {
    setState(prev => {
      const ids = new Set(updates.map(u => u.id));
      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'UPDATE',
        description: `Batch Updated ${updates.length} Jobs`,
        previousData: prev.jobs.filter(j => ids.has(j.id))
      };

      const updateMap = new Map(updates.map(u => [u.id, u]));

      return {
        ...prev,
        jobs: prev.jobs.map(j => updateMap.has(j.id) ? { ...j, ...updateMap.get(j.id)! } : j),
        history: addToHistory(prev.history, log)
      };
    });
  };

  /* --- HELPER: GENERATE NEXT JOB NUMBER --- */
  const getNextJobNumber = (currentMax: number) => {
    let next = currentMax + 1;
    // RULE: 4th digit cannot be 0 (xXX0xx)
    // E.g. 101001 -> Index 3 is '0'. 
    if (next.toString()[3] === '0') {
      next += 100;
    }
    return next;
  };

  const resolveImportConflicts = (newJobs: Job[], updatedJobs: Job[]) => {
    console.log("⚡ RESOLVING CONFLICTS", { new: newJobs.length, updated: updatedJobs.length });
    setState(prev => {
      let finalJobs = [...prev.jobs];
      let newHistory = prev.history;

      // 1. Process Updates
      if (updatedJobs.length > 0) {
        console.log("   - Processing Updates...");
        const updateMap = new Map(updatedJobs.map(u => [u.id, u]));
        finalJobs = finalJobs.map(j => updateMap.has(j.id) ? { ...j, ...updateMap.get(j.id)! } : j);

        const updateLog: ActionLog = {
          id: generateId(),
          timestamp: Date.now(),
          type: 'UPDATE',
          description: `Batch Updated ${updatedJobs.length} Jobs during Import`,
          previousData: prev.jobs.filter(j => updateMap.has(j.id))
        };
        newHistory = addToHistory(newHistory, updateLog);
      }

      // 2. Process New Imports (WITH AUTO-INCREMENT)
      if (newJobs.length > 0) {
        console.log("   - Processing New Imports...");

        // Calculate Seed
        let maxJobNum = finalJobs.reduce((max, j) => Math.max(max, j.jobNumber || 0), 100100);

        const numberedNewJobs = newJobs.map(job => {
          // Keep existing number if valid, otherwise generate
          if (job.jobNumber && job.jobNumber > 100000) return job;

          maxJobNum = getNextJobNumber(maxJobNum);
          return { ...job, jobNumber: maxJobNum };
        });

        finalJobs = [...finalJobs, ...numberedNewJobs];

        const importLog: ActionLog = {
          id: generateId(),
          timestamp: Date.now(),
          type: 'IMPORT',
          description: `Imported ${numberedNewJobs.length} Jobs`,
          currentDataId: numberedNewJobs.length > 0 ? numberedNewJobs[0].id : undefined // Simplified tracking
        };
        newHistory = addToHistory(newHistory, importLog);
      }

      console.log("   ✅ RESOLUTION COMPLETE. New Total:", finalJobs.length);
      return {
        ...prev,
        jobs: finalJobs,
        history: newHistory
      };
    });
  };

  const deleteJobs = (ids: string[]) => {
    setState(prev => {
      const deletedJobs = prev.jobs.filter(j => ids.includes(j.id));
      if (deletedJobs.length === 0) return prev;

      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'DELETE',
        description: `Deleted ${ids.length} Job(s)`,
        previousData: deletedJobs // Store array of jobs to restore
      };

      return {
        ...prev,
        jobs: prev.jobs.filter(j => !ids.includes(j.id)),
        history: addToHistory(prev.history, log)
      };
    });
  };

  const importJobs = (newJobs: Job[], dateRange?: { start: Date; end: Date } | null) => {
    setState(prev => {
      // Calculate Seed
      let maxJobNum = prev.jobs.reduce((max, j) => Math.max(max, j.jobNumber || 0), 100100);

      const numberedNewJobs = newJobs.map(job => {
        // Keep existing number if valid, otherwise generate
        if (job.jobNumber && job.jobNumber > 100000) return job;

        maxJobNum = getNextJobNumber(maxJobNum);
        return { ...job, jobNumber: maxJobNum };
      });

      const log: ActionLog = {
        id: generateId(),
        timestamp: Date.now(),
        type: 'IMPORT',
        description: `Imported ${numberedNewJobs.length} Jobs`,
        currentDataId: numberedNewJobs.map(j => j.id) // Track IDs to potentially undo import
      };

      return {
        ...prev,
        jobs: [...prev.jobs, ...numberedNewJobs],
        focusDateRange: dateRange || undefined,
        history: addToHistory(prev.history, log)
      };
    });
  };

  // --- UNDO ENGINE ---
  const undoAction = (actionId: string) => {
    setState(prev => {
      const action = prev.history.find(a => a.id === actionId);
      if (!action) return prev;

      let restoredJobs = [...prev.jobs];

      // 1. REVERT UPDATE: Restore old job data
      if (action.type === 'UPDATE' && action.previousData) {
        const oldData = action.previousData as Job;
        restoredJobs = restoredJobs.map(j => j.id === oldData.id ? oldData : j);
      }
      // 2. REVERT DELETE: Add back deleted jobs
      else if (action.type === 'DELETE' && action.previousData) {
        const deletedJobs = action.previousData as Job[];
        restoredJobs = [...restoredJobs, ...deletedJobs];
      }
      // 3. REVERT CREATE/IMPORT: Remove created jobs
      else if ((action.type === 'CREATE' || action.type === 'IMPORT') && action.currentDataId) {
        const idsToRemove = Array.isArray(action.currentDataId)
          ? action.currentDataId
          : [action.currentDataId];
        restoredJobs = restoredJobs.filter(j => !idsToRemove.includes(j.id));
      }

      return {
        ...prev,
        jobs: restoredJobs,
        history: prev.history.filter(a => a.id !== actionId) // Remove from history
      };
    });
  };

  const clearAllData = () => {
    setState(defaultState);
    localStorage.removeItem(STORAGE_KEY);
  };

  // --- PRICING ACTIONS ---

  const updatePrices = (prices: PriceTable) => {
    setState(prev => ({ ...prev, prices }));
  };

  const setActiveYear = (year: number) => {
    setState(prev => ({ ...prev, activeYear: year }));
  };

  const updateGlobalPrice = (year: number, category: string, size: string, price: PriceConfig) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      let yearIdx = newData.findIndex(y => y.year === year);

      if (yearIdx === -1) {
        // Create year if doesn't exist (Clone default structure)
        newData.push({
          year,
          global: JSON.parse(JSON.stringify(DEFAULT_PRICES)),
          overrides: []
        });
        yearIdx = newData.length - 1;
      }

      const targetYear = newData[yearIdx];
      if (!targetYear.global[category]) targetYear.global[category] = {};
      targetYear.global[category][size] = price;

      // NEW LOGIC: If this is a new Size we haven't seen before, add it to the dropdown list
      // This ensures "what you add here affects everything"
      let newLists = prev.lists;
      const normalizedSize = size.trim();
      if (normalizedSize && !prev.lists.sizes.some(s => s.toLowerCase() === normalizedSize.toLowerCase())) {
        newLists = {
          ...prev.lists,
          sizes: [...prev.lists.sizes, normalizedSize]
        };
      }

      return { ...prev, pricingData: newData, lists: newLists };
    });
  };

  const deleteGlobalPrice = (year: number, category: string, size: string) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      const yearData = newData.find(y => y.year === year);
      if (yearData && yearData.global[category]) {
        const newCategory = { ...yearData.global[category] };
        delete newCategory[size];
        yearData.global[category] = newCategory;
      }
      return { ...prev, pricingData: newData };
    });
  };

  const addPriceOverride = (year: number, override: PricingOverride) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      let targetYear = newData.find(y => y.year === year);
      if (!targetYear) {
        targetYear = { year, global: JSON.parse(JSON.stringify(DEFAULT_PRICES)), overrides: [] };
        newData.push(targetYear);
      }
      // Remove existing override for same prop/cat/size if exists
      targetYear.overrides = targetYear.overrides.filter(o =>
        !(o.propertyId === override.propertyId && o.category === override.category && o.size === override.size)
      );
      targetYear.overrides.push(override);
      return { ...prev, pricingData: newData };
    });
  };

  const removePriceOverride = (year: number, propertyId: string, category: string, size: string) => {
    setState(prev => {
      const newData = [...prev.pricingData];
      const targetYear = newData.find(y => y.year === year);
      if (targetYear) {
        targetYear.overrides = targetYear.overrides.filter(o =>
          !(o.propertyId === propertyId && o.category === category && o.size === size)
        );
      }
      return { ...prev, pricingData: newData };
    });
  };

  // --- APP CONFIG (NEW) ---
  const updateAppConfig = (updates: Partial<AppConfig>) => {
    setState(prev => ({
      ...prev,
      appConfig: { ...prev.appConfig, ...updates }
    }));
  };

  // --- EMPLOYEE ACTIONS (NEW) ---
  const addEmployee = (employee: Employee) => {
    setState(prev => ({ ...prev, employees: [...prev.employees, employee] }));
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setState(prev => ({
      ...prev,
      employees: prev.employees.map(e => e.id === id ? { ...e, ...updates } : e)
    }));
  };

  const deleteEmployee = (id: string) => {
    setState(prev => ({
      ...prev,
      employees: prev.employees.filter(e => e.id !== id)
    }));
  };

  // --- LINK ACTIONS ---
  const addQuickLink = (link: QuickLink) => {
    setState(prev => ({ ...prev, quickLinks: [...prev.quickLinks, link] }));
  };

  const deleteQuickLink = (id: string) => {
    setState(prev => ({ ...prev, quickLinks: prev.quickLinks.filter(l => l.id !== id) }));
  };

  // --- TASK ACTIONS ---
  const addTask = (text: string) => {
    const newTask = { id: generateId(), text, completed: false, createdAt: Date.now() };
    setState(prev => ({ ...prev, tasks: [newTask, ...prev.tasks] }));
  };

  const toggleTask = (id: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
    }));
  };

  const deleteTask = (id: string) => {
    setState(prev => ({ ...prev, tasks: prev.tasks.filter(t => t.id !== id) }));
  };

  const updateTask = (id: string, text: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => t.id === id ? { ...t, text } : t)
    }));
  };

  const reorderTasks = (tasks: Task[]) => {
    setState(prev => ({ ...prev, tasks }));
  };

  const setTasks = (tasks: Task[]) => {
    setState(prev => ({ ...prev, tasks }));
  };

  // --- API CONFIG ACTIONS ---
  const addApiConfig = (config: ApiConfig) => {
    setState(prev => ({ ...prev, apiConfigs: [...(prev.apiConfigs || []), config] }));
  };

  const updateApiConfig = (id: string, updates: Partial<ApiConfig>) => {
    setState(prev => ({
      ...prev,
      apiConfigs: (prev.apiConfigs || []).map(c => c.id === id ? { ...c, ...updates } : c)
    }));
  };

  const deleteApiConfig = (id: string) => {
    setState(prev => ({
      ...prev,
      apiConfigs: (prev.apiConfigs || []).filter(c => c.id !== id)
    }));
  };

  // --- PREPAID ACTIONS ---
  const updatePrepaidList = (key: string, units: string[]) => {
    setState(prev => ({
      ...prev,
      prepaidUnits: { ...prev.prepaidUnits, [key]: units }
    }));
  };

  const updateProperty = (id: string, updates: Partial<Property>) => {
    setState(prev => ({
      ...prev,
      properties: prev.properties.map(p => p.id === id ? { ...p, ...updates } : p)
    }));
  };

  const addProperty = (property: Property) => {
    setState(prev => ({
      ...prev,
      properties: [...prev.properties, property]
    }));
  };

  // View
  const setJobsViewMode = (mode: JobsViewMode) => {
    setState(prev => {
      // If we are switching OUT of duplicates/duplicates_only, save the previous mode
      // But only if the new mode is DUPLICATE focused
      if (mode === 'DUPLICATES_ONLY' && prev.viewMode !== 'DUPLICATES_ONLY') {
        return { ...prev, viewMode: mode, lastNonDuplicateMode: prev.viewMode };
      }
      return { ...prev, viewMode: mode };
    });
  };

  const setViewLayout = (layout: 'list' | 'card') => {
    setState(prev => ({ ...prev, viewLayout: layout }));
  };

  const setSearchTerm = (term: string) => {
    setState(prev => ({ ...prev, searchTerm: term }));
  };

  const setFocusDateRange = (range: { start: Date; end: Date } | undefined) => {
    setState(prev => ({ ...prev, focusDateRange: range }));
  };

  const setDateViewUnit = (unit: 'day' | 'week' | 'month' | 'biweek') => {
    setState(prev => ({ ...prev, dateViewUnit: unit }));
  };

  const updateSettings = (newSettings: Partial<AppState['settings']>) => {
    setState(prev => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings }
    }));
  };



  const addLog = (log: LogEntry) => {
    setState(prev => ({ ...prev, systemLogs: [...prev.systemLogs, log] }));
  };

  const setIsImporting = (val: boolean) => {
    setState(prev => ({ ...prev, isImporting: val }));
  };

  if (!isLoaded) return <div className="flex h-screen items-center justify-center text-slate-500">Loading Aroma Op-x {APP_VERSION}...</div>;

  return (
    <AppContext.Provider value={{
      ...state,
      addJob,
      updateJob,
      updateJobs,
      resolveImportConflicts,
      deleteJobs,
      importJobs,
      clearAllData,
      undoAction,
      updatePrices,
      setActiveYear,
      updateGlobalPrice,
      deleteGlobalPrice,
      addPriceOverride,
      removePriceOverride,
      updateAppConfig, // NEW
      updateProperty,
      addProperty,
      addEmployee,
      updateEmployee,
      deleteEmployee,
      addQuickLink,
      deleteQuickLink,
      addTask,
      toggleTask,
      deleteTask,
      updatePrepaidList,
      setJobsViewMode,
      setViewLayout,
      setSearchTerm,
      setFocusDateRange,
      setDateViewUnit, // Added
      addLog,
      setIsImporting,
      updateSettings,
      t,
      addApiConfig,
      updateApiConfig,
      deleteApiConfig,
      updateTask,
      reorderTasks,
      setTasks,
      refreshFromStorage // Added
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
