import React from 'react';
import SettingsView from '../components/SettingsView';

const SettingsPage: React.FC = () => {
    return <SettingsView />;
};

export default SettingsPage;
