import React from 'react';
import DailyReportView from '../components/DailyReportView';

const DailyReportPage: React.FC = () => {
    return <DailyReportView />;
};

export default DailyReportPage;
