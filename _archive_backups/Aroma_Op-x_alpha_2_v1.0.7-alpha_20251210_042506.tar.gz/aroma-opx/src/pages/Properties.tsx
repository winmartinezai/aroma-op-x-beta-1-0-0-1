import React from 'react';
import PropertiesView from '../components/PropertiesView';

const PropertiesPage: React.FC = () => {
    return <PropertiesView />;
};

export default PropertiesPage;
