import React from 'react';
import EmployeesView from '../components/EmployeesView';

const EmployeesPage: React.FC = () => {
    return <EmployeesView />;
};

export default EmployeesPage;
