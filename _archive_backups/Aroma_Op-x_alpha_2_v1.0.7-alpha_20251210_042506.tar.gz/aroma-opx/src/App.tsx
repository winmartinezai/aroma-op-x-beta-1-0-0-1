import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation, Outlet } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/Sidebar';
import StatusBoard from './components/StatusBoard';
import DateChooserDial from './components/DateChooserDial'; // Imported
import Dashboard from './pages/Dashboard';
import JobsMaster from './pages/JobsMaster';
import PropertiesPage from './pages/Properties';
import EmployeesPage from './pages/Employees';
import SettingsPage from './pages/Settings';
import DailyReportPage from './pages/DailyReport';
import type { View } from './types/types'; // Check types path
import { Menu } from 'lucide-react';
import { APP_VERSION } from './utils/constants';

// Layout Component
const Layout: React.FC = () => {
  const { systemLogs, isImporting, settings, t, focusDateRange, setFocusDateRange, setJobsViewMode } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isStatusBoardOpen, setIsStatusBoardOpen] = useState(false);
  const [autoOpenLogs, setAutoOpenLogs] = useState(true);

  // Map location to View ID for Sidebar highlighting
  const getCurrentView = (): View => {
    const path = location.pathname;
    if (path === '/' || path.includes('dashboard')) return 'dashboard';
    if (path.includes('jobs')) return 'jobs';
    if (path.includes('employees')) return 'employees';
    if (path.includes('properties')) return 'properties';
    if (path.includes('settings')) return 'settings';
    if (path.includes('daily-report')) return 'daily-report';
    return 'dashboard';
  };

  const currentView = getCurrentView();

  const handleViewChange = (view: View) => {
    if (view === 'dashboard') navigate('/');
    else navigate('/' + view);
  };

  // Auto-open logs
  useEffect(() => {
    const savedPref = localStorage.getItem('aroma_auto_open_logs');
    if (savedPref !== null) setAutoOpenLogs(savedPref === 'true');
  }, []);

  const handleSetAutoOpenLogs = (val: boolean) => {
    setAutoOpenLogs(val);
    localStorage.setItem('aroma_auto_open_logs', String(val));
  };

  useEffect(() => {
    if (autoOpenLogs && systemLogs.length > 0) {
      const lastLog = systemLogs[systemLogs.length - 1];
      if (lastLog.type === 'error' || lastLog.type === 'magic') {
        setIsStatusBoardOpen(true);
      }
    }
  }, [systemLogs, autoOpenLogs]);

  return (
    <div
      className="flex h-screen bg-slate-50 text-slate-900 font-sans overflow-hidden transition-all duration-300 ease-in-out"
      style={{ zoom: settings.uiScale || 1 }}
    >
      <Sidebar
        currentView={currentView}
        onChangeView={handleViewChange}
        collapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Top Header */}
        <header className="bg-white border-b border-slate-200 shrink-0 z-10 relative flex flex-col">
          <div className="h-16 flex items-center justify-between px-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                className="md:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
              >
                <Menu size={20} />
              </button>
              <h1 className="text-xl font-bold text-slate-800 uppercase tracking-tight">{t(currentView)}</h1>
            </div>

            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none">
              <h2 className="text-xl font-black text-slate-800 tracking-tight leading-none drop-shadow-sm">Aroma Op-x</h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">OPERATIONS</span>
                <span className="text-[10px] text-slate-400 font-medium ml-1">v{APP_VERSION}</span>
              </div>
              <div className="text-[9px] text-slate-400 font-bold tracking-widest mt-0.5">
                Dev By Win Martinez <span className="text-red-500">Ai</span>
              </div>
            </div>
            <div className="w-20"></div>
          </div>

          {/* GLOBAL DATE DIAL - Persistent across all views */}
          <div className="px-4 pb-2">
            <DateChooserDial
              currentRange={focusDateRange || null}
              onRangeChange={(range) => {
                setFocusDateRange(range || undefined);
                // ⚡ SYNC FIX: If user spins the dial, force view mode to DATE_FILTERED
                // This ensures they don't get stuck in "VIEW_ALL" while trying to pick a date.
                setJobsViewMode('DATE_FILTERED');
              }}
              onClear={() => {
                setFocusDateRange(undefined);
                // If clearing, maybe we want 'VIEW_ALL'?
                // But typically the Dial clear button implies "Show All" or "Reset".
                // 'VIEW_ALL' mode ignores the dial range anyway.
                // Let's set it to VIEW_ALL for clarity.
                setJobsViewMode('VIEW_ALL');
              }}
              hasActiveFilter={!!focusDateRange}
            />
          </div>
        </header>

        <main className="flex-1 overflow-hidden relative">
          <Outlet />
        </main>

        {settings.enableDebugConsole && (
          <StatusBoard
            logs={systemLogs}
            isOpen={isStatusBoardOpen}
            setIsOpen={setIsStatusBoardOpen}
            isProcessing={isImporting}
            autoOpen={autoOpenLogs}
            setAutoOpen={handleSetAutoOpenLogs}
          />
        )}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="jobs" element={<JobsMaster />} />
            <Route path="employees" element={<EmployeesPage />} />
            <Route path="properties" element={<PropertiesPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="daily-report" element={<DailyReportPage />} />
          </Route>
        </Routes>
      </HashRouter>
    </AppProvider>
  );
};

export default App;
