import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
  type VisibilityState,
  type RowSelectionState
} from '@tanstack/react-table';
import {
  Search, Plus, Trash2,
  MoreHorizontal, CheckSquare, Square, ArrowUpDown,
  ChevronLeft, ChevronRight,
  FileText, Briefcase,
  X, Eye, EyeOff, FolderInput,
  Crown, Edit2, ListFilter, Layers, Hourglass,
  AlertTriangle, CheckCircle, AlertCircle, RotateCcw, HelpCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { Job } from '../types/types';
// import type { JobsViewMode } from '../types/types';
import { formatCurrency, formatDate, generateId } from '../utils/helpers';
import { parseFile } from '../services/importService';
// import { isValidFileName } from '../services/importService';
import DuplicateResolutionModal from './DuplicateResolutionModal';
import JobEditModal from './JobEditModal';
// import InvoiceStagingModal from './InvoiceStagingModal';
// DateHeader and ContactsPortals moved to JobsMaster page

import JobsHistoryWidget, { type JobHistoryAction } from './JobsHistoryWidget';
// import DraggablePanel from './DraggablePanel';
import ExtrasModal from './ExtrasModal';
import { useClickOutside } from '../hooks/useClickOutside';
import { generateInvoiceNote } from '../utils/pricing';
// import { calculatePrice } from '../utils/pricing';

import EmployeeBadge from './EmployeeBadge';
import PortalDropdown from './PortalDropdown';
import JobCard from './JobCard';

const JobsTable: React.FC = () => {
  const {
    jobs, deleteJobs, updateJob, addJob, // t,
    focusDateRange, setFocusDateRange,
    viewMode, setJobsViewMode,
    viewLayout, setViewLayout, // Layout
    searchTerm, setSearchTerm, // Global Search
    addLog, setIsImporting, isImporting,
    employees,
    settings,
    appConfig,
    refreshFromStorage
  } = useApp();

  /* const [rowSelection, setRowSelection] = useState<RowSelectionState>({}); */
  // Use local state if TanStack doesn't persist, or sync with TanStack.
  // Actually, utilize TanStack's state directly via table.getState().rowSelection for reads if needed, 
  // but we control it here.
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});

  const [sorting, setSorting] = useState<SortingState>([{ id: 'date', desc: false }]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 50 });

  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  /* const [isStagingOpen, setIsStagingOpen] = useState(false); */

  // Local History State
  const [localHistory, setLocalHistory] = useState<JobHistoryAction[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const historyButtonRef = useRef<HTMLButtonElement>(null);
  /* const [historyPosition, setHistoryPosition] = useState({ x: 100, y: 100 }); */
  const [extrasModalJob, setExtrasModalJob] = useState<Job | null>(null);

  // Menus
  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const columnMenuRef = useRef<HTMLButtonElement>(null);
  useClickOutside(columnMenuRef, () => setShowColumnMenu(false));
  const [showHidden, setShowHidden] = useState(false);

  // Advanced Filters
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const filterMenuRef = useRef<HTMLButtonElement>(null);
  useClickOutside(filterMenuRef, () => setShowFilterMenu(false));
  const [statusFilters, setStatusFilters] = useState<Set<string>>(new Set());
  const [employeeFilters, setEmployeeFilters] = useState<Set<string>>(new Set());

  // Import State
  const { importJobs, /* updateJobs, */ resolveImportConflicts } = useApp();
  // Modal State
  const [duplicateModalOpen, setDuplicateModalOpen] = useState(false);

  interface ModalState {
    type: 'ALERT' | 'CONFIRM';
    title: string;
    message: string;
    onConfirm?: () => void;
  }
  const [activeModal, setActiveModal] = useState<ModalState | null>(null);

  const [pendingDuplicates, setPendingDuplicates] = useState<{ existing: Job; new: Job }[]>([]);
  const [pendingNonDuplicates, setPendingNonDuplicates] = useState<Job[]>([]);
  const [pendingDateRange, setPendingDateRange] = useState<{ start: Date; end: Date } | null>(null);

  // --- DUPLICATE DETECTION (Persistent) ---
  const duplicateCount = useMemo(() => {
    const signatures = jobs.map(j => `${j.property}|${j.apt}|${j.type}|${j.date}`);
    const counts: { [key: string]: number } = {};
    signatures.forEach(s => counts[s] = (counts[s] || 0) + 1);
    return Object.values(counts).filter(c => c > 1).reduce((sum, c) => sum + c, 0);
  }, [jobs]);

  const [showDuplicatesOnly, setShowDuplicatesOnly] = useState(false);
  const handleShowDuplicates = () => setShowDuplicatesOnly(true);

  const readyToBillCount = useMemo(() => {
    return jobs.filter(j => j.status === 'Complete' && j.invoiceStatus !== 'Sent').length;
  }, [jobs]);



  // --- FILTER LOGIC (Preserved from original) ---
  // We compute filtered data FIRST, then pass to TanStack.
  // This ensures our custom "View Mode" logic is respected.
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // 0. Duplicates Filter (Highest Priority)
      if (showDuplicatesOnly) {
        const sig = `${job.property}|${job.apt}|${job.type}|${job.date}`;
        const count = jobs.filter(j => `${j.property}|${j.apt}|${j.type}|${j.date}` === sig).length;
        return count > 1;
      }

      // 1. Search Filter (Global Priority)
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        return Object.entries(job).some(([key, value]) => {
          if (String(value).toLowerCase().includes(term)) return true;
          if (key === 'date' && typeof value === 'string') {
            const d = new Date(value);
            if (!isNaN(d.getTime())) {
              const formats = [
                d.toLocaleDateString('en-US', { month: 'short' }),
                d.toLocaleDateString('en-US', { month: 'long' }),
                d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
              ];
              return formats.some(f => f.toLowerCase().includes(term));
            }
          }
          return false;
        });
      }

      // 2. View Mode Filter
      let matchesMode = true;
      switch (viewMode) {
        case 'DATE_FILTERED':
          if (focusDateRange) {
            const jobDate = new Date(job.date);
            const start = new Date(focusDateRange.start);
            start.setHours(0, 0, 0, 0); // Use setHours 0 for accurate day comparison
            const end = new Date(focusDateRange.end);
            end.setHours(23, 59, 59, 999);
            matchesMode = jobDate >= start && jobDate <= end;
          }
          break;
        case 'VIEW_ALL': matchesMode = true; break;
        case 'READY_TO_BILL': matchesMode = job.status === 'Complete' && job.invoiceStatus !== 'Sent'; break;
        case 'OPEN_JOBS': matchesMode = job.status !== 'Paid' && job.status !== 'Cancel'; break;
        case 'PRIVATE_ONLY': matchesMode = job.isPrivate === true; break;
      }
      if (!matchesMode) return false;

      // 3. Global Date Filter Override
      // BUG FIX: Ensure 'VIEW_ALL' explicitly BYPASSES this check.
      // We only want the Global Dial to enforce date range on other specialized views (like 'OPEN_JOBS' maybe?)
      // Actually, if ViewMode is DATE_FILTERED, it's already handled.
      // If ViewMode is VIEW_ALL, we want NO date filter.
      // Unsure about READY_TO_BILL etc. Usually Global Dial should constrain those too? 
      // User said "show me the jobs on memory".
      // Safest fix: If viewMode is VIEW_ALL, SKIP this override.
      if (settings.dateDialVisibility === 'everywhere' && focusDateRange && viewMode !== 'DATE_FILTERED' && viewMode !== 'VIEW_ALL') {
        const jobDate = new Date(job.date);
        const start = new Date(focusDateRange.start); start.setHours(0, 0, 0, 0);
        const end = new Date(focusDateRange.end); end.setHours(23, 59, 59, 999);
        if (!(jobDate >= start && jobDate <= end)) return false;
      }

      // 4. Hide Hidden
      if (!showHidden && !searchTerm && viewMode !== 'VIEW_ALL') {
        // Apply hiding logic unless we are in View All or Searching
        if (job.status === 'Complete' && job.invoiceStatus === 'Sent') return false;
      }

      // 5. Advanced Filters
      if (statusFilters.size > 0 && !statusFilters.has(job.status)) return false;
      if (employeeFilters.size > 0 && !employeeFilters.has(job.assignedTo)) return false;

      // 6. Special View Mode Filters (Lowest Priority Logic, overrides others if matched)
      if (viewMode === 'READY_TO_BILL') {
        return job.status === 'Complete' && job.invoiceStatus !== 'Sent';
      }
      if (viewMode === 'OPEN_JOBS') {
        return job.status !== 'Complete' && job.status !== 'Cancel' && job.status !== 'Paid';
      }
      if (viewMode === 'PRIVATE_ONLY') {
        return job.isPrivate === true;
      }
      if (viewMode === 'MISSING_PO') {
        // Show jobs that are Complete/Verified but likely need PO.
        // Typically Complete jobs.
        // And missing PO field.
        return job.status === 'Complete' && (!job.po || job.po.trim() === '');
      }

      return true;
    });
  }, [jobs, searchTerm, viewMode, focusDateRange, settings.dateDialVisibility, showHidden, statusFilters, employeeFilters, showDuplicatesOnly]);

  // SYNC: Message Board should reflect the FILTERED view (what the user sees)
  const pendingInvoicesCount = useMemo(() => {
    return filteredJobs.filter(j => j.status === 'Complete' && j.invoiceStatus !== 'Sent').length;
  }, [filteredJobs]);

  // AUTO-SWITCH: If user moves the dial (focusDateRange changes), automatically switch to DATE_FILTERED
  useEffect(() => {
    if (focusDateRange) {
      setJobsViewMode('DATE_FILTERED');
    }
  }, [focusDateRange]);

  // --- TABLE COLUMNS DEFINITION ---
  const columns = useMemo<ColumnDef<Job>[]>(() => [
    // 1. Row Index (Count) - MOVED TO FIRST
    {
      id: 'index',
      header: '#',
      cell: info => <div className="text-slate-400 text-[10px] font-mono">{info.row.index + 1}</div>,
      size: 30,
    },
    {
      id: 'select',
      header: ({ table }) => (
        <button
          onClick={table.getToggleAllRowsSelectedHandler()}
          className="flex items-center justify-center text-slate-400 hover:text-slate-600"
        >
          {table.getIsAllRowsSelected() ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
        </button>
      ),
      cell: ({ row }) => (
        <button
          onClick={row.getToggleSelectedHandler()}
          className="flex items-center justify-center text-slate-300 hover:text-blue-500"
        >
          {row.getIsSelected() ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
        </button>
      ),
      size: 40,
    },
    // 2. Job Number (6 Digits)
    {
      accessorKey: 'jobNumber',
      header: 'Job #',
      cell: info => {
        const val = info.getValue() as number;
        return (
          <div className="font-mono font-bold text-slate-600 text-xs">
            {val ? val.toString().padStart(6, '0') : '-'}
          </div>
        );
      },
      size: 70,
    },
    {
      accessorKey: 'property',
      header: 'Property',
      cell: info => <div className="font-bold text-slate-700 truncate" title={info.getValue() as string}>{info.getValue() as string}</div>,
      size: 160,
    },
    {
      accessorKey: 'apt',
      header: 'Unit',
      cell: info => <div className="font-bold text-slate-800 truncate">{info.getValue() as string}</div>,
      size: 60,
    },
    {
      accessorKey: 'type',
      header: 'Service',
      cell: info => <div className="font-bold text-slate-600 uppercase text-[10px] truncate">{info.getValue() as string}</div>,
      size: 100,
    },
    {
      accessorKey: 'size',
      header: 'Size',
      cell: info => <div className="text-slate-500 truncate">{info.getValue() as string}</div>,
      size: 60,
    },
    {
      accessorKey: 'date',
      header: 'Date',
      cell: info => <div className="font-mono text-slate-600 truncate">{formatDate(info.getValue() as string)}</div>,
      size: 90,
    },
    {
      accessorKey: 'assignedTo',
      header: 'Tech',
      cell: info => {
        const name = info.getValue() as string;
        const emp = employees.find(e => e.name === name);
        return name ? (
          <EmployeeBadge
            name={name}
            color={emp?.color}
            size="sm"
          />
        ) : null;
      },
      size: 120,
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const status = row.original.status;
        return (
          <div className="flex items-center gap-1.5">
            {/* Customized Status Dot */}
            <div
              className="w-4 h-4 rounded-full shrink-0 flex items-center justify-center text-[8px] font-bold text-white shadow-sm transition-all"
              style={{
                backgroundColor: appConfig.STATUS_COLORS?.[status]?.color || '#cbd5e1'
              }}
              title={status}
            >
              {appConfig.STATUS_COLORS?.[status]?.letter || ''}
            </div>
            <select
              value={status}
              onChange={(e) => handleStatusChange(row.original.id, e.target.value as any)}
              className="bg-transparent border-none text-slate-600 text-xs focus:ring-0 cursor-pointer truncate w-full p-0"
            >
              <option value="Pending">Pending</option>
              <option value="In Progress">In Progress</option>
              <option value="Complete">Complete</option>
              <option value="Paid">Paid</option>
              <option value="Cancel">Cancel</option>
            </select>
          </div>
        );
      },
      size: 140,
    },
    {
      accessorKey: 'invoiceStatus',
      header: 'Inv Status',
      cell: ({ row }) => (
        <select
          value={row.original.invoiceStatus}
          onChange={(e) => handleInvoiceStatusChange(row.original.id, e.target.value as any)}
          className={`px-1.5 py-0.5 rounded text-[10px] font-bold border appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/20 w-full truncate ${row.original.invoiceStatus === 'Sent' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
            row.original.invoiceStatus === 'Draft' ? 'bg-amber-50 text-amber-700 border-amber-100' :
              'bg-slate-50 text-slate-400 border-slate-100'
            }`}
        >
          <option value="None">-</option>
          <option value="Draft">Draft</option>
          <option value="Sent">Sent</option>
        </select>
      ),
      size: 80,
    },
    {
      accessorKey: 'invoiceNumber',
      header: 'Inv #',
      cell: ({ row }) => (
        <input
          type="text"
          defaultValue={row.original.invoiceNumber || ''}
          onBlur={(e) => {
            const val = e.target.value.trim();
            if (val !== (row.original.invoiceNumber || '')) {
              updateJob(row.original.id, { invoiceNumber: val });
            }
          }}
          className="bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none text-slate-600 font-mono text-xs py-0.5 w-full placeholder-slate-300"
          placeholder="-"
        />
      ),
      size: 80,
    },
    {
      accessorKey: 'extras',
      header: 'Extras',
      cell: ({ row }) => (
        <div className="flex items-center justify-between group/extras">
          <span className="text-slate-600 truncate" title={row.original.extras}>{row.original.extras || '-'}</span>
          <button onClick={() => setExtrasModalJob(row.original)} className="opacity-0 group-hover/extras:opacity-100 p-1 text-blue-500 hover:bg-blue-50 rounded transition-all shrink-0">
            <Plus size={12} />
          </button>
        </div>
      ),
      size: 150,
    },
    {
      accessorKey: 'notes',
      header: 'Notes',
      cell: info => <div className="text-slate-500 italic truncate" title={info.getValue() as string}>{info.getValue() as string}</div>,
      size: 120,
    },
    {
      accessorKey: 'invoiceNote',
      header: 'Inv. Note',
      cell: ({ row }) => (
        <div className="flex justify-between items-center group/note">
          <span className="truncate text-slate-500 text-[10px]" title={row.original.invoiceNote}>{row.original.invoiceNote}</span>
          {row.original.invoiceNote && (
            <button onClick={() => navigator.clipboard.writeText(row.original.invoiceNote || '')} className="opacity-0 group-hover/note:opacity-100 p-1 text-blue-500 hover:bg-blue-50 rounded">
              <FileText size={10} />
            </button>
          )}
        </div>
      ),
      size: 120,
    },
    {
      accessorKey: 'clientPrice',
      header: 'Price',
      cell: info => <div className="text-right font-mono text-slate-700 font-medium">{formatCurrency(info.getValue() as number)}</div>,
      size: 80,
    },
    {
      accessorKey: 'employeePrice',
      header: 'Pay',
      cell: ({ row }) => (
        <div className="relative group/pay">
          <div className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-400 text-[10px] pointer-events-none pl-1">$</div>
          <input
            type="number"
            step="0.01"
            defaultValue={row.original.employeePrice || 0}
            onBlur={(e) => {
              const val = parseFloat(e.target.value);
              if (!isNaN(val) && val !== row.original.employeePrice) {
                updateJob(row.original.id, { employeePrice: val });
              }
            }}
            className="text-right font-mono text-slate-500 w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none text-xs py-0.5 pl-3"
          />
        </div>
      ),
      size: 80,
    },
    {
      id: 'total',
      header: 'Total',
      cell: ({ row }) => <div className="text-right font-mono text-slate-800 font-bold">{formatCurrency((row.original.clientPrice || 0) + (row.original.extrasPrice || 0))}</div>,
      size: 80,
    },
    {
      id: 'isPrivate',
      header: () => <Crown size={14} className="mx-auto text-slate-400" />,
      cell: ({ row }) => (
        <button
          onClick={() => updateJob(row.original.id, { isPrivate: !row.original.isPrivate })}
          className={`p-1 rounded-full w-full flex justify-center ${row.original.isPrivate ? 'bg-purple-100 text-purple-600' : 'text-slate-300 hover:text-slate-400'}`}
        >
          <Crown size={14} fill={row.original.isPrivate ? "currentColor" : "none"} />
        </button>
      ),
      size: 40,
    },
    {
      id: 'actions',
      header: '',
      cell: ({ row }) => (
        <button onClick={() => setEditingJobId(row.original.id)} className="text-slate-400 hover:text-blue-600 w-full flex justify-center">
          <MoreHorizontal size={14} />
        </button>
      ),
      size: 40,
    }
  ], [employees]);

  // --- TANSTACK TABLE INSTANCE ---
  const table = useReactTable({
    data: filteredJobs,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
      columnVisibility,
      rowSelection,
      pagination
    },
    onSortingChange: setSorting,
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    onPaginationChange: setPagination,
    getRowId: (row: Job) => row.id, // Use our ID
    enableRowSelection: true,
  });

  // --- ACTIONS ---
  const addToHistory = (action: JobHistoryAction) => setLocalHistory(prev => [action, ...prev]);

  const handleAddJob = () => {
    // AUTO ASSIGN JOB NUMBER
    const maxJobNum = jobs.reduce((max, j) => (j.jobNumber && j.jobNumber > max ? j.jobNumber : max), 100100);
    let nextJobNum = maxJobNum + 1;
    // RULE: 4th digit cannot be 0.
    if (nextJobNum.toString()[3] === '0') {
      nextJobNum += 100;
    }

    const newJob: Job = {
      id: generateId(),
      date: new Date().toISOString(),
      jobNumber: nextJobNum, // Auto-assigned
      property: 'New Property',
      apt: 'Unit',
      type: 'Clean',
      size: '1x1',
      assignedTo: '',
      status: 'Pending',
      invoiceStatus: 'None',
      clientPrice: 0,
      employeePrice: 0,
      extrasPrice: 0,
      notes: '',
      extras: '',
      invoiceNote: ''
    };
    addJob(newJob);
    addToHistory({
      id: generateId(), timestamp: Date.now(), type: 'CREATE', description: `Created Job #${nextJobNum}`, jobId: newJob.id, user: 'You'
    });
    setEditingJobId(newJob.id);
  };

  // Handlers (Copy-Pasted logic from original but updated to use simple updateJob)
  // const addToHistory = (action: JobHistoryAction) => setLocalHistory(prev => [action, ...prev]);
  // ... (Other handlers like handleUndo, handleStatusChange, etc - keeping implementation compact for this file write)
  const handleStatusChange = (id: string, newStatus: Job['status']) => {
    const job = jobs.find(j => j.id === id); if (!job) return;
    updateJob(id, { status: newStatus });
  };
  const handleInvoiceStatusChange = (id: string, newStatus: Job['invoiceStatus']) => {
    updateJob(id, { invoiceStatus: newStatus });
  };
  const handleSaveExtras = (jobId: string, summary: string, total: number) => {
    const job = jobs.find(j => j.id === jobId); if (!job) return;
    const newInvoiceNote = generateInvoiceNote(job, summary);
    updateJob(jobId, { extras: summary, extrasPrice: total, invoiceNote: newInvoiceNote });
  };
  const handleUndo = (action: JobHistoryAction) => {
    if (action.type === 'CREATE' && action.jobId) deleteJobs([action.jobId]);
    // Simplistic Logic just for demo
    setLocalHistory(prev => prev.filter(a => a.id !== action.id));
  };




  // Import Handlers
  const onFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsImporting(true);
    let allParsedJobs: Job[] = [];
    let allLogs: any[] = [];
    let combinedDateRange: { start: Date; end: Date } | null = null;

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.name.match(/\.(xlsx|xls|csv)$/i)) continue;

        const parsedResult = await parseFile(file, jobs, appConfig);
        const { jobs: parsedJobs, logs: fileLogs, dateRange } = parsedResult;

        allParsedJobs = [...allParsedJobs, ...parsedJobs];
        allLogs = [...allLogs, ...fileLogs];

        if (dateRange) {
          if (!combinedDateRange) combinedDateRange = dateRange;
          else {
            if (dateRange.start < combinedDateRange.start) combinedDateRange.start = dateRange.start;
            if (dateRange.end > combinedDateRange.end) combinedDateRange.end = dateRange.end;
          }
        }
      }

      allLogs.forEach(log => addLog(log));

      if (allParsedJobs.length === 0) {
        alert('No valid jobs found in selected files.');
        setIsImporting(false);
        e.target.value = '';
        return;
      }

      // CHECK FOR DUPLICATES
      const duplicates: { existing: Job; new: Job }[] = [];
      const nonDuplicates: Job[] = [];

      allParsedJobs.forEach(newJob => {
        const existing = jobs.find(j =>
          j.property === newJob.property &&
          j.apt === newJob.apt &&
          j.type === newJob.type &&
          j.date === newJob.date
        );

        if (existing) {
          duplicates.push({ existing, new: newJob });
        } else {
          nonDuplicates.push(newJob);
        }
      });

      if (duplicates.length > 0) {
        setPendingDuplicates(duplicates);
        setPendingNonDuplicates(nonDuplicates);
        setPendingDateRange(combinedDateRange);
        setDuplicateModalOpen(true);
      } else {
        importJobs(nonDuplicates, combinedDateRange);
        alert(`Successfully imported ${nonDuplicates.length} jobs!`);
        if (combinedDateRange) {
          setFocusDateRange(combinedDateRange);
          setJobsViewMode('DATE_FILTERED');
        }
      }

    } catch (error: any) {
      console.error(error);
      addLog({
        id: generateId(),
        timestamp: new Date().toISOString(),
        type: 'error',
        message: 'Import failed',
        detail: error instanceof Error ? error.message : String(error)
      });
      alert('Import failed. Check logs.');
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  const handleDuplicateResolution = (resolutions: { [key: string]: 'skip' | 'overwrite' | 'keep_both' }) => {
    const finalJobsToImport = [...pendingNonDuplicates];
    const jobsToUpdate: Job[] = [];

    pendingDuplicates.forEach(d => {
      const action = resolutions[d.new.id];
      if (action === 'keep_both') {
        finalJobsToImport.push(d.new);
      } else if (action === 'overwrite') {
        const updatedJob = { ...d.new, id: d.existing.id };
        jobsToUpdate.push(updatedJob);
      }
    });

    if (finalJobsToImport.length > 0 || jobsToUpdate.length > 0) {
      resolveImportConflicts(finalJobsToImport, jobsToUpdate);
    }

    if (pendingDateRange) {
      setFocusDateRange(pendingDateRange);
      setJobsViewMode('DATE_FILTERED');
    }

    alert(`Import complete! Added ${finalJobsToImport.length}, Updated ${jobsToUpdate.length}.`);

    setDuplicateModalOpen(false);
    setPendingDuplicates([]);
    setPendingNonDuplicates([]);
    setPendingDateRange(null);
  };

  // LOST & FOUND Refresh
  const handleLostFoundRefresh = () => {
    if (confirm("Reset view and find all lost jobs?")) {
      refreshFromStorage();
      setSearchTerm('');
      setFocusDateRange(undefined);
      setJobsViewMode('VIEW_ALL');
      setStatusFilters(new Set());
      setEmployeeFilters(new Set());
      setShowDuplicatesOnly(false); // <--- RESET THIS
      setShowHidden(true);
      table.resetSorting();
      table.resetPagination();
      table.resetColumnVisibility();
      setTimeout(() => alert(`View Reset! Found ${jobs.length} jobs. (TanStack Engine Active)`), 200);
    }
  };

  // --- DEBUG RENDER ---
  console.log("🎨 RENDER TABLE:", {
    totalJobs: jobs.length,
    filtered: filteredJobs.length,
    rows: table.getRowModel().rows.length
  });

  // --- RENDER ---
  return (
    <div className="flex flex-row h-full bg-slate-50 relative overflow-visible">
      <div className="flex-1 flex flex-col min-w-0">

        {/* DATE HEADER & CONTACTS PORTALS REMOVED - Managed by JobsMaster Page */}


        {/* TOOLBAR */}
        <div className="bg-white border-b border-slate-200 p-2 flex flex-col md:flex-row gap-4 justify-between items-center shrink-0 shadow-sm z-50 relative overflow-visible">

          {/* LEFT: Tabs & Actions */}
          <div className="flex items-center gap-2 flex-wrap w-full md:w-auto">
            {/* DUPLICATE WARNING */}
            {duplicateCount > 0 && (
              <button
                onClick={handleShowDuplicates}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${showDuplicatesOnly ? 'bg-orange-100 text-orange-700 border-orange-300 ring-2 ring-orange-200' : 'bg-orange-50 text-orange-600 border-orange-200 hover:bg-orange-100'}`}
              >
                <AlertTriangle size={14} />
                <span>{duplicateCount} Duplicates Found</span>
                {showDuplicatesOnly && <X size={12} onClick={(e) => { e.stopPropagation(); setShowDuplicatesOnly(false); }} className="ml-1 hover:bg-orange-200 rounded" />}
              </button>
            )}

            <div className="flex bg-slate-100 p-1 rounded-lg shrink-0">
              <button onClick={handleAddJob} className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded-md text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm whitespace-nowrap">
                <Plus size={14} /> New Job
              </button>
              <div className="h-6 w-px bg-slate-200 mx-1"></div>

              {/* Layout Toggle */}
              <div className="bg-slate-100 p-1 rounded-lg flex items-center mr-2">
                <button
                  onClick={() => setViewLayout('list')}
                  className={`p-1.5 rounded transition-all ${viewLayout === 'list' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  title="List View"
                >
                  <ListFilter size={16} />
                </button>
                <button
                  onClick={() => setViewLayout('card')}
                  className={`p-1.5 rounded transition-all ${viewLayout === 'card' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  title="Card Grid"
                >
                  <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
                    <span className="bg-current rounded-[1px]"></span>
                    <span className="bg-current rounded-[1px]"></span>
                    <span className="bg-current rounded-[1px]"></span>
                    <span className="bg-current rounded-[1px]"></span>
                  </div>
                </button>
              </div>

              {/* View Mode Dropdown */}
              <button
                onClick={() => setJobsViewMode('VIEW_ALL')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'VIEW_ALL' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
              >
                <Layers size={14} />
                All
              </button>
              {/* Tabs */}
              <button
                onClick={() => setJobsViewMode(viewMode === 'OPEN_JOBS' ? 'DATE_FILTERED' : 'OPEN_JOBS')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'OPEN_JOBS' ? 'bg-slate-100 text-slate-800 border border-slate-200' : 'text-slate-500 hover:bg-slate-50'
                  }`}
              >
                <Briefcase size={14} />
                Open Jobs
              </button>

              <button
                onClick={() => setJobsViewMode(viewMode === 'READY_TO_BILL' ? 'DATE_FILTERED' : 'READY_TO_BILL')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'READY_TO_BILL' ? 'bg-red-50 text-red-700 border border-red-100' : 'text-slate-500 hover:bg-slate-50'
                  }`}
              >
                <CheckCircle size={14} />
                Ready to Bill
                {readyToBillCount > 0 && <span className="ml-1 bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full text-[10px]">{readyToBillCount}</span>}
              </button>

              <button
                onClick={() => setJobsViewMode(viewMode === 'PRIVATE_ONLY' ? 'DATE_FILTERED' : 'PRIVATE_ONLY')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'PRIVATE_ONLY' ? 'bg-purple-100 text-purple-700 border border-purple-200 shadow-sm' : 'text-slate-500 hover:bg-slate-50'
                  }`}
              >
                <Crown size={14} />
                Private / Direct
              </button>
            </div>

            {/* MESSAGE BOARD */}
            <div className="flex-1 flex justify-center hidden md:flex">
              <div className={`px-4 py-1.5 rounded-full border shadow-sm flex items-center gap-2 transition-all ${pendingInvoicesCount > 0 ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-emerald-50 border-emerald-200 text-emerald-700'}`}>
                {pendingInvoicesCount > 0 ? (
                  <>
                    <AlertCircle size={14} className="animate-pulse" />
                    <span className="text-xs font-bold">{pendingInvoicesCount} Invoices Pending</span>
                  </>
                ) : (
                  <>
                    <CheckCircle size={14} />
                    <span className="text-xs font-bold">All Caught Up!</span>
                  </>
                )}
              </div>
            </div>

            {/* CENTER: Icon Actions */}
            <div className="flex items-center gap-1 shrink-0">
              {/* DELETE SELECTED */}
              {Object.keys(rowSelection).length > 0 && (
                <button
                  onClick={() => {
                    const selectedIds = Object.keys(rowSelection);
                    setActiveModal({
                      type: 'CONFIRM',
                      title: 'Delete Selected?',
                      message: `Are you sure you want to delete ${selectedIds.length} selected job(s)?\n\nThis cannot be undone.`,
                      onConfirm: () => {
                        deleteJobs(selectedIds);
                        setRowSelection({});
                      }
                    });
                    // if (window.confirm(`Are you sure you want to delete ${selectedIds.length} selected job(s)?`)) {
                    //    deleteJobs(selectedIds);
                    //    setRowSelection({}); // Clear selection after delete
                    // }
                  }}
                  className="flex items-center gap-1 bg-red-50 text-red-600 border border-red-200 px-2 py-1.5 rounded hover:bg-red-100 transition-colors mr-2 animate-in fade-in slide-in-from-left-2"
                  title="Delete Selected Jobs"
                >
                  <Trash2 size={14} />
                  <span className="text-xs font-bold hidden sm:inline">Delete ({Object.keys(rowSelection).length})</span>
                </button>
              )}

              <button
                onClick={() => {
                  const selectedIds = Object.keys(rowSelection);
                  if (selectedIds.length === 1) {
                    setEditingJobId(selectedIds[0]);
                  } else if (selectedIds.length === 0) {
                    // Replaced native alert with a forced-interaction UI blocking modal-alert
                    // We can reuse DuplicateModal or just create a simple state for "alertMessage"
                    // But to be quick and clean, I'll add a simple <AlertModal /> logic below and set it here.
                    setActiveModal({
                      type: 'ALERT',
                      title: 'Selection Required',
                      message: "Please select a job first by clicking the checkbox."
                    });
                  } else {
                    setActiveModal({
                      type: 'ALERT',
                      title: 'Multiple Selection',
                      message: "Please select only ONE job to edit."
                    });
                  }
                }}
                className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded"
                title="Edit Selected Job"
              >
                <Edit2 size={14} />
              </button>

              {/* Column Menu (Restored) */}
              <div className="relative">
                <button
                  ref={columnMenuRef}
                  onClick={() => setShowColumnMenu(!showColumnMenu)}
                  className={`p-1.5 rounded transition-colors ${showColumnMenu ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                  title="Columns"
                >
                  <MoreHorizontal size={14} className="rotate-90" />
                </button>
                <PortalDropdown
                  isOpen={showColumnMenu}
                  onClose={() => setShowColumnMenu(false)}
                  triggerRef={columnMenuRef}
                  className="bg-white rounded-lg shadow-xl border border-slate-200 p-2 min-w-[200px]"
                >
                  <div className="text-[10px] font-bold text-slate-400 mb-2 uppercase px-1">Visible Columns</div>
                  {table.getAllLeafColumns().map(column => {
                    if (column.id === 'select' || column.id === 'actions') return null;
                    return (
                      <label key={column.id} className="flex items-center gap-2 px-2 py-1.5 hover:bg-slate-50 rounded cursor-pointer">
                        <input
                          type="checkbox"
                          checked={column.getIsVisible()}
                          onChange={column.getToggleVisibilityHandler()}
                          className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3"
                        />
                        <span className="text-xs capitalize">{column.id}</span>
                      </label>
                    );
                  })}
                </PortalDropdown>
              </div>

              {/* Filter Menu */}
              <div className="relative">
                <button
                  ref={filterMenuRef}
                  onClick={() => setShowFilterMenu(!showFilterMenu)}
                  className={`p-1.5 rounded transition-colors ${showFilterMenu || statusFilters.size > 0 || employeeFilters.size > 0 ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                  title="Sort & Filter"
                >
                  <ListFilter size={14} />
                </button>
                <PortalDropdown
                  isOpen={showFilterMenu}
                  onClose={() => setShowFilterMenu(false)}
                  triggerRef={filterMenuRef}
                  className="bg-white rounded-lg shadow-xl border border-slate-200 p-3 w-56 max-h-[80vh] overflow-y-auto"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-slate-500">SORT & FILTER</span>
                    {(statusFilters.size > 0 || employeeFilters.size > 0) && (
                      <button
                        onClick={() => { setStatusFilters(new Set()); setEmployeeFilters(new Set()); }}
                        className="text-[10px] text-red-500 hover:text-red-700 font-bold"
                      >
                        Clear Filters
                      </button>
                    )}
                  </div>
                  {/* Status Filters */}
                  <div className="mb-3">
                    <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase">Status</div>
                    {['Pending', 'In Progress', 'Complete', 'Paid', 'Cancel'].map(status => (
                      <label key={status} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                        <input
                          type="checkbox"
                          checked={statusFilters.has(status)}
                          onChange={() => {
                            const newSet = new Set(statusFilters);
                            if (newSet.has(status)) newSet.delete(status);
                            else newSet.add(status);
                            setStatusFilters(newSet);
                          }}
                          className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3"
                        />
                        <span className="text-xs">{status}</span>
                      </label>
                    ))}
                  </div>
                  {/* Employee Filters */}
                  <div>
                    <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase">Tech</div>
                    {employees.map(emp => (
                      <label key={emp.id} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                        <input
                          type="checkbox"
                          checked={employeeFilters.has(emp.name)}
                          onChange={() => {
                            const newSet = new Set(employeeFilters);
                            if (newSet.has(emp.name)) newSet.delete(emp.name);
                            else newSet.add(emp.name);
                            setEmployeeFilters(newSet);
                          }}
                          className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3"
                        />
                        <span className="text-xs">{emp.name}</span>
                      </label>
                    ))}
                  </div>
                </PortalDropdown>
              </div>

              {/* Column Selector */}
              <div className="relative">
                <button ref={columnMenuRef} onClick={() => setShowColumnMenu(!showColumnMenu)} className={`p-1.5 rounded transition-colors ${showColumnMenu ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`} title="Columns"><Layers size={14} /></button>
                {showColumnMenu && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-xl border border-slate-200 z-[100] p-2 max-h-[80vh] overflow-y-auto">
                    <div className="text-xs font-bold text-slate-500 mb-2 px-1">VISIBLE COLUMNS</div>
                    {table.getAllLeafColumns().map(column => {
                      if (column.id === 'select' || column.id === 'actions') return null;
                      return (
                        <label key={column.id} className="flex items-center gap-2 px-1 py-1 hover:bg-slate-50 rounded cursor-pointer">
                          <input
                            type="checkbox"
                            checked={column.getIsVisible()}
                            onChange={column.getToggleVisibilityHandler()}
                            className="rounded text-blue-600 focus:ring-blue-500"
                          />
                          <span className="text-xs capitalize">{column.id.replace(/([A-Z])/g, ' $1').trim()}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* History Toggle */}
              {/* History Toggle (Portal) */}
              <div className="relative">
                <button
                  ref={historyButtonRef}
                  onClick={() => setShowHistory(!showHistory)}
                  className={`p-1.5 rounded transition-colors ${showHistory ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                  title="Toggle History"
                >
                  <Hourglass size={14} />
                </button>
                <PortalDropdown
                  isOpen={showHistory}
                  onClose={() => setShowHistory(false)}
                  triggerRef={historyButtonRef}
                  className="min-w-[320px]"
                // Adjust position manually via style in PortalDropdown or specialized logic if needed,
                // but default bottom-left should be okay, maybe we want shifting left?
                // We'll trust the default for now (align left of button).
                // Actually, for right-side items, we usually want to align right edge.
                // But PortalDropdown default is left-aligned.
                >
                  <JobsHistoryWidget history={localHistory} onUndo={handleUndo} />
                </PortalDropdown>
              </div>

              {/* Show/Hide Hidden */}
              <button
                onClick={() => setShowHidden(!showHidden)}
                className={`p-1.5 rounded transition-colors ${showHidden ? 'bg-emerald-100 text-emerald-700' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                title={showHidden ? "Hide Completed & Sent Jobs" : "Show All (Including Completed & Sent)"}
              >
                {showHidden ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
            </div>

          </div>

          <div className="flex items-center gap-3">
            {/* Import Button */}
            <label className={`flex items-center gap-2 px-3 py-1.5 rounded-md cursor-pointer transition-all border ${isImporting ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white text-blue-600 border-blue-200 hover:bg-blue-50 hover:border-blue-300 shadow-sm'}`}>
              <FolderInput size={14} />
              <span className="font-bold text-xs hidden sm:inline">{isImporting ? 'Importing...' : 'Import Jobs'}</span>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                multiple
                className="hidden"
                onChange={onFileUpload}
                disabled={isImporting}
              />
            </label>

            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input type="text" placeholder="Search Property, Unit, Tech, Notes..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                className="w-48 pl-8 pr-3 py-1.5 text-xs rounded-md border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
            </div>

            <button onClick={handleLostFoundRefresh} className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-white text-slate-600 border border-slate-200 hover:bg-slate-50" title="Lost & Found">
              <RotateCcw size={14} /> <span className="font-bold text-xs hidden sm:inline">Refresh</span>
            </button>

            {/* Clear Jobs Button (Restored & Enhanced) */}
            <button
              onClick={() => {
                const visibleJobIds = table.getFilteredRowModel().rows.map(r => r.original.id);
                if (visibleJobIds.length === 0) {
                  alert("No visible jobs to delete.");
                  return;
                }
                setActiveModal({
                  type: 'CONFIRM',
                  title: '⚠️ Bulk Delete',
                  message: `DANGER: You are about to DELETE ${visibleJobIds.length} VISIBLE JOBS.\n\nThis action cannot be undone.\n\nAre you sure you want to proceed?`,
                  onConfirm: () => {
                    // We can add a second layer if we want, but for now single modal is robust enough if it blocks
                    deleteJobs(visibleJobIds);
                    addLog({
                      id: Date.now().toString(),
                      timestamp: new Date().toISOString(),
                      type: 'warning',
                      message: `User bulk deleted ${visibleJobIds.length} jobs.`
                    });
                  }
                });
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-white text-red-600 border border-red-200 hover:bg-red-50 hover:border-red-300 shadow-sm transition-colors"
              title="Delete All Visible Jobs"
            >
              <Trash2 size={14} />
              <span className="font-bold text-xs hidden sm:inline">Clear Visible</span>
            </button>
          </div>
        </div>

        {/* MAIN CONTENT AREA */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {viewLayout === 'card' ? (
            <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {table.getRowModel().rows.map(row => (
                  <JobCard
                    key={row.original.id}
                    job={row.original}
                    onEdit={(j) => setEditingJobId(j.id)}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="flex-1 overflow-auto custom-scrollbar relative">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 sticky top-0 z-30 shadow-sm">
                  {table.getHeaderGroups().map(headerGroup => (
                    <tr key={headerGroup.id}>
                      {headerGroup.headers.map(header => (
                        <th key={header.id} className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 select-none group hover:bg-slate-100 transition-colors cursor-pointer" style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}>
                          {header.isPlaceholder ? null : (
                            <div
                              {...{
                                className: header.column.getCanSort() ? 'flex items-center gap-1 cursor-pointer' : '',
                                onClick: header.column.getToggleSortingHandler(),
                              }}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                              {{
                                asc: <ArrowUpDown size={12} className="opacity-100" />,
                                desc: <ArrowUpDown size={12} className="opacity-100 rotate-180" />,
                              }[header.column.getIsSorted() as string] ?? (header.column.getCanSort() ? <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-50" /> : null)}
                            </div>
                          )}
                        </th>
                      ))}
                    </tr>
                  ))}
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {table.getRowModel().rows.map(row => {
                    const job = row.original;
                    // Find assigned employee for color
                    const assignedEmp = employees.find(e => e.name === job.assignedTo);

                    // Row Color Logic
                    let rowBgStyle = {};
                    let rowClass = 'hover:bg-slate-50 transition-colors border-b border-transparent';

                    if (assignedEmp?.color) {
                      // Apply Tech Color (Moderate Opacity ~20%) through inline style
                      // Assuming hex is valid 6-char
                      rowBgStyle = { backgroundColor: `${assignedEmp.color}33` }; // 33 = ~20% opacity
                      rowClass = 'transition-colors border-b border-transparent hover:brightness-95';
                    } else if (job.status === 'Complete' && job.invoiceStatus === 'Sent') {
                      rowClass = 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-b border-transparent transition-colors';
                    }

                    return (
                      <tr
                        key={row.id}
                        className={`group ${rowClass}`}
                        style={rowBgStyle}
                        onClick={() => row.toggleSelected()}
                      >
                        {row.getVisibleCells().map(cell => (
                          <td key={cell.id} className="p-3 text-sm py-2 relative">
                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* FOOTER PAGINATION */}
          <div className="bg-white border-t border-slate-200 p-2 flex justify-between items-center shrink-0 text-[10px] text-slate-500 z-30">
            <span>Showing {table.getRowModel().rows.length} of {table.getFilteredRowModel().rows.length} jobs</span>
            <div className="flex gap-2">
              <button
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
                className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
              >
                <ChevronLeft size={14} />
              </button>
              <span className="font-medium">Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}</span>
              <button
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
                className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* MODALS */}
        {editingJobId && <JobEditModal isOpen={true} onClose={() => setEditingJobId(null)} jobId={editingJobId} onOpenExtras={(id) => setExtrasModalJob(jobs.find(j => j.id === id) || null)} />}
        <ExtrasModal isOpen={!!extrasModalJob} onClose={() => setExtrasModalJob(null)} job={extrasModalJob} onSave={handleSaveExtras} />

        <DuplicateResolutionModal
          isOpen={duplicateModalOpen}
          onClose={() => {
            setDuplicateModalOpen(false);
            setPendingDuplicates([]);
            setPendingNonDuplicates([]);
            setPendingDateRange(null);
          }}
          duplicates={pendingDuplicates}
          onResolve={handleDuplicateResolution}
        />

        {/* CUSTOM ALERT / CONFIRM MODAL */}
        {activeModal && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            {/* Backdrop click REMOVED to prevent accidental close */}
            <div className="bg-white p-6 rounded-lg shadow-2xl max-w-sm w-full mx-4 border-l-4 border-amber-500 animate-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
              <h3 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
                {activeModal.type === 'CONFIRM' ? <HelpCircle className="text-amber-500" /> : <AlertTriangle className="text-amber-500" />}
                {activeModal.title}
              </h3>
              <p className="text-slate-600 mb-6 whitespace-pre-line">{activeModal.message}</p>
              <div className="flex justify-end gap-3">
                {activeModal.type === 'CONFIRM' && (
                  <button
                    onClick={() => setActiveModal(null)}
                    className="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium transition-colors"
                  >
                    Cancel
                  </button>
                )}
                <button
                  onClick={() => {
                    if (activeModal.onConfirm) activeModal.onConfirm();
                    setActiveModal(null);
                  }}
                  className={`px-4 py-2 rounded font-bold text-white shadow-sm transition-colors ${activeModal.type === 'CONFIRM' ? 'bg-red-600 hover:bg-red-700' : 'bg-slate-800 hover:bg-slate-700'}`}
                >
                  {activeModal.type === 'CONFIRM' ? 'Yes, Proceed' : 'Understood'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default JobsTable;