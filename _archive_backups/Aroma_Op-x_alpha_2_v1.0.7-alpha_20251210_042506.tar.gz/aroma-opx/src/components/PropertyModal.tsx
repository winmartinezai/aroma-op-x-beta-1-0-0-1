import React, { useState, useEffect } from 'react';
import { X, Save, Building, Phone, Globe, Mail } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { Property } from '../types/types';
// import { generateId } from '../utils/helpers';

interface PropertyModalProps {
    isOpen: boolean;
    onClose: () => void;
    propertyId: string | null; // null = New Property
}

const PropertyModal: React.FC<PropertyModalProps> = ({ isOpen, onClose, propertyId }) => {
    const { properties, addProperty, updateProperty, addLog } = useApp();

    // Form State
    const [formData, setFormData] = useState<Partial<Property>>({
        name: '',
        contact: '',
        phone: '',
        managementGroup: 'Independent',
        billingLogic: 'independent',
        poLogic: 'optional',
        portal: '',
        primaryEmail: '',
        billingEmail: ''
    });

    // Load Data on Open
    useEffect(() => {
        if (isOpen && propertyId) {
            const existing = properties.find(p => p.id === propertyId);
            if (existing) {
                setFormData({ ...existing });
            }
        } else if (isOpen && !propertyId) {
            // Reset for new
            setFormData({
                name: '',
                contact: '',
                phone: '',
                managementGroup: 'Independent',
                billingLogic: 'independent',
                poLogic: 'optional',
                portal: '',
                primaryEmail: '',
                billingEmail: ''
            });
        }
    }, [isOpen, propertyId, properties]);

    if (!isOpen) return null;

    const handleSave = () => {
        if (!formData.name) {
            alert('Property Name is required');
            return;
        }

        try {
            if (propertyId) {
                // Update
                updateProperty(propertyId, formData);
                addLog({
                    id: Date.now().toString(), // Simple ID for log
                    timestamp: new Date().toISOString(),
                    type: 'success',
                    message: `Updated property: ${formData.name}`
                });
            } else {
                // Create
                const newProperty: Property = {
                    id: crypto.randomUUID(),
                    name: formData.name,
                    contact: formData.contact || '',
                    phone: formData.phone || '',
                    managementGroup: formData.managementGroup as any || 'Independent',
                    billingLogic: formData.billingLogic as any || 'independent',
                    poLogic: formData.poLogic as any || 'optional',
                    portal: formData.portal || '',
                    primaryEmail: formData.primaryEmail,
                    billingEmail: formData.billingEmail
                };
                addProperty(newProperty);
                addLog({
                    id: Date.now().toString(),
                    timestamp: new Date().toISOString(),
                    type: 'success',
                    message: `Created new property: ${formData.name}`
                });
            }
            onClose();
        } catch (error) {
            console.error(error);
            alert('Failed to save property');
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">

                {/* Header */}
                <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                            <Building size={20} />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-slate-800">
                                {propertyId ? 'Edit Property' : 'New Property'}
                            </h2>
                            <p className="text-xs text-slate-500">Manage property details and configuration</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
                        <X size={20} />
                    </button>
                </div>

                {/* Body */}
                <div className="p-6 overflow-y-auto custom-scrollbar space-y-6">

                    {/* Section 1: Basic Info */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2">
                            Basic Information
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="col-span-2">
                                <label className="block text-xs font-bold text-slate-700 mb-1">Property Name *</label>
                                <div className="relative">
                                    <Building className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                    <input
                                        type="text"
                                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                        placeholder="e.g. Colina Ranch Hill"
                                        value={formData.name}
                                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Management Group</label>
                                <select
                                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white"
                                    value={formData.managementGroup}
                                    onChange={e => setFormData({ ...formData, managementGroup: e.target.value as any })}
                                >
                                    <option value="Independent">Independent</option>
                                    <option value="Altman">Altman</option>
                                    <option value="ZRS">ZRS</option>
                                    <option value="Greystar">Greystar</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Portal URL</label>
                                <div className="relative">
                                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                    <input
                                        type="text"
                                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                        placeholder="https://..."
                                        value={formData.portal}
                                        onChange={e => setFormData({ ...formData, portal: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Section 2: Contact Info */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2">
                            Contact Details
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Primary Contact</label>
                                <input
                                    type="text"
                                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                    placeholder="Manager Name"
                                    value={formData.contact}
                                    onChange={e => setFormData({ ...formData, contact: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                                <div className="relative">
                                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                    <input
                                        type="text"
                                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                        placeholder="(555) 123-4567"
                                        value={formData.phone}
                                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Primary Email</label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                    <input
                                        type="email"
                                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                        placeholder="manager@property.com"
                                        value={formData.primaryEmail}
                                        onChange={e => setFormData({ ...formData, primaryEmail: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Billing Email (CC)</label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                    <input
                                        type="email"
                                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                        placeholder="billing@property.com"
                                        value={formData.billingEmail}
                                        onChange={e => setFormData({ ...formData, billingEmail: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Section 3: Configuration */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2">
                            System Configuration
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">Billing Logic</label>
                                <select
                                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white"
                                    value={formData.billingLogic}
                                    onChange={e => setFormData({ ...formData, billingLogic: e.target.value as any })}
                                >
                                    <option value="independent">Independent (Per Job)</option>
                                    <option value="combined">Combined (Weekly/Monthly)</option>
                                </select>
                                <p className="text-[10px] text-slate-400 mt-1">How invoices are generated for this property.</p>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-700 mb-1">PO Requirement</label>
                                <select
                                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white"
                                    value={formData.poLogic}
                                    onChange={e => setFormData({ ...formData, poLogic: e.target.value as any })}
                                >
                                    <option value="mandatory">Mandatory (Red)</option>
                                    <option value="optional">Optional (Yellow)</option>
                                    <option value="none">None (Green)</option>
                                </select>
                                <p className="text-[10px] text-slate-400 mt-1">Strictness of PO number requirement.</p>
                            </div>
                        </div>
                    </div>

                </div>

                {/* Footer */}
                <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-2">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        className="px-4 py-2 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm flex items-center gap-2 transition-colors"
                    >
                        <Save size={16} />
                        Save Property
                    </button>
                </div>

            </div>
        </div>
    );
};

export default PropertyModal;
