
import React from 'react';
import { LayoutDashboard, ClipboardList, Users, Building, Settings, FileText, ChevronLeft, ChevronRight, PaintBucket, Sparkles } from 'lucide-react';
// ... (skip)

import type { View } from '../types/types';
import { APP_VERSION } from '../utils/constants';
import { useApp } from '../context/AppContext';

interface SidebarProps {
  currentView: View;
  onChangeView: (view: View) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, collapsed, onToggleCollapse }) => {
  const { settings, t } = useApp();

  const menuItems = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { id: 'jobs', label: t('jobs'), icon: ClipboardList },
    { id: 'employees', label: t('employees'), icon: Users },
    { id: 'properties', label: t('properties'), icon: Building },
    { id: 'settings', label: t('settings'), icon: Settings },
    { id: 'daily-report', label: t('daily-report'), icon: FileText },
  ];

  return (
    <div
      className={`bg-slate-900 text-slate-300 flex flex-col h-full shrink-0 relative z-20 shadow-xl transition-all duration-300 ${collapsed ? 'w-20' : 'w-64'}`}
    >

      {/* Top Logo Area */}
      <div className="h-16 flex items-center justify-center border-b border-slate-800 shrink-0 overflow-hidden">
        <div className={`transition-all duration-300 transform ${collapsed ? 'scale-100' : 'scale-100'}`}>
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt="Logo"
              className="w-10 h-10 object-contain rounded-lg bg-white"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-white shadow-lg border border-slate-700 relative overflow-hidden">
              {/* Paint Bucket (Painting) */}
              <PaintBucket size={18} className="text-blue-500 absolute top-1.5 left-1.5 transform -rotate-12" />
              {/* Sparkles (Cleaning) */}
              <Sparkles size={16} className="text-emerald-400 absolute bottom-1.5 right-1.5 transform rotate-12" />
            </div>
          )}
        </div>
      </div>

      <nav className="flex-1 px-3 py-6 space-y-2 overflow-y-auto custom-scrollbar overflow-x-hidden">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 group relative ${isActive
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20'
                : 'hover:bg-slate-800 hover:text-white'
                } ${collapsed ? 'justify-center px-0' : ''}`}
            >
              <Icon size={20} className={isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'} />

              {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}

              {/* Tooltip for Collapsed Mode */}
              {collapsed && (
                <div className="absolute left-16 bg-slate-900 text-white text-xs px-3 py-2 rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 shadow-xl border border-slate-700 font-medium">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / Credits Section - REFINED & SUBTLE */}
      <div className="border-t border-slate-800 bg-slate-900/50 shrink-0">
        {!collapsed && (
          <div className="px-6 py-6 animate-in fade-in slide-in-from-bottom-2 duration-500 overflow-hidden text-center">

            {/* Main Brand */}
            <h2 className="text-2xl font-black text-white tracking-wide mb-1.5 font-sans drop-shadow-md">
              Aroma Op-x
            </h2>

            {/* Subtitle */}
            <div className="text-xs text-slate-400 font-bold tracking-widest mb-4 text-center">
              Dev By.- Win Martinez <span className="tracking-tight">A<span className="text-red-500 text-[0.9em] ml-[1px]">i</span></span>
            </div>

            {/* Model / Version Info */}
            <div className="inline-block bg-slate-800 rounded px-3 py-1.5 border border-slate-700 shadow-sm">
              <span className="text-xs font-mono font-bold text-slate-400">
                {APP_VERSION}
              </span>
            </div>
          </div>
        )}

        <div className="p-4 flex justify-center border-t border-slate-800/50">
          <button
            onClick={onToggleCollapse}
            className="p-4 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors border border-transparent hover:border-slate-700 bg-slate-800/50"
            title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {collapsed ? <ChevronRight size={24} /> : <ChevronLeft size={24} />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
