
import React, { useState } from 'react';
import {
    Settings as SettingsIcon, DollarSign, Database,
    Upload, Download, Save, Globe, Monitor,
    Terminal, Shield, CheckCircle, AlertTriangle,
    ChevronRight, Plus, Trash2, Printer
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { generateId } from '../utils/helpers';

type SettingsTab = 'general' | 'pricing' | 'data' | 'integration';

const SettingsView: React.FC = () => {
    const {
        settings, updateSettings,
        activeYear, setActiveYear,
        pricingData, updateGlobalPrice,
        addLog, jobs, employees, properties,
        apiConfigs, addApiConfig, updateApiConfig, deleteApiConfig,
        appConfig, updateAppConfig
    } = useApp();

    const [newApi, setNewApi] = useState({ name: '', url: '', key: '', type: 'GOOGLE_SHEET' });
    const [activeTab, setActiveTab] = useState<SettingsTab>('general');
    const [selectedTemplateName, setSelectedTemplateName] = useState<string>('YEAR_2025');

    // Sync selected template with default if available
    React.useEffect(() => {
        if (appConfig?.DEFAULTS?.template) {
            setSelectedTemplateName(appConfig.DEFAULTS.template);
        }
    }, [appConfig]);

    // --- GENERAL TAB HANDLERS ---
    const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                updateSettings({ logoUrl: reader.result as string });
            };
            reader.readAsDataURL(file);
        }
    };

    // --- DATA TAB HANDLERS ---
    const handleExport = () => {
        const data = {
            version: settings.version || 'v1.0.0',
            timestamp: new Date().toISOString(),
            jobs,
            employees,
            properties,
            pricingData,
            settings,
            appConfig
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `aroma_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        addLog({
            id: generateId(),
            timestamp: new Date().toISOString(),
            type: 'success',
            message: 'System backup exported successfully'
        });
    };

    const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const json = JSON.parse(event.target?.result as string);
                // In a real app, we'd validate this rigorously
                // For now, we'll assume it's valid if it has the main keys
                if (json.jobs && (json.pricingData || json.appConfig)) {
                    // We need a way to bulk restore.
                    // Currently AppContext doesn't expose a "restoreAll" but we can add it or just rely on manual reload for now?
                    // Actually, let's just log it for now as "Feature Coming Soon" or implement a basic restore if easy.
                    // The user asked for the BUTTON, not necessarily the full logic yet, but let's try.
                    localStorage.setItem('aroma_ops_data_v2', JSON.stringify(json));
                    alert('Data restored! The page will now reload.');
                    window.location.reload();
                } else {
                    alert('Invalid backup file format.');
                }
            } catch (err) {
                console.error(err);
                alert('Failed to parse backup file.');
            }
        };
        reader.readAsText(file);
    };

    // --- PRICING TAB HANDLERS ---
    const handlePriceChange = (category: string, size: string, type: 'client' | 'emp', value: string) => {
        if (!appConfig) return;
        const numValue = parseFloat(value) || 0;

        const newConfig = JSON.parse(JSON.stringify(appConfig)); // Deep copy
        // @ts-ignore
        if (!newConfig.PRICING_TEMPLATES[selectedTemplateName][category]) {
            // @ts-ignore
            newConfig.PRICING_TEMPLATES[selectedTemplateName][category] = {};
        }
        // @ts-ignore
        if (!newConfig.PRICING_TEMPLATES[selectedTemplateName][category][size]) {
            // @ts-ignore
            newConfig.PRICING_TEMPLATES[selectedTemplateName][category][size] = { client: 0, emp: 0 };
        }

        // @ts-ignore
        newConfig.PRICING_TEMPLATES[selectedTemplateName][category][size][type] = numValue;

        updateAppConfig(newConfig);
    };

    const renderPricingTable = (category: string, title: string) => {
        if (!appConfig) return null;
        // @ts-ignore
        const template = appConfig.PRICING_TEMPLATES[selectedTemplateName];
        if (!template) return <div>Template not found</div>;

        // @ts-ignore
        const data = template[category] || {};
        const sizes = Object.keys(data);

        return (
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden mb-6">
                <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex justify-between items-center">
                    <h3 className="font-bold text-slate-700">{title}</h3>
                </div>
                <table className="w-full text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                        <tr>
                            <th className="px-4 py-2 text-left">Size / Item</th>
                            <th className="px-4 py-2 text-right">Client Price</th>
                            <th className="px-4 py-2 text-right">Employee Pay</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {sizes.map(size => (
                            <tr key={size} className="hover:bg-slate-50">
                                <td className="px-4 py-2 font-medium text-slate-700">{size}</td>
                                <td className="px-4 py-2 text-right">
                                    <div className="relative inline-block w-24">
                                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                                        <input
                                            type="number"
                                            className="w-full pl-6 pr-2 py-1 border rounded text-right focus:ring-2 focus:ring-blue-500 outline-none"
                                            value={data[size].client}
                                            onChange={(e) => handlePriceChange(category, size, 'client', e.target.value)}
                                        />
                                    </div>
                                </td>
                                <td className="px-4 py-2 text-right">
                                    <div className="relative inline-block w-24">
                                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                                        <input
                                            type="number"
                                            className="w-full pl-6 pr-2 py-1 border rounded text-right focus:ring-2 focus:ring-blue-500 outline-none"
                                            value={data[size].emp}
                                            onChange={(e) => handlePriceChange(category, size, 'emp', e.target.value)}
                                        />
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="flex h-full bg-slate-50">
            {/* Sidebar */}
            <div className="w-64 bg-white border-r border-slate-200 flex flex-col">
                <div className="p-6 border-b border-slate-100">
                    <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                        <SettingsIcon className="text-blue-600" />
                        Settings
                    </h2>
                </div>
                <nav className="flex-1 p-4 space-y-1">
                    <button
                        onClick={() => setActiveTab('general')}
                        className={`w - full flex items - center gap - 3 px - 4 py - 3 rounded - lg transition - colors ${activeTab === 'general' ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-600 hover:bg-slate-50'} `}
                    >
                        <Monitor size={18} /> General
                    </button>
                    <button
                        onClick={() => setActiveTab('pricing')}
                        className={`w - full flex items - center gap - 3 px - 4 py - 3 rounded - lg transition - colors ${activeTab === 'pricing' ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-600 hover:bg-slate-50'} `}
                    >
                        <DollarSign size={18} /> Pricing Config
                    </button>
                    <button
                        onClick={() => setActiveTab('data')}
                        className={`w - full flex items - center gap - 3 px - 4 py - 3 rounded - lg transition - colors ${activeTab === 'data' ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-600 hover:bg-slate-50'} `}
                    >
                        <Database size={18} /> Data Management
                    </button>
                    <button
                        onClick={() => setActiveTab('integration')}
                        className={`w - full flex items - center gap - 3 px - 4 py - 3 rounded - lg transition - colors ${activeTab === 'integration' ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-600 hover:bg-slate-50'} `}
                    >
                        <Globe size={18} /> Integrations
                    </button>
                </nav>
                <div className="p-4 border-t border-slate-100 text-xs text-slate-400 text-center">
                    v{settings.version} • Aroma Ops
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto p-8">
                <div className="max-w-4xl mx-auto">

                    {/* GENERAL TAB */}
                    {activeTab === 'general' && (
                        <div className="space-y-6 animate-in fade-in duration-300">
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                    <Monitor size={20} className="text-slate-400" />
                                    Application Preferences
                                </h3>
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                        <div>
                                            <div className="font-medium">Company Name</div>
                                            <div className="text-sm text-slate-500">Displayed on invoices and reports</div>
                                        </div>
                                        <input
                                            type="text"
                                            value={settings.companyName}
                                            onChange={(e) => updateSettings({ companyName: e.target.value })}
                                            className="border rounded px-3 py-1 w-64"
                                        />
                                    </div>
                                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                        <div>
                                            <div className="font-medium">Language</div>
                                            <div className="text-sm text-slate-500">Interface language (English/Spanish)</div>
                                        </div>
                                        <select
                                            value={settings.language}
                                            onChange={(e) => updateSettings({ language: e.target.value as 'en' | 'es' })}
                                            className="border rounded px-3 py-1 w-64"
                                        >
                                            <option value="en">English</option>
                                            <option value="es">Español</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                        <div>
                                            <div className="font-medium">Date Dial Visibility</div>
                                            <div className="text-sm text-slate-500">Where should the date navigation dial appear?</div>
                                        </div>
                                        <select
                                            value={settings.dateDialVisibility || 'dashboard_only'}
                                            onChange={(e) => updateSettings({ dateDialVisibility: e.target.value as 'dashboard_only' | 'everywhere' })}
                                            className="border rounded px-3 py-1 w-64"
                                        >
                                            <option value="dashboard_only">Dashboard Only</option>
                                            <option value="everywhere">Everywhere (Dashboard + Jobs)</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                        <div>
                                            <div className="font-medium">Debug Console</div>
                                            <div className="text-sm text-slate-500">Show system logs and status board</div>
                                        </div>
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={settings.enableDebugConsole}
                                                onChange={(e) => updateSettings({ enableDebugConsole: e.target.checked })}
                                                className="sr-only peer"
                                            />
                                            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* PRICING TAB */}
                    {activeTab === 'pricing' && (
                        <div className="space-y-6 animate-in fade-in duration-300">
                            {!appConfig ? (
                                <div className="p-8 text-center text-slate-500">
                                    <p>Loading configuration...</p>
                                    <p className="text-xs mt-2">If this persists, try reloading the page.</p>
                                </div>
                            ) : (
                                <>
                                    <div className="flex justify-between items-center">
                                        <h2 className="text-2xl font-bold text-slate-800">Pricing Configuration</h2>
                                        <div className="flex items-center gap-2">
                                            <label className="text-sm font-medium text-slate-600">Active Template:</label>
                                            <select
                                                value={selectedTemplateName}
                                                onChange={(e) => setSelectedTemplateName(e.target.value)}
                                                className="border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-bold text-blue-700 bg-white shadow-sm"
                                            >
                                                {Object.keys(appConfig.PRICING_TEMPLATES).map(t => (
                                                    <option key={t} value={t}>{t.replace('_', ' ')}</option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                        {renderPricingTable('PAINT', 'Paint Services')}
                                        {renderPricingTable('CLEAN', 'Cleaning Services')}
                                        {renderPricingTable('TOUCH_UP_PAINT', 'Touch-Up Paint')}
                                        {renderPricingTable('TOUCH_UP_CLEAN', 'Touch-Up Clean')}
                                    </div>

                                    <div className="mt-8">
                                        <h3 className="text-lg font-bold mb-4 text-slate-800">Extras & Add-ons</h3>
                                        {renderPricingTable('EXTRAS', 'Standard Extras')}
                                    </div>

                                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-start gap-3">
                                        <AlertTriangle className="text-blue-600 shrink-0 mt-0.5" size={20} />
                                        <div>
                                            <h4 className="font-bold text-blue-800 text-sm">Property Specific Overrides</h4>
                                            <p className="text-sm text-blue-600 mt-1">
                                                Some properties have specific pricing rules (e.g. Colina Ranch Hill).
                                                These are currently managed in the Property Configs section (Coming Soon to UI).
                                                For now, global template changes will affect all properties unless overridden.
                                            </p>
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    )}

                    {/* DATA TAB */}
                    {activeTab === 'data' && (
                        <div className="space-y-6 animate-in fade-in duration-300">
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                    <Database size={20} className="text-slate-400" />
                                    Backup & Restore
                                </h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 text-center space-y-3">
                                        <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                                            <Download size={24} />
                                        </div>
                                        <h4 className="font-bold text-slate-700">Export Backup</h4>
                                        <p className="text-sm text-slate-500">Download a full JSON backup of all jobs, settings, and data.</p>
                                        <button onClick={handleExport} className="px-4 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 w-full">
                                            Download JSON
                                        </button>
                                    </div>
                                    <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 text-center space-y-3">
                                        <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                                            <Upload size={24} />
                                        </div>
                                        <h4 className="font-bold text-slate-700">Restore Data</h4>
                                        <p className="text-sm text-slate-500">Restore from a previously exported JSON file.</p>
                                        <div className="relative">
                                            <input
                                                type="file"
                                                accept=".json"
                                                onChange={handleRestore}
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                            />
                                            <button className="px-4 py-2 bg-white border border-slate-300 text-slate-700 font-bold rounded-lg hover:bg-slate-50 w-full">
                                                Select File...
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* INTEGRATION TAB */}
                    {activeTab === 'integration' && (
                        <div className="space-y-6 animate-in fade-in duration-300">
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                    <Globe size={20} className="text-slate-400" />
                                    API Integrations
                                </h3>
                                <div className="text-center py-12 text-slate-400">
                                    <Terminal size={48} className="mx-auto mb-4 opacity-20" />
                                    <p>External integrations (Google Sheets, QuickBooks) coming soon.</p>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div >
    );
};

export default SettingsView;

