import React, { useState, useMemo } from 'react';
import ReactDOM from 'react-dom/client';
import JobsTable from '../components/JobsTable';
import { AppContext } from '../context/AppContext';
import { AppContextType, Job, Employee, Property, AppState, JobsViewMode } from '../types';

// --- MOCK DATA ---
const MOCK_EMPLOYEES: Employee[] = [
    { id: 'emp1', name: 'John Doe', color: '#3b82f6' },
    { id: 'emp2', name: 'Jane Smith', color: '#10b981' },
    { id: 'emp3', name: 'Bob Johnson', color: '#f59e0b' },
];

const MOCK_PROPERTIES: Property[] = [
    { id: 'prop1', name: 'Sunset Apartments', contact: 'Manager Mike', phone: '555-0101', managementGroup: 'Greystar', billingLogic: 'combined', poLogic: 'mandatory', portal: 'VendorCafe' },
    { id: 'prop2', name: 'Ocean View', contact: 'Sarah Connor', phone: '555-0102', managementGroup: 'Altman', billingLogic: 'independent', poLogic: 'optional', portal: 'OpsTechnology' },
];

const generateMockJobs = (): Job[] => {
    const jobs: Job[] = [];
    const statuses = ['Pending', 'In Progress', 'Complete', 'Paid', 'Cancel'] as const;
    const types = ['Paint', 'Clean', 'Repair', 'Resurface'];

    for (let i = 0; i < 50; i++) {
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        jobs.push({
            id: `job-${i}`,
            date: new Date(Date.now() - Math.floor(Math.random() * 1000000000)).toISOString().split('T')[0],
            property: MOCK_PROPERTIES[Math.floor(Math.random() * MOCK_PROPERTIES.length)].name,
            apt: `${Math.floor(Math.random() * 900) + 100}`,
            size: '2x2',
            type: types[Math.floor(Math.random() * types.length)],
            assignedTo: MOCK_EMPLOYEES[Math.floor(Math.random() * MOCK_EMPLOYEES.length)].name,
            status: status,
            invoiceStatus: status === 'Complete' ? (Math.random() > 0.5 ? 'Sent' : 'Draft') : 'None',
            extras: '',
            notes: 'Mock job for testing',
            clientPrice: 150 + Math.floor(Math.random() * 200),
            employeePrice: 60 + Math.floor(Math.random() * 80),
            extrasPrice: 0,
        });
    }
    return jobs;
};

const MOCK_JOBS = generateMockJobs();

// --- MOCK PROVIDER ---
const MockAppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS);
    const [viewMode, setViewMode] = useState<JobsViewMode>('DATE_FILTERED');
    const [focusDateRange, setFocusDateRange] = useState<{ start: Date; end: Date } | undefined>(undefined);

    const mockState: AppState = {
        version: '1.0.0-MOCK',
        activeYear: 2025,
        jobs,
        employees: MOCK_EMPLOYEES,
        properties: MOCK_PROPERTIES,
        pricingData: [],
        prices: {},
        settings: {
            employeeInvoiceEmail: 'test@example.com',
            companyName: 'Mock Company',
            language: 'en',
            showDateHeader: true,
            enableDebugConsole: true,
        },
        portals: {},
        quickLinks: [],
        lists: {
            jobTypes: ['Paint', 'Clean', 'Repair', 'Resurface'],
            sizes: ['1x1', '2x2', '3x2'],
        },
        tasks: [],
        prepaidUnits: {},
        history: [],
        viewMode,
        lastNonDuplicateMode: 'DATE_FILTERED',
        systemLogs: [],
        isImporting: false,
        apiConfigs: [],
    };

    const mockContext: AppContextType = {
        ...mockState,
        addJob: (job) => setJobs([...jobs, job]),
        updateJob: (id, updates) => setJobs(jobs.map(j => j.id === id ? { ...j, ...updates } : j)),
        deleteJobs: (ids) => setJobs(jobs.filter(j => !ids.includes(j.id))),
        importJobs: (newJobs) => setJobs([...jobs, ...newJobs]),
        clearAllData: () => setJobs([]),
        undoAction: () => console.log('Undo mock'),
        updatePrices: () => { },
        setActiveYear: () => { },
        updateGlobalPrice: () => { },
        deleteGlobalPrice: () => { },
        addPriceOverride: () => { },
        removePriceOverride: () => { },
        addEmployee: () => { },
        updateEmployee: () => { },
        deleteEmployee: () => { },
        updateProperty: () => { },
        addProperty: () => { },
        addQuickLink: () => { },
        deleteQuickLink: () => { },
        addTask: () => { },
        toggleTask: () => { },
        deleteTask: () => { },
        updatePrepaidList: () => { },
        setFocusDateRange,
        setJobsViewMode: setViewMode,
        addLog: () => { },
        setIsImporting: () => { },
        updateSettings: () => { },
        t: (key) => key,
        addApiConfig: () => { },
        updateApiConfig: () => { },
        deleteApiConfig: () => { },
        updateTask: () => { },
        reorderTasks: () => { },
        setTasks: () => { },
    };

    return (
        <AppContext.Provider value={mockContext}>
            {children}
        </AppContext.Provider>
    );
};

ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
        <MockAppProvider>
            <div className="p-6 bg-slate-50 min-h-screen">
                <h1 className="text-2xl font-bold mb-4 text-slate-800">Standalone Jobs Master (Polishing Mode)</h1>
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-[calc(100vh-100px)]">
                    <JobsTable />
                </div>
            </div>
        </MockAppProvider>
    </React.StrictMode>
);
