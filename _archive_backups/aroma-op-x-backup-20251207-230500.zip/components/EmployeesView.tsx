import React from 'react';

const EmployeesView: React.FC = () => {
    return (
        <div className="p-6">
            <h2 className="text-2xl font-bold text-slate-800">Employees</h2>
            <p className="text-slate-500">Employee management coming soon.</p>
        </div>
    );
};

export default EmployeesView;
