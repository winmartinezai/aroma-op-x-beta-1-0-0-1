
export interface Job {
  id: string;
  date: string;
  property: string;
  apt: string;
  size: string;
  type: string;
  assignedTo: string; // Employee name
  status: 'Pending' | 'In Progress' | 'Complete' | 'Paid' | 'Cancel';
  invoiceStatus: 'None' | 'Draft' | 'Sent';
  po?: string;
  invoiceNumber?: string;
  extras: string;
  notes: string;
  invoiceNote?: string; // Auto-generated for invoices
  clientPrice: number;
  employeePrice: number;
  extrasPrice: number;
  highlightColor?: string;
  createdAt?: number;
  relatedJobId?: string; // ID of the "Twin" job (e.g. Paint linked to Clean)
}

export interface Employee {
  id: string;
  name: string;
  color: string; // Hex code for avatar background
  rate?: number;
  phone?: string;
  email?: string;
}

export interface Property {
  id: string;
  name: string;
  contact: string;
  phone: string;

  // Professional Configuration
  managementGroup: 'Altman' | 'ZRS' | 'Greystar' | 'Independent' | 'Other';
  billingLogic: 'independent' | 'combined';
  poLogic: 'mandatory' | 'optional' | 'none'; // Traffic light system

  // Routing
  primaryEmail?: string;
  billingEmail?: string; // CC
  portal: string;
}

export interface PriceConfig {
  client: number;
  employee: number;
}

// Old PriceTable (Deprecating slowly or keeping for backward comp)
export interface PriceTable {
  [category: string]: {
    [size: string]: PriceConfig;
  };
}

// NEW PRICING SYSTEM
export interface PricingOverride {
  propertyId: string; // e.g. "Colina Ranch Hill"
  category: string;   // e.g. "TOUCH_UP_CLEAN"
  size: string;       // e.g. "2x2" or "All"
  price: PriceConfig;
}

export interface YearlyPricing {
  year: number;
  global: PriceTable;
  overrides: PricingOverride[];
}

export interface QuickLink {
  id: string;
  label: string;
  url: string;
  category: 'Estimates' | 'Portals' | 'Other';
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
}

// --- NEW ACTION HISTORY TYPES ---
export type ActionType = 'CREATE' | 'UPDATE' | 'DELETE' | 'IMPORT';

export interface ActionLog {
  id: string;
  timestamp: number;
  type: ActionType;
  description: string;
  // Data needed to revert the action
  previousData?: Job | Job[]; // For Updates (old state) or Deletes (deleted jobs)
  currentDataId?: string | string[]; // For Creates (to know what to delete on undo)
}

export type Language = 'en' | 'es';

// --- JOBS VIEW MODES ---
export type JobsViewMode =
  | 'DATE_FILTERED'   // Default: Uses Date Dial
  | 'VIEW_ALL'        // Ignores Date Dial, shows all
  | 'READY_TO_BILL'   // Status=Complete, Invoice=None/Draft
  | 'OPEN_JOBS'       // Status!=Complete
  | 'DUPLICATES_ONLY'; // Potential duplicates

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'magic';
  message: string;
  detail?: string;
}

export interface AppState {
  version: string; // Store version info
  activeYear: number;
  jobs: Job[];
  employees: Employee[];
  properties: Property[];

  // New Pricing Structure
  pricingData: YearlyPricing[]; // Array of years

  // Legacy support (temporarily keep until migration confirmed)
  prices: PriceTable;

  settings: {
    employeeInvoiceEmail: string;
    companyName: string;
    logoUrl?: string; // New field for custom logo
    language: Language; // NEW: Language setting
    showDateHeader: boolean; // NEW: Toggle Date Dial
    enableDebugConsole: boolean; // NEW: Global toggle for StatusBoard
  };
  portals: Record<string, string>; // Map portal name to URL
  quickLinks: QuickLink[]; // New Estimates/Links feature
  lists: {
    jobTypes: string[];
    sizes: string[];
  };

  tasks: Task[]; // New Todo Feature
  prepaidUnits: Record<string, string[]>; // Key: "YYYY-MM_Property", Value: ["101", "102"]

  history: ActionLog[]; // UNDO HISTORY

  focusDateRange?: { start: Date; end: Date }; // Used to auto-navigate JobsTable after import

  // VIEW STATE
  viewMode: JobsViewMode;
  lastNonDuplicateMode: JobsViewMode; // To restore after exiting duplicates view

  // SYSTEM LOGS
  systemLogs: LogEntry[];
  isImporting: boolean;
}

export type View = 'dashboard' | 'jobs' | 'employees' | 'properties' | 'settings' | 'daily-report';

export interface AppContextType extends AppState {
  addJob: (job: Job) => void;
  updateJob: (id: string, updates: Partial<Job>) => void;
  deleteJobs: (ids: string[]) => void;
  importJobs: (jobs: Job[], dateRange?: { start: Date; end: Date } | null) => void;
  clearAllData: () => void;

  // Undo Action
  undoAction: (actionId: string) => void;

  // Pricing Actions
  updatePrices: (prices: PriceTable) => void;
  setActiveYear: (year: number) => void;
  updateGlobalPrice: (year: number, category: string, size: string, price: PriceConfig) => void;
  deleteGlobalPrice: (year: number, category: string, size: string) => void; // New action
  addPriceOverride: (year: number, override: PricingOverride) => void;
  removePriceOverride: (year: number, propertyId: string, category: string, size: string) => void;

  // Employee Actions (NEW)
  addEmployee: (employee: Employee) => void;
  updateEmployee: (id: string, updates: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;

  updateProperty: (id: string, updates: Partial<Property>) => void;
  addProperty: (property: Property) => void;

  // Link Actions
  addQuickLink: (link: QuickLink) => void;
  deleteQuickLink: (id: string) => void;

  // Task Actions
  addTask: (text: string) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;

  // Prepaid Actions
  updatePrepaidList: (key: string, units: string[]) => void;

  setFocusDateRange: (range: { start: Date; end: Date } | undefined) => void;
  setJobsViewMode: (mode: JobsViewMode) => void;

  // System Actions
  addLog: (log: LogEntry) => void;
  setIsImporting: (isImporting: boolean) => void;

  // General Settings
  updateSettings: (settings: Partial<AppState['settings']>) => void;

  // Translation Helper
  t: (key: string) => string;
}
