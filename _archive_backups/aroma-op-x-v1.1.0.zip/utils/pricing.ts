
import { Job, PriceTable, YearlyPricing } from '../types';

// Map display types to PriceTable keys
export const getPriceKey = (jobType: string): string | null => {
  const t = (jobType || '').toLowerCase().trim();
  if (t === 'paint') return 'PAINT';
  if (t === 'clean') return 'CLEAN';
  if (t === 'touch up paint') return 'TOUCH_UP_PAINT';
  if (t === 'touch up clean') return 'TOUCH_UP_CLEAN';
  if (t === 'touch up') return 'TOUCH_UP_PAINT'; // Default fallback
  return null;
};

export const calculateJobPrices = (
  type: string, 
  size: string, 
  priceTable: PriceTable, // Legacy Support
  propertyName?: string, // NEW
  year?: number, // NEW
  pricingData?: YearlyPricing[] // NEW: The Brain
): { client: number; employee: number } => {
  const categoryKey = getPriceKey(type);
  if (!categoryKey) return { client: 0, employee: 0 };

  // --- NEW LOGIC START ---
  if (pricingData && year && propertyName) {
      const yearData = pricingData.find(y => y.year === year);
      
      if (yearData) {
          // 1. Check for Property Override
          const override = yearData.overrides.find(o => 
              o.propertyId === propertyName && 
              o.category === categoryKey && 
              (o.size === size || o.size === 'All')
          );

          if (override) {
              return override.price;
          }

          // 2. Check Global Year Data
          if (yearData.global[categoryKey] && yearData.global[categoryKey][size]) {
              return yearData.global[categoryKey][size];
          }
      }
  }
  // --- NEW LOGIC END ---

  // Fallback to legacy basic lookup
  if (!priceTable[categoryKey]) return { client: 0, employee: 0 };
  const sizePrices = priceTable[categoryKey][size];
  if (sizePrices) return sizePrices;
  
  return { client: 0, employee: 0 };
};

export const generateInvoiceNote = (size: string, type: string, extras: string): string => {
  // Format: "2x2 Paint, + Odor Treatment"
  let note = `${size || '?'} ${type || 'Service'}`;
  if (extras) {
    note += `, + ${extras}`;
  }
  return note;
};
