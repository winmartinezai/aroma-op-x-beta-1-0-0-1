import React, { useState, useMemo } from 'react';
import {
  Search, Filter, Download, CheckSquare, Square,
  ArrowUpDown, DollarSign, Trash2, Edit2, FileText,
  Clock, ChevronLeft, ChevronRight, FolderInput,
  Layers, Eye, AlertTriangle, Briefcase, CheckCircle,
  Plus, MoreHorizontal, FilePlus, AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Job, JobsViewMode } from '../types';
import { formatCurrency, formatDate, generateId } from '../utils/helpers';
import { parseFile, isValidFileName } from '../services/importService';
import JobEditModal from './JobEditModal';
import InvoiceStagingModal from './InvoiceStagingModal';
import DateHeader from './DateHeader';

import ContactsPortals from './ContactsPortals';

const JobsTable: React.FC = () => {
  const {
    jobs, deleteJobs, updateJob, t,
    focusDateRange, setFocusDateRange,
    viewMode, setJobsViewMode,
    addLog, setIsImporting, isImporting,
    employees,
    settings
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [sortConfig, setSortConfig] = useState<{ key: keyof Job; direction: 'asc' | 'desc' } | null>({ key: 'date', direction: 'desc' });
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [isStagingOpen, setIsStagingOpen] = useState(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  // We need importJobs from context
  const { importJobs } = useApp();

  // Redefine handleFileUpload to use importJobs
  const onFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isValidFileName(file.name)) {
      addLog({
        id: generateId(),
        timestamp: new Date().toISOString(),
        type: 'error',
        message: 'Invalid file name format. Please use YYYY-MM.xlsx'
      });
      return;
    }

    setIsImporting(true);
    try {
      const { jobs: parsedJobs, dateRange } = await parseFile(file);
      importJobs(parsedJobs, dateRange);

      addLog({
        id: generateId(),
        timestamp: new Date().toISOString(),
        type: 'success',
        message: `Successfully imported ${parsedJobs.length} jobs from ${file.name}`
      });
    } catch (error) {
      console.error(error);
      addLog({
        id: generateId(),
        timestamp: new Date().toISOString(),
        type: 'error',
        message: 'Import failed',
        detail: error instanceof Error ? error.message : String(error)
      });
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  // --- FILTER LOGIC ---
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // 1. View Mode Filter
      let matchesMode = true;

      switch (viewMode) {
        case 'DATE_FILTERED':
          if (focusDateRange) {
            const jobDate = new Date(job.date);
            const start = new Date(focusDateRange.start);
            start.setHours(0, 0, 0, 0);
            const end = new Date(focusDateRange.end);
            end.setHours(23, 59, 59, 999);
            matchesMode = jobDate >= start && jobDate <= end;
          }
          break;
        case 'VIEW_ALL':
          matchesMode = true;
          break;
        case 'READY_TO_BILL':
          // Status Complete AND Invoice None/Draft
          matchesMode = job.status === 'Complete' && job.invoiceStatus !== 'Sent';
          break;
        case 'OPEN_JOBS':
          matchesMode = job.status !== 'Complete' && job.status !== 'Paid' && job.status !== 'Cancel';
          break;
        case 'DUPLICATES_ONLY':
          matchesMode = true;
          break;
      }

      if (!matchesMode) return false;

      // 2. Search Filter
      const matchesSearch =
        searchTerm === '' ||
        job.property.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.apt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (job.po && job.po.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (job.assignedTo && job.assignedTo.toLowerCase().includes(searchTerm.toLowerCase()));

      return matchesSearch;
    });
  }, [jobs, searchTerm, viewMode, focusDateRange]);

  // Sort Logic
  const sortedJobs = useMemo(() => {
    let sortableItems = [...filteredJobs];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue === undefined || bValue === undefined) return 0;

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [filteredJobs, sortConfig]);

  // Pagination Logic
  const totalPages = Math.ceil(sortedJobs.length / itemsPerPage);
  const paginatedJobs = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedJobs.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedJobs, currentPage]);

  const requestSort = (key: keyof Job) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const toggleSelection = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedJobs.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginatedJobs.map(j => j.id)));
    }
  };

  const handleDeleteSelected = () => {
    if (confirm(`Are you sure you want to delete ${selectedIds.size} jobs?`)) {
      deleteJobs(Array.from(selectedIds));
      setSelectedIds(new Set());
    }
  };

  const handleStatusChange = (id: string, newStatus: Job['status']) => {
    updateJob(id, { status: newStatus });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Complete': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'In Progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Pending': return 'bg-slate-100 text-slate-600 border-slate-200';
      case 'Paid': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Cancel': return 'bg-red-50 text-red-500 border-red-100 line-through';
      default: return 'bg-slate-50 text-slate-500';
    }
  };

  // Helper to get row background color
  const getRowStyle = (job: Job) => {
    // 1. Green Line Rule: Complete + Sent = Green
    if (job.status === 'Complete' && job.invoiceStatus === 'Sent') {
      return { backgroundColor: '#dcfce7' }; // emerald-100
    }

    // 2. Employee Color Rule
    if (job.assignedTo) {
      const emp = employees.find(e => e.name === job.assignedTo);
      if (emp && emp.color) {
        // Create a very light version of the color (approx 10% opacity)
        // Since we have hex, we can use a style with opacity or rgba
        return { backgroundColor: `${emp.color}15` }; // Hex + 15 alpha ~ 8% opacity
      }
    }

    return {};
  };

  // Calculate Totals
  const totals = useMemo(() => {
    return filteredJobs.reduce((acc, job) => ({
      client: acc.client + (job.clientPrice || 0),
      employee: acc.employee + (job.employeePrice || 0),
      count: acc.count + 1
    }), { client: 0, employee: 0, count: 0 });
  }, [filteredJobs]);

  const selectedTotals = useMemo(() => {
    const selected = jobs.filter(j => selectedIds.has(j.id));
    return selected.reduce((acc, job) => ({
      client: acc.client + (job.clientPrice || 0),
      employee: acc.employee + (job.employeePrice || 0),
      count: acc.count + 1
    }), { client: 0, employee: 0, count: 0 });
  }, [jobs, selectedIds]);

  // Counts for Tabs
  const readyToBillCount = useMemo(() => {
    // Count jobs that match READY_TO_BILL criteria within current date range (if filtered)
    // Or globally? Usually tabs show global or filtered counts. Let's stick to filtered for consistency.
    return jobs.filter(j => j.status === 'Complete' && j.invoiceStatus !== 'Sent').length;
  }, [jobs]);

  return (
    <div className="flex flex-col h-full bg-slate-50 relative">

      {/* DATE DIAL HEADER (Only visible in DATE_FILTERED mode) */}
      {viewMode === 'DATE_FILTERED' && (
        <DateHeader
          currentRange={focusDateRange}
          onRangeChange={setFocusDateRange}
          onClear={() => setJobsViewMode('VIEW_ALL')}
          hasActiveFilter={!!focusDateRange}
        />
      )}

      {/* DUPLICATE WARNING BANNER (Mocked for now based on screenshot idea) */}
      {/* In a real scenario, we'd check for actual duplicates */}
      {false && (
        <div className="bg-orange-50 border-b border-orange-200 p-3 flex items-center justify-between text-orange-800 text-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} className="text-orange-600" />
            <div>
              <span className="font-bold">342 Potential Duplicates Found</span>
              <span className="ml-2 opacity-80">Some jobs have same unit + service within 14 days.</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="bg-orange-100 hover:bg-orange-200 text-orange-800 px-3 py-1 rounded font-bold transition-colors">Resolve</button>
            <button className="bg-white border border-orange-200 hover:bg-orange-50 text-orange-800 px-3 py-1 rounded font-bold transition-colors">Show All (Ignore)</button>
          </div>
        </div>
      )}

      {/* CONTACTS & PORTALS (Search on Top) */}
      <div className="px-2 pt-2">
        <ContactsPortals />
      </div>

      {/* TOOLBAR */}
      <div className="bg-white border-b border-slate-200 p-2 flex flex-col md:flex-row gap-4 justify-between items-center shrink-0 shadow-sm z-20">

        {/* LEFT: Tabs & Actions */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
          {/* New Job Button */}
          <button className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded-md text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm whitespace-nowrap">
            <Plus size={14} />
            New Job
          </button>

          <div className="h-6 w-px bg-slate-200 mx-1"></div>

          {/* Tabs */}
          <button
            onClick={() => setJobsViewMode('OPEN_JOBS')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'OPEN_JOBS' ? 'bg-slate-100 text-slate-800 border border-slate-200' : 'text-slate-500 hover:bg-slate-50'
              }`}
          >
            <Briefcase size={14} />
            Open Jobs
          </button>

          <button
            onClick={() => setJobsViewMode('READY_TO_BILL')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${viewMode === 'READY_TO_BILL' ? 'bg-red-50 text-red-700 border border-red-100' : 'text-slate-500 hover:bg-slate-50'
              }`}
          >
            <CheckCircle size={14} />
            Ready to Bill
            <span className="bg-red-100 text-red-700 px-1.5 rounded-full text-[10px] font-bold">{readyToBillCount}</span>
          </button>

          <div className="h-6 w-px bg-slate-200 mx-1"></div>

          {/* Icon Actions */}
          <div className="flex items-center gap-1">
            <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"><Edit2 size={14} /></button>
            <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"><Search size={14} /></button>
            <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"><Filter size={14} /></button>
            <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"><AlertCircle size={14} /></button>
          </div>
        </div>

        {/* RIGHT: Search & Import */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">

          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input
              type="text"
              placeholder="Search..."
              className="w-48 pl-8 pr-3 py-1.5 text-xs rounded-md border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Import Button */}
          <label className={`flex items-center gap-2 px-3 py-1.5 rounded-md cursor-pointer transition-all border ${isImporting ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white text-blue-600 border-blue-200 hover:bg-blue-50 hover:border-blue-300 shadow-sm'}`}>
            <FolderInput size={14} />
            <span className="font-bold text-xs hidden sm:inline">{isImporting ? 'Importing...' : 'Import Folder'}</span>
            <input
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={onFileUpload}
              disabled={isImporting}
            />
          </label>
        </div>
      </div>

      {/* TABLE CONTAINER */}
      <div className="flex-1 overflow-auto relative">
        <table className="w-full text-xs text-left border-collapse">
          <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider sticky top-0 z-10 shadow-sm">
            <tr>
              <th className="p-3 w-8 border-b border-slate-200 text-center">#</th>
              <th className="p-3 w-8 border-b border-slate-200">
                <button onClick={toggleSelectAll} className="flex items-center justify-center text-slate-400 hover:text-slate-600">
                  {selectedIds.size > 0 && selectedIds.size === paginatedJobs.length ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
                </button>
              </th>
              {[
                { key: 'date', label: 'DATE', width: 'min-w-[90px]' },
                { key: 'property', label: 'PROPERTY', width: 'min-w-[160px]' },
                { key: 'apt', label: 'UNIT', width: 'min-w-[60px]' },
                { key: 'type', label: 'SERVICE', width: 'min-w-[100px]' },
                { key: 'size', label: 'SIZE', width: 'min-w-[60px]' },
                { key: 'assignedTo', label: 'TECH', width: 'min-w-[120px]' },
                { key: 'status', label: 'STATUS', width: 'min-w-[100px]' },
                { key: 'invoiceStatus', label: 'INV STATUS', width: 'min-w-[80px]' },
                { key: 'invoiceNumber', label: 'INV #', width: 'min-w-[60px]' },
                { key: 'extras', label: 'EXTRAS', width: 'min-w-[80px]' },
                { key: 'clientPrice', label: 'PRICE', width: 'min-w-[80px] text-right' },
                { key: 'employeePrice', label: 'PAY', width: 'min-w-[80px] text-right' },
                { key: 'total', label: 'TOTAL', width: 'min-w-[80px] text-right' },
                { key: 'actions', label: 'ACTIONS', width: 'min-w-[60px] text-center' },
              ].map((col) => (
                <th
                  key={col.key}
                  className={`p-3 border-b border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors group ${col.width}`}
                  onClick={() => col.key !== 'actions' && col.key !== 'total' && requestSort(col.key as keyof Job)}
                >
                  <div className={`flex items-center gap-1 ${col.width.includes('right') ? 'justify-end' : col.width.includes('center') ? 'justify-center' : ''}`}>
                    {col.label}
                    {col.key !== 'actions' && col.key !== 'total' && <ArrowUpDown size={10} className="opacity-0 group-hover:opacity-50 transition-opacity" />}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {paginatedJobs.length === 0 ? (
              <tr>
                <td colSpan={16} className="p-12 text-center text-slate-400 italic">
                  {viewMode === 'DATE_FILTERED' && focusDateRange
                    ? "No jobs found for the selected date range."
                    : "No jobs found matching your filters."}
                </td>
              </tr>
            ) : (
              paginatedJobs.map((job, index) => (
                <tr
                  key={job.id}
                  style={getRowStyle(job)}
                  className={`group transition-colors hover:brightness-95 ${selectedIds.has(job.id) ? 'bg-blue-50/50' : ''}`}
                >
                  <td className="p-3 text-center text-slate-400 font-mono text-[10px]">{(currentPage - 1) * itemsPerPage + index + 1}</td>
                  <td className="p-3">
                    <button onClick={() => toggleSelection(job.id)} className="flex items-center justify-center text-slate-300 hover:text-blue-500">
                      {selectedIds.has(job.id) ? <CheckSquare size={14} className="text-blue-600" /> : <Square size={14} />}
                    </button>
                  </td>
                  <td className="p-3 font-mono text-slate-600">{formatDate(job.date)}</td>
                  <td className="p-3 font-bold text-slate-700 truncate max-w-[160px]" title={job.property}>{job.property}</td>
                  <td className="p-3 font-bold text-slate-800">{job.apt}</td>
                  <td className="p-3 font-bold text-slate-600 uppercase text-[10px]">{job.type}</td>
                  <td className="p-3 text-slate-500">{job.size}</td>
                  <td className="p-3">
                    {job.assignedTo && (
                      <div className="flex items-center gap-2">
                        <div
                          className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shadow-sm"
                          style={{ backgroundColor: employees.find(e => e.name === job.assignedTo)?.color || '#cbd5e1' }}
                        >
                          {job.assignedTo.charAt(0)}
                        </div>
                        <span className="text-slate-700 font-medium">{job.assignedTo}</span>
                      </div>
                    )}
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 rounded-full ${job.status === 'Complete' ? 'bg-emerald-500' :
                        job.status === 'In Progress' ? 'bg-blue-500' :
                          job.status === 'Pending' ? 'bg-slate-300' : 'bg-red-500'
                        }`}></div>
                      <span className="text-slate-600">{job.status}</span>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${job.invoiceStatus === 'Sent' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                      job.invoiceStatus === 'Draft' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                        'bg-slate-50 text-slate-400 border-slate-100'
                      }`}>
                      {job.invoiceStatus === 'None' ? '-' : job.invoiceStatus}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400 font-mono">{job.invoiceNumber || '-'}</td>
                  <td className="p-3">
                    {job.extras ? (
                      <span className="text-slate-600 truncate max-w-[80px] block" title={job.extras}>{job.extras}</span>
                    ) : (
                      <button className="text-slate-300 hover:text-blue-500 flex items-center gap-1 text-[10px] border border-dashed border-slate-300 px-1.5 py-0.5 rounded hover:border-blue-300 transition-colors">
                        <Plus size={10} /> Add
                      </button>
                    )}
                  </td>
                  <td className="p-3 text-right font-mono text-slate-700 font-medium">{formatCurrency(job.clientPrice)}</td>
                  <td className="p-3 text-right font-mono text-slate-500">{formatCurrency(job.employeePrice)}</td>
                  <td className="p-3 text-right font-mono text-slate-800 font-bold">{formatCurrency((job.clientPrice || 0) + (job.extrasPrice || 0))}</td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => setEditingJobId(job.id)}
                      className="text-slate-400 hover:text-blue-600 transition-colors"
                    >
                      <MoreHorizontal size={14} />
                    </button>
                  </td>
                </tr>
              ))
            )}
            {/* Ghost Rows for Spacing */}
            {[...Array(5)].map((_, i) => (
              <tr key={`ghost-${i}`} className="h-10 border-b border-transparent">
                <td colSpan={16}></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* STICKY FOOTER */}
      <div className="bg-white border-t border-slate-200 p-2 flex justify-between items-center shrink-0 text-[10px] text-slate-500 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-30">
        <div className="flex items-center gap-4">
          <span>Showing {paginatedJobs.length} of {filteredJobs.length} jobs</span>

          {/* Quick Stats */}
          <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
            <div className="flex items-center gap-1.5">
              <DollarSign size={12} className="text-emerald-500" />
              <span className="font-bold text-slate-700">{formatCurrency(selectedIds.size > 0 ? selectedTotals.client : totals.client)}</span>
              <span className="text-slate-400">REVENUE</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock size={12} className="text-orange-400" />
              <span className="font-bold text-slate-700">{formatCurrency(selectedIds.size > 0 ? selectedTotals.employee : totals.employee)}</span>
              <span className="text-slate-400">PAYROLL</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
          >
            <ChevronLeft size={14} />
          </button>
          <span className="font-medium">Page {currentPage} of {totalPages || 1}</span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Modals */}
      {editingJobId && (
        <JobEditModal
          isOpen={true}
          onClose={() => setEditingJobId(null)}
          jobId={editingJobId}
        />
      )}

      <InvoiceStagingModal
        isOpen={isStagingOpen}
        onClose={() => setIsStagingOpen(false)}
        selectedJobs={jobs.filter(j => selectedIds.has(j.id))}
      />
    </div>
  );
};

export default JobsTable;