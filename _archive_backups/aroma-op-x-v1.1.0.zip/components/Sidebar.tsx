
import React from 'react';
import { LayoutDashboard, ClipboardList, Users, Building, Settings, FileText, ChevronLeft, ChevronRight, PaintBucket } from 'lucide-react';
import { View } from '../types';
import { APP_VERSION, BUILD_DATE } from '../constants';
import { useApp } from '../context/AppContext';

interface SidebarProps {
  currentView: View;
  onChangeView: (view: View) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, collapsed, onToggleCollapse }) => {
  const { settings, t } = useApp();

  const menuItems = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { id: 'jobs', label: t('jobs'), icon: ClipboardList },
    { id: 'employees', label: t('employees'), icon: Users },
    { id: 'properties', label: t('properties'), icon: Building },
    { id: 'settings', label: t('settings'), icon: Settings },
    { id: 'daily-report', label: t('daily-report'), icon: FileText },
  ];

  return (
    <div
      className={`bg-slate-900 text-slate-300 flex flex-col h-full shrink-0 relative z-20 shadow-xl transition-all duration-300 ${collapsed ? 'w-20' : 'w-64'}`}
    >

      {/* Top Logo Area */}
      <div className="h-16 flex items-center justify-center border-b border-slate-800 shrink-0 overflow-hidden">
        <div className={`transition-all duration-300 transform ${collapsed ? 'scale-100' : 'scale-100'}`}>
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt="Logo"
              className="w-10 h-10 object-contain rounded-lg bg-white"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center text-white shadow-lg shadow-blue-900/50">
              <PaintBucket size={20} fill="currentColor" className="text-blue-100" />
            </div>
          )}
        </div>
      </div>

      <nav className="flex-1 px-3 py-6 space-y-2 overflow-y-auto custom-scrollbar overflow-x-hidden">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 group relative ${isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20'
                  : 'hover:bg-slate-800 hover:text-white'
                } ${collapsed ? 'justify-center px-0' : ''}`}
            >
              <Icon size={20} className={isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'} />

              {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}

              {/* Tooltip for Collapsed Mode */}
              {collapsed && (
                <div className="absolute left-16 bg-slate-900 text-white text-xs px-3 py-2 rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 shadow-xl border border-slate-700 font-medium">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / Credits Section - REFINED & SUBTLE */}
      <div className="border-t border-slate-800 bg-slate-900/50 shrink-0">
        {!collapsed && (
          <div className="px-6 py-6 animate-in fade-in slide-in-from-bottom-2 duration-500 overflow-hidden text-center">

            {/* Main Brand */}
            <h2 className="text-lg font-bold text-white tracking-wide mb-1 font-sans">
              Aroma Op-x
            </h2>

            {/* Subtitle */}
            <div className="text-[10px] text-slate-500 font-medium tracking-wider uppercase mb-3">
              By Win Martinez Ai
            </div>

            {/* Model / Version Info */}
            <div className="inline-block bg-slate-800/50 rounded px-2 py-1 border border-slate-800">
              <span className="text-[9px] font-mono text-slate-600">
                {APP_VERSION}
              </span>
            </div>
          </div>
        )}

        <div className="p-4 flex justify-center border-t border-slate-800/50">
          <button
            onClick={onToggleCollapse}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-500 hover:text-white transition-colors border border-transparent hover:border-slate-700"
            title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
