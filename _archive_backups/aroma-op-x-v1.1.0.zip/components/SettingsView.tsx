import React, { useState } from 'react';
import {
    Settings as SettingsIcon, DollarSign, Database,
    Upload, Download, Save, Globe, Monitor,
    Terminal, Shield, CheckCircle, AlertTriangle,
    ChevronRight, Plus, Trash2, Printer
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { generateId } from '../utils/helpers';

type SettingsTab = 'general' | 'pricing' | 'data';

const SettingsView: React.FC = () => {
    const {
        settings, updateSettings,
        activeYear, setActiveYear,
        pricingData, updateGlobalPrice,
        addLog, jobs, employees, properties
    } = useApp();

    const [activeTab, setActiveTab] = useState<SettingsTab>('general');

    // --- GENERAL TAB HANDLERS ---
    const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                updateSettings({ logoUrl: reader.result as string });
            };
            reader.readAsDataURL(file);
        }
    };

    // --- DATA TAB HANDLERS ---
    const handleExport = () => {
        const data = {
            version: settings.version || 'v1.0.0',
            timestamp: new Date().toISOString(),
            jobs,
            employees,
            properties,
            pricingData,
            settings
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `aroma_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        addLog({
            id: generateId(),
            timestamp: new Date().toISOString(),
            type: 'success',
            message: 'System backup exported successfully'
        });
    };

    const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const json = JSON.parse(event.target?.result as string);
                // In a real app, we'd validate this rigorously
                // For now, we'll assume it's valid if it has the main keys
                if (json.jobs && json.pricingData) {
                    // We need a way to bulk restore. 
                    // Currently AppContext doesn't expose a "restoreAll" but we can add it or just rely on manual reload for now?
                    // Actually, let's just log it for now as "Feature Coming Soon" or implement a basic restore if easy.
                    // The user asked for the BUTTON, not necessarily the full logic yet, but let's try.
                    localStorage.setItem('aroma_ops_data_v2', JSON.stringify(json));
                    alert('Data restored! The page will now reload.');
                    window.location.reload();
                } else {
                    alert('Invalid backup file format.');
                }
            } catch (err) {
                console.error(err);
                alert('Failed to parse backup file.');
            }
        };
        reader.readAsText(file);
    };

    // --- PRICING TAB HELPERS ---
    const currentPricing = pricingData.find(p => p.year === activeYear) || {
        year: activeYear,
        global: {},
        overrides: []
    };

    // Flatten global prices for table display
    // We'll focus on the main categories: CLEAN, PAINT, TOUCH_UP_CLEAN
    const pricingRows = [
        { size: '1x1', clean: currentPricing.global.CLEAN?.['1x1'], paint: currentPricing.global.PAINT?.['1x1'] },
        { size: '2x2', clean: currentPricing.global.CLEAN?.['2x2'], paint: currentPricing.global.PAINT?.['2x2'] },
        { size: '3x2', clean: currentPricing.global.CLEAN?.['3x2'], paint: currentPricing.global.PAINT?.['3x2'] },
        { size: 'Studio', clean: currentPricing.global.CLEAN?.['Studio'], paint: currentPricing.global.PAINT?.['Studio'] },
    ];

    return (
        <div className="flex flex-col h-full bg-slate-50">

            {/* Header */}
            <div className="bg-white border-b border-slate-200 px-6 py-4 shrink-0">
                <h2 className="text-lg font-bold text-slate-800">Settings</h2>
                <p className="text-xs text-slate-500">Control Center</p>
            </div>

            {/* Tabs */}
            <div className="flex justify-end px-6 py-2 border-b border-slate-200 bg-white shrink-0">
                <div className="flex bg-slate-100 p-1 rounded-lg">
                    {(['general', 'pricing', 'data'] as SettingsTab[]).map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wide transition-all ${activeTab === tab
                                    ? 'bg-white text-slate-800 shadow-sm'
                                    : 'text-slate-400 hover:text-slate-600'
                                }`}
                        >
                            {tab === 'data' ? 'Data & Backup' : tab}
                        </button>
                    ))}
                </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6">
                <div className="max-w-4xl mx-auto space-y-6">

                    {/* --- GENERAL TAB --- */}
                    {activeTab === 'general' && (
                        <>
                            {/* Brand Identity */}
                            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                                <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
                                    <Shield size={16} className="text-blue-500" />
                                    <h3 className="font-bold text-slate-700">Brand Identity</h3>
                                </div>
                                <div className="p-6 flex flex-col md:flex-row gap-8 items-start">
                                    {/* Logo Upload */}
                                    <div className="shrink-0">
                                        <label className="block w-32 h-32 rounded-xl border-2 border-dashed border-slate-300 hover:border-blue-400 cursor-pointer flex flex-col items-center justify-center bg-slate-50 transition-colors group relative overflow-hidden">
                                            {settings.logoUrl ? (
                                                <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-contain p-2" />
                                            ) : (
                                                <>
                                                    <Upload size={24} className="text-slate-400 group-hover:text-blue-500 mb-2" />
                                                    <span className="text-[10px] font-bold text-slate-400 uppercase">Upload</span>
                                                </>
                                            )}
                                            <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                                        </label>
                                    </div>

                                    {/* Fields */}
                                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                                        <div>
                                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Company Name</label>
                                            <input
                                                className="w-full text-sm font-bold text-slate-700 border border-slate-200 rounded-lg px-3 py-2 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                                                value={settings.companyName}
                                                onChange={(e) => updateSettings({ companyName: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Invoice Email (CC)</label>
                                            <input
                                                className="w-full text-sm font-medium text-slate-600 border border-slate-200 rounded-lg px-3 py-2 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                                                value={settings.employeeInvoiceEmail}
                                                onChange={(e) => updateSettings({ employeeInvoiceEmail: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Application Interface */}
                            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                                <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
                                    <Monitor size={16} className="text-purple-500" />
                                    <h3 className="font-bold text-slate-700">Application Interface</h3>
                                </div>
                                <div className="divide-y divide-slate-100">

                                    {/* Date Dial Toggle */}
                                    <div className="px-6 py-4 flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                                                <SettingsIcon size={18} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-700">Visual Date Dial</p>
                                                <p className="text-xs text-slate-500">Show the timeline navigator at the top of Jobs table.</p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => updateSettings({ showDateHeader: !settings.showDateHeader })}
                                            className={`w-12 h-6 rounded-full transition-colors relative ${settings.showDateHeader ? 'bg-blue-600' : 'bg-slate-200'}`}
                                        >
                                            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${settings.showDateHeader ? 'left-7' : 'left-1'}`}></div>
                                        </button>
                                    </div>

                                    {/* Debug Console Toggle */}
                                    <div className="px-6 py-4 flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-slate-100 text-slate-600 rounded-lg">
                                                <Terminal size={18} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-700">System Debug Console</p>
                                                <p className="text-xs text-slate-500">Show status board at bottom of screen.</p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => updateSettings({ enableDebugConsole: !settings.enableDebugConsole })}
                                            className={`w-12 h-6 rounded-full transition-colors relative ${settings.enableDebugConsole ? 'bg-blue-600' : 'bg-slate-200'}`}
                                        >
                                            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${settings.enableDebugConsole ? 'left-7' : 'left-1'}`}></div>
                                        </button>
                                    </div>

                                    {/* Language Toggle */}
                                    <div className="px-6 py-4 flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                                                <Globe size={18} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-700">System Language</p>
                                                <p className="text-xs text-slate-500">Affects menus and static labels.</p>
                                            </div>
                                        </div>
                                        <div className="flex bg-slate-100 rounded-lg p-1">
                                            <button
                                                onClick={() => updateSettings({ language: 'en' })}
                                                className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${settings.language === 'en' ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'}`}
                                            >
                                                EN
                                            </button>
                                            <button
                                                onClick={() => updateSettings({ language: 'es' })}
                                                className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${settings.language === 'es' ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'}`}
                                            >
                                                ES
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </>
                    )}

                    {/* --- PRICING TAB --- */}
                    {activeTab === 'pricing' && (
                        <>
                            {/* Year Selector */}
                            <div className="flex justify-center mb-6">
                                <div className="flex bg-white border border-slate-200 rounded-xl p-1 shadow-sm">
                                    {[2024, 2025, 2026].map(year => (
                                        <button
                                            key={year}
                                            onClick={() => setActiveYear(year)}
                                            className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeYear === year
                                                    ? 'bg-slate-900 text-white shadow-md'
                                                    : 'text-slate-500 hover:bg-slate-50'
                                                }`}
                                        >
                                            {year}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                                {/* Base Rate Card */}
                                <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                                    <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 rounded bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">$</div>
                                            <div>
                                                <h3 className="font-bold text-slate-700 text-sm">Base Rate Card</h3>
                                                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Global Defaults</p>
                                            </div>
                                        </div>
                                        <button className="text-slate-400 hover:text-slate-600">
                                            <Printer size={16} />
                                        </button>
                                    </div>

                                    <div className="p-6">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100">
                                                    <th className="text-left py-2 font-bold">Size Variant</th>
                                                    <th className="text-right py-2 font-bold">Client Bill</th>
                                                    <th className="text-right py-2 font-bold">Worker Pay</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-slate-50">
                                                {/* Simplified View for Demo - Just showing CLEAN prices for now as example */}
                                                {pricingRows.map(row => (
                                                    <tr key={row.size} className="group hover:bg-slate-50">
                                                        <td className="py-3 font-bold text-slate-700">{row.size}</td>
                                                        <td className="py-3 text-right font-mono text-slate-600">
                                                            {row.clean?.client || '-'}
                                                        </td>
                                                        <td className="py-3 text-right font-mono text-slate-400">
                                                            {row.clean?.employee || '-'}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                        <button className="w-full mt-4 py-2 border border-dashed border-slate-300 rounded-lg text-xs font-bold text-slate-400 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 transition-all flex items-center justify-center gap-2">
                                            <Plus size={14} />
                                            Add Size Variant
                                        </button>
                                    </div>
                                </div>

                                {/* Exceptions / Overrides */}
                                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                                    <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 rounded bg-purple-100 text-purple-600 flex items-center justify-center">
                                                <SettingsIcon size={12} />
                                            </div>
                                            <div>
                                                <h3 className="font-bold text-slate-700 text-sm">Exceptions</h3>
                                                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Property Overrides</p>
                                            </div>
                                        </div>
                                        <button className="bg-slate-800 text-white p-1 rounded hover:bg-slate-700">
                                            <Plus size={12} />
                                        </button>
                                    </div>

                                    <div className="divide-y divide-slate-100">
                                        {currentPricing.overrides.length === 0 ? (
                                            <div className="p-8 text-center text-slate-400 italic text-xs">
                                                No overrides configured for {activeYear}.
                                            </div>
                                        ) : (
                                            currentPricing.overrides.map((override, idx) => (
                                                <div key={idx} className="p-4 hover:bg-slate-50 group">
                                                    <div className="flex justify-between items-start mb-1">
                                                        <span className="font-bold text-slate-700 text-xs">{override.propertyId}</span>
                                                        <span className="text-emerald-600 font-mono font-bold text-xs">{formatCurrency(override.price.client)}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center text-[10px] text-slate-500">
                                                        <span>{override.category} • {override.size}</span>
                                                        <button className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-500 transition-all">
                                                            <Trash2 size={12} />
                                                        </button>
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>

                            </div>
                        </>
                    )}

                    {/* --- DATA TAB --- */}
                    {activeTab === 'data' && (
                        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                                <h3 className="font-bold text-slate-700 flex items-center gap-2">
                                    <Database size={16} className="text-slate-400" />
                                    Data Management
                                </h3>
                                <p className="text-xs text-slate-500 mt-1">Backup your data regularly. The system stores data locally in your browser.</p>
                            </div>

                            <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                                <button
                                    onClick={handleExport}
                                    className="flex flex-col items-center justify-center gap-3 p-8 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-blue-300 hover:shadow-md transition-all group"
                                >
                                    <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                                        <Download size={24} />
                                    </div>
                                    <div className="text-center">
                                        <h4 className="font-bold text-slate-700">Expert Backup</h4>
                                        <p className="text-xs text-slate-400 mt-1">Download JSON file</p>
                                    </div>
                                </button>

                                <label className="flex flex-col items-center justify-center gap-3 p-8 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-emerald-300 hover:shadow-md transition-all group cursor-pointer">
                                    <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                                        <Upload size={24} />
                                    </div>
                                    <div className="text-center">
                                        <h4 className="font-bold text-slate-700">Restore Data</h4>
                                        <p className="text-xs text-slate-400 mt-1">Select JSON file</p>
                                    </div>
                                    <input type="file" accept=".json" className="hidden" onChange={handleRestore} />
                                </label>
                            </div>

                            <div className="px-6 py-4 bg-orange-50 border-t border-orange-100 flex items-start gap-3">
                                <AlertTriangle size={16} className="text-orange-500 shrink-0 mt-0.5" />
                                <p className="text-xs text-orange-800">
                                    <strong>Note:</strong> Clearing your browser cache or using a cleaner tool will erase this app's data unless you have an exported backup.
                                </p>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};

export default SettingsView;
